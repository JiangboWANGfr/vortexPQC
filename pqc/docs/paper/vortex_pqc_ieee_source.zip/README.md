# IEEE manuscript source package

Open `main.tex` in Overleaf using pdfLaTeX, or run:

    latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex

This is an IEEEtran conference working draft, not a venue-specific submission.
The local build has 10 pages, 16 tables, 5 figures, and 11 references.
IEEEtran, TikZ, and the other packages declared in `main.tex` are supplied by a
standard TeX Live installation and by Overleaf.

All generated `.tex` tables and four vector PDF plots are frozen in this
package. The fifth figure is drawn in `main.tex` using TikZ. Editing a CSV does
not update these tables automatically. To regenerate numerical content, use
`pqc/docs/paper/generate_results.py` in the original Vortex repository and
rebuild the paper there.

`DATA_NOTES_ZH.md` explains the data and limitations in Chinese. CSV links in
this copy point to the bundled snapshots under `pqc/results/`.
`provenance.json` contains their SHA-256 hashes and the numerical macros used
in the manuscript.

The snapshots preserve historical comments for audit. The final unified
ML-KEM table fixes W32 NTT and cooperative arithmetic while switching five
Keccak backends. It includes new SimX M=1/M=8 runs and XRT M=1 validation for
SG25 stages and whole-round KROUND. No board measurements were produced.
