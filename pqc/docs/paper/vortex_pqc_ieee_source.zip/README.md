# IEEE manuscript source package

Open `main.tex` in Overleaf using pdfLaTeX, or run:

    latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex

This is an IEEEtran conference working draft, not a venue-specific submission.
The local build has 12 pages, 23 tables, 5 figures, and 11 references.
IEEEtran, TikZ, balance, and the other packages declared in `main.tex` are
supplied by a standard TeX Live installation and by Overleaf.

All generated `.tex` tables and four vector PDF plots are frozen in this
package. The fifth figure is drawn in `main.tex` using TikZ. Editing a CSV does
not update these tables automatically. To regenerate numerical content, use
`pqc/docs/paper/generate_results.py` in the original Vortex repository and
rebuild the paper there.

`DATA_NOTES_ZH.md` explains the data and limitations in Chinese. CSV links in
this copy point to the bundled snapshots under `pqc/results/`.
`provenance.json` records the 23 input-file SHA-256 hashes and numerical macros
used in the manuscript.

The new W32 controls use RV32IM with F/D disabled. They add PQRV assembly,
SG1/SG5/SG25 mapping and packed-state measurements, equal round-unrolling
controls, and corresponding complete ML-KEM KAT runs. Source commit
38c56304f identifies their implementation. Numerical checks pass throughout;
the two SG5 timing-model pairs fail the unchanged 5% threshold and remain
explicitly marked FAIL in the CSV. The other 16 timing pairs pass. Do not
interpret numerical correctness as a timing-model pass.

The snapshots also preserve historical comments for audit. The final unified
ML-KEM table fixes the W32 half-bank NTT and cooperative arithmetic while
switching five Keccak backends. The direct RV32IM W8T32 phase profile reports
mutually exclusive M1 intervals and preserves uninstrumented M1/M8 headlines.
The matched XLEN tables compare Stage and KROUND at RV32IM and RV64IM with F/D
disabled, then compare six independent NTT-only, NTT-plus-Stage, and
NTT-plus-KROUND post-route implementations. All six route without routing
errors; RV64IM Stage and KROUND miss the 250 MHz setup target and are labeled
as timing misses. No new synthesis, board measurements, or activity-driven
power measurements were produced for the W32 software controls.
