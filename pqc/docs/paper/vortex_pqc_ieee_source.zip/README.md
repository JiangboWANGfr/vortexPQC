# IEEE manuscript source package

Open `main.tex` in Overleaf using pdfLaTeX, or run:

    latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex

This is an IEEEtran conference working draft, not a venue-specific submission.
The local build has 11 pages, 19 tables, 5 figures, and 11 references.
IEEEtran, TikZ, and the other packages declared in `main.tex` are supplied by a
standard TeX Live installation and by Overleaf.

All generated `.tex` tables and four vector PDF plots are frozen in this
package. The fifth figure is drawn in `main.tex` using TikZ. Editing a CSV does
not update these tables automatically. To regenerate numerical content, use
`pqc/docs/paper/generate_results.py` in the original Vortex repository and
rebuild the paper there.

`DATA_NOTES_ZH.md` explains the data and limitations in Chinese. CSV links in
this copy point to the bundled snapshots under `pqc/results/`.
`provenance.json` contains their SHA-256 hashes and the numerical macros used
in the manuscript.

The snapshots preserve historical comments for audit. The final unified
ML-KEM table fixes the W32 half-bank NTT and cooperative arithmetic while
switching five Keccak backends. The matched XLEN tables compare Stage and
KROUND at RV32IM and RV64IM with F/D disabled, then compare six independent
NTT-only, NTT-plus-Stage, and NTT-plus-KROUND post-route implementations. All
six route without routing errors; RV64IM Stage and KROUND miss the 250 MHz
setup target and are labeled as timing misses. No board measurements or
activity-driven power measurements were produced.
