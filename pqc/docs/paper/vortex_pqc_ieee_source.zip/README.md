# IEEE manuscript source package

Open `main.tex` in Overleaf using pdfLaTeX, or run:

    latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex

This is an IEEEtran conference working draft, not a venue-specific submission.
The local build has 12 pages, 23 tables, 5 figures, and 11 references.
IEEEtran, TikZ, balance, and the other packages declared in `main.tex` are
supplied by a standard TeX Live installation and by Overleaf.

All generated `.tex` tables and four vector PDF plots are frozen in this
package. The fifth figure is drawn in `main.tex` using TikZ. Editing a CSV does
not update these tables automatically. To regenerate numerical content, use
`pqc/docs/paper/generate_results.py` in the original Vortex repository and
rebuild the paper there.

`DATA_NOTES_ZH.md` explains the data and limitations in Chinese. CSV links in
this copy point to the bundled snapshots under `pqc/results/`.
`provenance.json` records the 30 input-file SHA-256 hashes and numerical macros
used in the manuscript.

The W32 controls use RV32IM with F/D disabled. The PQRV, SG1/SG5/SG25,
and equal-unrolling controls use implementation snapshot 38c56304f. The SG5
synchronization follow-up adds SG5_SYNC=barrier at 1bd44cf34; SG5_SYNC=fence
remains the default. The historical synchronization matrix preserves all 31
pairs: 20 pass the unchanged 5% timing gate and 11 fail, with exact retired
instructions and correct numerical results throughout. Diagnostic patches
are included in pqc/results/keccak_sg5_sync_sources.zip.

The cache fill-forward correction at 6455855c2 is a separate experiment.
With the same warp-barrier binary, all 11 repeated release SimX/XRT pairs
pass numerical checks, exact instruction equality, and the unchanged 5%
whole-launch timing gate. The maximum launch gap is 4.23%; one isolated
permutation interval still differs by 5.63%. The cache unit regression covers
array depths, read/store ordering, response backpressure, and write-through
stores at fill arrival. Full fence-flush modeling remains incomplete;
historical SimX throughput tables are retained, while the new same-core XRT
controls are archived separately. Six matched XRT permutation mappings and
six complete ML-KEM backends have explicit KAT and instruction-count checks.
The new CSV and trace-evidence JSON preserve this distinction. The JSON
identifies local raw logs by path and hash; those large logs are not included
in this manuscript source package.

The snapshots also preserve historical comments for audit. The final unified
XRT ML-KEM table fixes the W32 half-bank NTT and cooperative arithmetic while
switching six Keccak mappings. The direct RV32IM W8T32 phase profile reports
mutually exclusive M1 intervals and preserves uninstrumented M1/M8 headlines.
The matched XLEN tables compare Stage and KROUND at RV32IM and RV64IM with F/D
disabled, including eight-request XRT KATs. Six independent NTT-only, NTT-plus-Stage, and
NTT-plus-KROUND post-route implementations. All six route without routing
errors; RV64IM Stage and KROUND miss the 250 MHz setup target and are labeled
as timing misses. No new synthesis, board measurements, or activity-driven
power measurements were produced for the W32 software controls.
