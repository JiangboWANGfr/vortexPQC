#!/usr/bin/env python3
import csv
import json
import re
import subprocess
import time
import traceback
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RUN = ROOT / "build32_im/tests/pqc"
STATUS = Path(__file__).with_name("m8_status.json")


def status(state, **values):
    STATUS.write_text(json.dumps({"state": state, **values}, indent=2) + "\n")


try:
    status("running", experiments=["c/xrt", "both/xrt"], inputs=list(range(1, 9)))
    while True:
        finished = 0
        for arm in ("c", "both"):
            timing = (RUN / f"mldsa_m8_{arm}/m8_xrt.time").read_text()
            code = re.search(r"^exit_status=(\d+)$", timing, re.MULTILINE)
            if code:
                assert int(code[1]) == 0, (arm, timing)
                finished += 1
        if finished == 2:
            break
        time.sleep(30)

    collector = ROOT / "pqc/results/collect_mldsa_pointwise_m8.py"
    result = subprocess.run(["python3", str(collector)], cwd=ROOT / "build32_im",
                            text=True, capture_output=True)
    Path(__file__).with_name("m8_collection.log").write_text(result.stdout + result.stderr)
    assert result.returncode == 0, result.stdout + result.stderr
    data_file = ROOT / "pqc/results/mldsa_pointwise_m8.csv"
    with data_file.open() as stream:
        rows = list(csv.DictReader(stream))
    batches = {(r["arm"], r["driver"]): r for r in rows if r["request_id"] == "0"}
    table = ["| Model | C/C makespan | Mapped makespan | Reduction |",
             "| --- | ---: | ---: | ---: |"]
    saved = {}
    for driver in ("simx", "xrt"):
        control = int(batches["c", driver]["makespan_cycles"])
        mapped = int(batches["both", driver]["makespan_cycles"])
        saved[driver] = 100 * (1 - mapped / control)
        table.append(f"| {driver} | {control:,} | {mapped:,} | {saved[driver]:.3f}% |")
    report = "\n".join(table) + "\n\n" + result.stdout
    report += "\nAll 32 request checks pass. Input IDs 1--8 exercise 8, 7, 2, 9, 3, 2, 11, and 8 signing attempts, respectively, derived from full-RAM L5 counts. These are concurrent request intervals, not isolated signing latencies.\n"
    Path(__file__).with_name("m8_summary.md").write_text(report)

    proposal = ROOT / "docs/proposals/mldsa_pointwise_mapping_proposal.md"
    old = "The fresh SimX control and mapped makespans are 77,528,313 and 68,096,270\ncycles. XRT results are pending."
    content = proposal.read_text()
    assert content.count(old) == 1
    proposal.write_text(content.replace(old, report.rstrip() + "\n\nStructured results are in `pqc/results/mldsa_pointwise_m8.csv`; the raw logs, build commands, launch manifest, and measured binaries are archived in `pqc/results/mldsa_pointwise_m8_sources.zip`."))

    paths = [collector, data_file, Path(__file__),
             Path(__file__).with_name("m8_run_manifest.json"),
             Path(__file__).with_name("m8_collection.log"),
             Path(__file__).with_name("m8_summary.md")]
    for arm in ("c", "both"):
        directory = RUN / f"mldsa_m8_{arm}"
        paths.extend(directory / f for f in ("m8_simx.log", "m8_xrt.log", "m8_simx.time", "m8_xrt.time", "kernel.vxbin", "mldsa_profile", "Makefile"))
        paths.append(Path(__file__).with_name(f"build_pointwise_m8_{arm}.log"))
    paths.extend(Path(__file__).parent / "runtime" / f for f in ("simx_config.stamp", "xrtsim_config.stamp"))
    with zipfile.ZipFile(ROOT / "pqc/results/mldsa_pointwise_m8_sources.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        for path in paths:
            archive.write(path, path.relative_to(ROOT))
    status("passed", request_checks=len(rows), batch_reduction_pct=saved,
           results=str(data_file.relative_to(ROOT)), model_checks=result.stdout.splitlines())
except Exception:
    status("failed", error=traceback.format_exc())
    raise
