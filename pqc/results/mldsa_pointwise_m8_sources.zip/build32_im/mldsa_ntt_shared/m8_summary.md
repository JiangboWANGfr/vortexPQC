| Model | C/C makespan | Mapped makespan | Reduction |
| --- | ---: | ---: | ---: |
| simx | 77,528,313 | 68,096,270 | 12.166% |
| xrt | 77,071,268 | 68,063,840 | 11.687% |

c: device_cycles model gap 0.593%
c: makespan_cycles model gap 0.593%
both: device_cycles model gap 0.056%
both: makespan_cycles model gap 0.048%
simx: M8 makespan reduction 12.166%
xrt: M8 makespan reduction 11.687%

All 32 request checks pass. Input IDs 1--8 exercise 8, 7, 2, 9, 3, 2, 11, and 8 signing attempts, respectively, derived from full-RAM L5 counts. These are concurrent request intervals, not isolated signing latencies.
