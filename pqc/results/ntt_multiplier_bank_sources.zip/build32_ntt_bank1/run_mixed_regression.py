import concurrent.futures,pathlib,subprocess
repo=pathlib.Path.cwd().parent
jobs=[(xlen,bank) for xlen in (32,64) for bank in (16,8,4,2)]
for xlen in (32,64):
    for bank in (16,4,2):
        build=repo/f"build{xlen}_ntt_bank{bank if bank < 8 else ''}"
        with (build/'configure_unit.log').open('w') as log:
            subprocess.run(['../configure',f'--xlen={xlen}','--tooldir=/home/jiangbowang/tools-pqc-v3.0.1'],cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
def run(job):
    xlen,bank=job
    build=repo/f"build{xlen}_ntt_bank{bank if bank < 8 else ''}"
    log=build/f'unit_kd_{bank}.log'
    with log.open('w') as out:
        subprocess.run(['make','-C','hw/unittest/pqc_unit','run-nttmul','ALU_LANES=32','THREADS=1',f'CONFIGS=-DSIMULATION -DVX_CFG_NTT_MUL_LANES={bank}',f'OBJ_DIR=obj_ntt_bank{bank}'],cwd=build,stdout=out,stderr=subprocess.STDOUT,check=True)
    assert 'PASSED' in log.read_text()
    print('PASS',xlen,bank,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    list(pool.map(run,jobs))
