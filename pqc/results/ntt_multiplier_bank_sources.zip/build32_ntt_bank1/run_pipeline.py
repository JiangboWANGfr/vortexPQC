import pathlib,subprocess
root=pathlib.Path.cwd()
for name in ('build_banks','build_apps','run_performance'):
    with (root/f'{name}.log').open('w') as log:
        subprocess.run(['python3','-u',f'{name}.py'],stdout=log,stderr=subprocess.STDOUT,check=True)
    print(name,'PASS',flush=True)
