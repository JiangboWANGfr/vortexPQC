import concurrent.futures, json, pathlib, subprocess
root = pathlib.Path.cwd()
repo = root.parent
def run(xlen):
    build = repo / f'build{xlen}_ntt_bank1'
    for kind, target, obj in (('kd', 'run-nttmul', 'obj_ntt_bank1'), ('d', 'run-nttmul-d', 'obj_ntt_d_bank1')):
        command = ['make', '-C', 'hw/unittest/pqc_unit', target, 'ALU_LANES=32', 'THREADS=1', 'CONFIGS=-DSIMULATION -DVX_CFG_NTT_MUL_LANES=1', f'OBJ_DIR={obj}']
        (build / f'unit_{kind}_1_command.json').write_text(json.dumps(command))
        with (build / f'unit_{kind}_1.log').open('w') as log:
            subprocess.run(command, cwd=build, stdout=log, stderr=subprocess.STDOUT, check=True)
        content = (build / f'unit_{kind}_1.log').read_text()
        assert 'PASSED' in content and '%Error' not in content
        print('PASS', xlen, kind, flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(run, (32,64)))
(root / 'units.done').write_text('PASS\n')
