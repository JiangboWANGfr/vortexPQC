module VX_pqc_nttmul import VX_gpu_pkg::*; #(
    parameter  INSTANCE_ID = "",
    parameter NUM_LANES = 1
) (
    input wire clk,
    input wire reset,
    VX_execute_if execute_if,
    VX_result_if result_if
);
    localparam TAG_WIDTH = $bits(alu_header_t);
    localparam LANE_BITS = ((($clog2(NUM_LANES)) > 0) ? ($clog2(NUM_LANES)) : 1);
    localparam NUM_MULTIPLIERS = (NUM_LANES + 1) / 2;
    localparam BEAT_WIDTH = TAG_WIDTH + 1 + 1 + 1 + 3 + 1 + 32 * NUM_MULTIPLIERS;
    function automatic logic [31:0] sign16(input logic [15:0] value);
        return {{16{value[15]}}, value};
    endfunction
    function automatic logic [15:0] k_mont_factor(input logic [15:0] value);
        return value - (value << 8) - (value << 10) - (value << 11);
    endfunction
    function automatic logic [15:0] k_mont_finish(
        input logic [31:0] product, input logic [15:0] factor
    );
        logic signed [31:0] f;
        logic signed [31:0] fq;
        begin
            f = $signed(sign16(factor));
            fq = f + (f <<< 8) + (f <<< 10) + (f <<< 11);
            return 16'($signed(product - fq) >>> 16);
        end
    endfunction
    function automatic logic [15:0] k_barrett_quotient(input logic [31:0] product);
        return 16'(($signed(product) + 32'sd33554432) >>> 26);
    endfunction
    function automatic logic [15:0] k_barrett_finish(
        input logic [15:0] value, input logic [15:0] quotient
    );
        logic signed [31:0] q;
        logic signed [31:0] qq;
        begin
            q = $signed(sign16(quotient));
            qq = q + (q <<< 8) + (q <<< 10) + (q <<< 11);
            return 16'($signed(sign16(value)) - qq);
        end
    endfunction
    wire valid_out;
    alu_header_t header_out;
    wire [NUM_LANES-1:0][32-1:0] data_out;
    wire advance = result_if.ready || ~valid_out;
    wire is_butterfly_in = execute_if.data.op_type == INST_ALU_NTTBF_K;
    wire is_d_in = execute_if.data.op_args.alu.imm20[4];
    wire is_gs_in = execute_if.data.op_args.alu.imm20[3];
    wire [2:0] stage_in = execute_if.data.op_args.alu.imm20[2:0];
    wire two_beats = (NUM_LANES > 1)
                   && (!is_butterfly_in || (!is_d_in && is_gs_in));
    wire [NUM_MULTIPLIERS-1:0][31:0] first_a, first_b, first_coefficients;
    wire [NUM_MULTIPLIERS-1:0][31:0] second_a, second_b, second_coefficients;
    for (genvar i = 0; i < NUM_MULTIPLIERS; ++i) begin : g_operands
        wire [4:0][31:0] pair_a, pair_b, pair_zeta;
        for (genvar s = 0; s < 5; ++s) begin : g_stage
            localparam LO = (i & ((1 << s) - 1)) | ((i >> s) << (s + 1));
            localparam HI = LO | (1 << s);
            if (HI < NUM_LANES) begin : g_pair
                assign pair_a[s] = execute_if.data.rs1_data[LO][31:0];
                assign pair_b[s] = execute_if.data.rs1_data[HI][31:0];
                assign pair_zeta[s] = execute_if.data.rs2_data[LO][31:0];
            end else begin : g_unused
                assign pair_a[s] = '0;
                assign pair_b[s] = '0;
                assign pair_zeta[s] = '0;
            end
        end
        wire [31:0] a = pair_a[stage_in];
        wire [31:0] b = pair_b[stage_in];
        assign first_a[i] = is_d_in
            ? (is_butterfly_in ? (is_gs_in ? a - b : b)
                               : execute_if.data.rs1_data[i][31:0])
            : (is_butterfly_in ? sign16(is_gs_in ? b[15:0] - a[15:0]
                                                : b[15:0])
                               : sign16(execute_if.data.rs1_data[i][15:0]));
        assign first_b[i] = is_d_in
            ? (is_butterfly_in ? pair_zeta[stage_in]
                               : execute_if.data.rs2_data[i][31:0])
            : (is_butterfly_in ? sign16(pair_zeta[stage_in][15:0])
                               : sign16(execute_if.data.rs2_data[i][15:0]));
        assign first_coefficients[i] = is_d_in
            ? (is_gs_in ? a + b : a) : sign16(a[15:0]);
        assign second_coefficients[i] = sign16(a[15:0] + b[15:0]);
        if (i + NUM_MULTIPLIERS < NUM_LANES) begin : g_second
            assign second_a[i] = is_butterfly_in
                ? second_coefficients[i]
                : (is_d_in ? execute_if.data.rs1_data[i + NUM_MULTIPLIERS][31:0]
                           : sign16(execute_if.data.rs1_data[i + NUM_MULTIPLIERS][15:0]));
            assign second_b[i] = is_butterfly_in ? 32'd20159
                : (is_d_in ? execute_if.data.rs2_data[i + NUM_MULTIPLIERS][31:0]
                           : sign16(execute_if.data.rs2_data[i + NUM_MULTIPLIERS][15:0]));
        end else begin : g_single
            assign second_a[i] = '0;
            assign second_b[i] = '0;
        end
    end
    reg pending_second;
    reg [NUM_MULTIPLIERS-1:0][31:0] saved_a, saved_b;
    reg [BEAT_WIDTH-1:0] saved_tag;
    always @(posedge clk) begin
        if (reset) begin
            pending_second <= 0;
        end else if (advance) begin
            if (pending_second) begin
                pending_second <= 0;
            end else if (execute_if.valid && two_beats) begin
                pending_second <= 1;
            end
        end
        if (advance && execute_if.valid && !pending_second && two_beats) begin
            saved_a <= second_a;
            saved_b <= second_b;
            saved_tag <= {execute_if.data.header, is_d_in, is_butterfly_in,
                          is_gs_in, stage_in, 1'b1, second_coefficients};
        end
    end
    wire [NUM_MULTIPLIERS-1:0][31:0] factor_a = pending_second ? saved_a : first_a;
    wire [NUM_MULTIPLIERS-1:0][31:0] factor_b = pending_second ? saved_b : first_b;
    wire [BEAT_WIDTH-1:0] tag_in = pending_second ? saved_tag
        : {execute_if.data.header, is_d_in, is_butterfly_in, is_gs_in,
           stage_in, !two_beats, first_coefficients};
    wire valid_operands;
    wire [BEAT_WIDTH-1:0] tag_operands;
    wire [NUM_MULTIPLIERS-1:0][31:0] operand_a, operand_b;
    VX_shift_register #(
        .DATAW (1 + BEAT_WIDTH + 64 * NUM_MULTIPLIERS),
        .DEPTH (1), .RESETW (1)
    ) operand_pipe (
        .clk (clk), .reset (reset), .enable (advance),
        .data_in ({pending_second || execute_if.valid, tag_in, factor_a, factor_b}),
        .data_out ({valid_operands, tag_operands, operand_a, operand_b})
    );
    wire valid_mul;
    alu_header_t header_mul;
    wire is_d_mul, is_butterfly_mul, is_gs_mul, last_mul;
    wire [2:0] stage_mul;
    wire [NUM_MULTIPLIERS-1:0][31:0] coefficients_mul;
    VX_shift_register #(
        .DATAW (1 + BEAT_WIDTH),
        .DEPTH (3 - 1),
        .RESETW (1)
    ) tag_pipe (
        .clk (clk), .reset (reset), .enable (advance),
        .data_in ({valid_operands, tag_operands}),
        .data_out ({valid_mul, header_mul, is_d_mul, is_butterfly_mul, is_gs_mul,
                    stage_mul, last_mul, coefficients_mul})
    );
    wire probe_request_valid = execute_if.valid;
    wire probe_request_ready = execute_if.ready;
    wire [NUM_LANES-1:0] probe_request_mask = execute_if.data.header.tmask;
    wire [NUM_MULTIPLIERS-1:0][63:0] product_out;
    for (genvar i = 0; i < NUM_MULTIPLIERS; ++i) begin : g_multiplier
        VX_multiplier #(
            .A_WIDTH (32), .B_WIDTH (32), .R_WIDTH (64),
            .SIGNED (1), .LATENCY (3 - 1)
        ) multiplier (
            .clk (clk), .enable (advance),
            .dataa (operand_a[i]), .datab (operand_b[i]),
            .result (product_out[i])
        );
    end
    wire valid_factor;
    alu_header_t header_factor;
    wire is_d_factor, is_butterfly_factor, is_gs_factor, last_factor;
    wire [2:0] stage_factor;
    wire [NUM_MULTIPLIERS-1:0][31:0] coefficients_factor, mont_factor;
    wire [NUM_MULTIPLIERS-1:0][31:0] k_factor;
    wire [NUM_MULTIPLIERS-1:0][63:0] product_factor;
    wire [NUM_MULTIPLIERS-1:0][31:0] mont_factor_in;
    wire [NUM_MULTIPLIERS-1:0][31:0] k_factor_in;
    for (genvar i = 0; i < NUM_MULTIPLIERS; ++i) begin : g_factor
        assign mont_factor_in[i] = product_out[i][31:0] * 32'd58728449;
        assign k_factor_in[i] = {k_barrett_quotient(product_out[i][31:0]),
                                 k_mont_factor(product_out[i][15:0])};
    end
    VX_shift_register #(
        .DATAW (1 + BEAT_WIDTH + 128 * NUM_MULTIPLIERS),
        .DEPTH (1), .RESETW (1)
    ) factor_pipe (
        .clk (clk), .reset (reset), .enable (advance),
        .data_in ({valid_mul, header_mul, is_d_mul, is_butterfly_mul, is_gs_mul,
                   stage_mul, last_mul, coefficients_mul, product_out,
                   mont_factor_in, k_factor_in}),
        .data_out ({valid_factor, header_factor, is_d_factor,
                    is_butterfly_factor, is_gs_factor, stage_factor, last_factor,
                    coefficients_factor, product_factor, mont_factor, k_factor})
    );
    wire valid_reduce;
    alu_header_t header_reduce;
    wire is_d_reduce, is_butterfly_reduce, is_gs_reduce, last_reduce;
    wire [2:0] stage_reduce;
    wire [NUM_MULTIPLIERS-1:0][31:0] coefficients_reduce, montgomery;
    wire [NUM_MULTIPLIERS-1:0][31:0] montgomery_in, barrett_in, barrett_reduce;
    for (genvar i = 0; i < NUM_MULTIPLIERS; ++i) begin : g_reduce
        wire signed [63:0] tq = $signed(mont_factor[i]) * 64'sd8380417;
        wire signed [63:0] difference = $signed(product_factor[i]) - tq;
        assign montgomery_in[i] = is_d_factor ? difference[63:32]
            : sign16(k_mont_finish(product_factor[i][31:0], k_factor[i][15:0]));
        assign barrett_in[i] = sign16(k_barrett_finish(
            coefficients_factor[i][15:0], k_factor[i][31:16]));
    end
    VX_shift_register #(
        .DATAW (1 + BEAT_WIDTH + 64 * NUM_MULTIPLIERS),
        .DEPTH (1), .RESETW (1)
    ) reduction_pipe (
        .clk (clk), .reset (reset), .enable (advance),
        .data_in ({valid_factor, header_factor, is_d_factor, is_butterfly_factor,
                   is_gs_factor, stage_factor, last_factor,
                   coefficients_factor, montgomery_in, barrett_in}),
        .data_out ({valid_reduce, header_reduce, is_d_reduce, is_butterfly_reduce,
                    is_gs_reduce, stage_reduce, last_reduce,
                    coefficients_reduce, montgomery, barrett_reduce})
    );
    reg [NUM_MULTIPLIERS-1:0][31:0] partial_results;
    always @(posedge clk) begin
        if (advance && valid_reduce && !last_reduce)
            partial_results <= montgomery;
    end
    wire [NUM_LANES-1:0][32-1:0] data_reduce;
    for (genvar i = 0; i < NUM_LANES; ++i) begin : g_result
        wire [4:0][31:0] butterfly;
        for (genvar s = 0; s < 5; ++s) begin : g_stage
            localparam BANK = (i & ((1 << s) - 1)) | ((i >> (s + 1)) << s);
            if (BANK < NUM_MULTIPLIERS) begin : g_pair
                wire [31:0] low_d = is_gs_reduce ? coefficients_reduce[BANK]
                    : coefficients_reduce[BANK] + montgomery[BANK];
                wire [31:0] high_d = is_gs_reduce ? montgomery[BANK]
                    : coefficients_reduce[BANK] - montgomery[BANK];
                wire [31:0] low_k = is_gs_reduce ? barrett_reduce[BANK]
                    : sign16(coefficients_reduce[BANK][15:0] + montgomery[BANK][15:0]);
                wire [31:0] high_k = is_gs_reduce ? partial_results[BANK]
                    : sign16(coefficients_reduce[BANK][15:0] - montgomery[BANK][15:0]);
                assign butterfly[s] = (i & (1 << s)) != 0
                    ? (is_d_reduce ? high_d : high_k)
                    : (is_d_reduce ? low_d : low_k);
            end else begin : g_unused
                assign butterfly[s] = '0;
            end
        end
        wire [31:0] nttmul;
        if (NUM_LANES == 1) begin : g_single
            assign nttmul = montgomery[i];
        end else if (i < NUM_MULTIPLIERS) begin : g_first
            assign nttmul = partial_results[i];
        end else begin : g_second
            assign nttmul = montgomery[i - NUM_MULTIPLIERS];
        end
        assign data_reduce[i] = 32'($signed(
            is_butterfly_reduce ? butterfly[stage_reduce] : nttmul));
    end
    VX_shift_register #(
        .DATAW (1 + TAG_WIDTH + 32 * NUM_LANES),
        .DEPTH (1), .RESETW (1)
    ) result_pipe (
        .clk (clk), .reset (reset), .enable (advance),
        .data_in ({valid_reduce && last_reduce, header_reduce, data_reduce}),
        .data_out ({valid_out, header_out, data_out})
    );
    assign execute_if.ready = advance && !pending_second;
    assign result_if.valid = valid_out;
    assign result_if.data.header = header_out;
    assign result_if.data.data = data_out;
endmodule
