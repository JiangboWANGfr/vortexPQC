import concurrent.futures, hashlib, json, os, pathlib, subprocess, time
root = pathlib.Path.cwd()
repo = root.parent
jobs = [(scheme, bank, batch, driver)
        for driver in ('simx', 'xrt')
        for scheme, batch in (('mldsa',8), ('mldsa',1), ('mlkem',8), ('mlkem',1))
        for bank in (4,)]
files = {}
def add(path):
    files[str(path.relative_to(repo))] = hashlib.sha256(path.read_bytes()).hexdigest()
for bank in (4,):
    for name in ('libsimx.so','libxrtsim.so','libvortex.so','libvortex-simx.so','libvortex-xrt.so','simx_config.stamp','xrtsim_config.stamp'):
        add(root/f'bank{bank}/runtime'/name)
    for scheme in ('mlkem','mldsa'):
        for name in ('kernel.vxbin',f'{scheme}_profile'):
            add(root/f'tests/pqc/{scheme}_bank{bank}'/name)
        for binary in ('kernel.vxbin', f'{scheme}_profile'):
            assert (root/f'tests/pqc/{scheme}_bank4'/binary).read_bytes() == (repo/f'build32_ntt_bank/tests/pqc/{scheme}_bank8'/binary).read_bytes()
for name in ('hw/rtl/pqc/VX_pqc_nttmul.sv','sim/simx/alu_unit.cpp','sim/simx/alu_unit.h','VX_config.toml'):
    add(repo/name)
prior = json.loads((repo/'build32_ntt_bank/run_manifest.json').read_text())
for name in ('hw/rtl/pqc/VX_pqc_nttmul.sv','sim/simx/alu_unit.cpp','sim/simx/alu_unit.h','VX_config.toml'):
    assert files[name] == prior['files'][name], name
(root/'run_manifest.json').write_text(json.dumps({'files':files,'jobs':jobs},indent=2)+'\n')
def run(job):
    scheme, bank, batch, driver = job
    directory = root/f'bank{bank}'
    app = root/f'tests/pqc/{scheme}_bank{bank}'
    command = [f'./{scheme}_profile',f'-b{batch}'] + (['-t32'] if scheme=='mlkem' else [f'-s{0 if batch==1 else 1}'])
    env = dict(os.environ, LD_LIBRARY_PATH=str(directory/'runtime'), VORTEX_DRIVER=driver, XRT_DEVICE='xrtsim', VORTEX_PROFILING='0')
    stem = f'{scheme}_m{batch}_{driver}'
    status = {'argv':command,'cwd':str(app), 'start':time.time(), 'state':'running'}
    (directory/f'{stem}.json').write_text(json.dumps(status,indent=2)+'\n')
    with (directory/f'{stem}.log').open('w') as log:
        result = subprocess.run(command,cwd=app,env=env,stdout=log,stderr=subprocess.STDOUT)
    status.update(end=time.time(),exit_code=result.returncode,state='finished')
    (directory/f'{stem}.json').write_text(json.dumps(status,indent=2)+'\n')
    assert result.returncode == 0, (job,result.returncode)
    assert (directory/f'{stem}.log').read_text().endswith('PASSED!\n'),job
    print('PASS', job, flush=True)
# Four RTL processes bound CPU and memory use; each model uses independent files.
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    list(pool.map(run, jobs))
(root/'performance.done').write_text('PASS\n')
