import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import time

repo = pathlib.Path.cwd().parent
env = dict(os.environ, XILINX_VIVADO='/data/Xilinx/2025.1/Vivado',
           CLK_FREQ_MHZ='250', OPT_LEVEL='3')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


for bank in (4, 2, 1):
    build = repo / f'build32_ntt_bank{bank}'
    base = build / 'hw/syn/xilinx/dut'
    directory = base / f'v80_rv32im_ntt_bank{bank}_core'
    assert not directory.exists(), directory
    directory.mkdir()
    shutil.copy2(base / 'build.mk', directory / 'Makefile')
    flags = (f'-DVX_CFG_EXT_F_DISABLE -DVX_CFG_EXT_D_DISABLE '
             f'-DVX_CFG_EXT_NTT_ENABLE -DVX_CFG_NUM_WARPS=8 '
             f'-DVX_CFG_NUM_THREADS=32 -DVX_CFG_NTT_MUL_LANES={bank}')
    command = [
        'make', '-C', str(directory), 'DUT=core',
        'DEVICE=xcv80-lsva4737-2MHP-e-S', 'MAX_JOBS=4', 'OPT_LEVEL=3',
        f'CONFIGS={flags}', 'build'
    ]
    status = {
        'argv': command,
        'env': {key: env[key] for key in
                ('XILINX_VIVADO', 'CLK_FREQ_MHZ', 'OPT_LEVEL')},
        'git_head': subprocess.check_output(
            ['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
        'sources': {
            name: digest(repo / name) for name in
            ('VX_config.toml', 'hw/rtl/pqc/VX_pqc_nttmul.sv')
        },
        'start': time.time(),
        'state': 'running'
    }
    (directory / 'command.json').write_text(json.dumps(status, indent=2) + '\n')
    with (directory / 'build.log').open('w') as log:
        result = subprocess.run(command, env=env, stdout=log,
                                stderr=subprocess.STDOUT)
    status.update(end=time.time(), exit_code=result.returncode, state='finished')
    (directory / 'command.json').write_text(json.dumps(status, indent=2) + '\n')
    result.check_returncode()
    (directory / 'build.done').write_text('PASS\n')
    print('PASS', bank, flush=True)
