import json, os, pathlib, shutil, subprocess
root = pathlib.Path.cwd()
base = root / 'hw/syn/xilinx/dut'
env = dict(os.environ, XILINX_VIVADO='/data/Xilinx/2025.1/Vivado', CLK_FREQ_MHZ='250', OPT_LEVEL='3')
for bank in (8,16):
    directory = base / f'v80_rv32im_ntt_bank{bank}_core'
    directory.mkdir(exist_ok=True)
    shutil.copy2(base/'build.mk', directory/'Makefile')
    flags = f'-DVX_CFG_EXT_F_DISABLE -DVX_CFG_EXT_D_DISABLE -DVX_CFG_EXT_NTT_ENABLE -DVX_CFG_NUM_WARPS=8 -DVX_CFG_NUM_THREADS=32 -DVX_CFG_NTT_MUL_LANES={bank}'
    command = ['make','-C',str(directory),'DUT=core','DEVICE=xcv80-lsva4737-2MHP-e-S','MAX_JOBS=4','OPT_LEVEL=3',f'CONFIGS={flags}','build']
    (directory/'command.json').write_text(json.dumps({'argv':command,'env':{k:env[k] for k in ('XILINX_VIVADO','CLK_FREQ_MHZ','OPT_LEVEL')}}))
    with (directory/'build.log').open('w') as log:
        subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    (directory/'build.done').write_text('PASS\n')
