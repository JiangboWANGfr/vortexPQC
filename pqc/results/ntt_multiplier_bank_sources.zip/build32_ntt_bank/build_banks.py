import concurrent.futures, json, os, pathlib, shutil, subprocess
root = pathlib.Path.cwd()
base = root.parent
configs = '-DVX_CFG_EXT_F_DISABLE -DVX_CFG_EXT_D_DISABLE -DVX_CFG_EXT_PQC_ENABLE -DVX_CFG_EXT_NTT_ENABLE -DVX_CFG_EXT_KSG25_ENABLE -DVX_CFG_EXT_KROUND25_ENABLE -DVX_CFG_NUM_WARPS=8 -DVX_CFG_NUM_THREADS=32'
archived = base / 'build32_im/mldsa_ntt_shared/runtime'
def build(bank):
    directory = root / f'bank{bank}'
    runtime = directory / 'runtime'
    runtime.mkdir(parents=True, exist_ok=True)
    for name in ('libvortex.so', 'libvortex-simx.so', 'libvortex-xrt.so'):
        shutil.copy2(archived / name, runtime / name)
    flags = f'{configs} -DVX_CFG_NTT_MUL_LANES={bank}'
    for target in ('simx', 'xrtsim'):
        command = ['make', '-C', f'sim/{target}', '-j4', f'DESTDIR={runtime}', f'CONFIGS={flags}', 'JOBS=4']
        (directory / f'{target}_command.json').write_text(json.dumps(command))
        with (directory / f'build_{target}.log').open('w') as log:
            subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)
    (directory / 'build.done').write_text('PASS\n')
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
    list(executor.map(build, (8, 16)))
