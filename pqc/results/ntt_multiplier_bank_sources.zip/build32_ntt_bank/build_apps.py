import json, os, pathlib, shutil, subprocess
root = pathlib.Path.cwd()
base = root.parent
flags = '-DVX_CFG_EXT_F_DISABLE -DVX_CFG_EXT_D_DISABLE -DVX_CFG_EXT_PQC_ENABLE -DVX_CFG_EXT_NTT_ENABLE -DVX_CFG_EXT_KSG25_ENABLE -DVX_CFG_EXT_KROUND25_ENABLE -DVX_CFG_NUM_WARPS=8 -DVX_CFG_NUM_THREADS=32'
env = dict(os.environ, LIBC_PATH=str(base.parent/'toolchains-im/libc32'), LIBCRT_PATH=str(base.parent/'toolchains-im/libcrt32'))
def run(cmd, log):
    with (root/log).open('w') as out:
        subprocess.run(cmd, env=env, stdout=out, stderr=subprocess.STDOUT, check=True)
run(['make','-C','sw/kernel','-j4',f'CONFIGS={flags}'], 'build_kernel.log')
shutil.copy2(base/'build32_im/mldsa_ntt_shared/runtime/libvortex.so',root/'sw/runtime/libvortex.so')
for bank in (8,16):
    runtime = root/f'bank{bank}/runtime'
    run(['make','-C','sim/simx','-j4',f'DESTDIR={runtime}',f'CONFIGS={flags} -DVX_CFG_NTT_MUL_LANES={bank}', str(runtime/'libsimx.so')],f'bank{bank}/build_libsimx.log')
    for scheme in ('mlkem','mldsa'):
        app = root/f'tests/pqc/{scheme}_bank{bank}'
        app.mkdir(exist_ok=True)
        shutil.copy2(root/f'tests/pqc/{scheme}_profile/Makefile',app/'Makefile')
        cmd = ['make','-C',str(app),'-j4',f'CONFIGS={flags} -DVX_CFG_NTT_MUL_LANES={bank}', 'KECCAK=pe','NTT=reg32','NTTMUL=ise','NTTBF=ise']
        cmd += ['SERIAL=1','ARITH=all','ARITH_MUL=ise'] if scheme=='mlkem' else ['MLDSA_RAM=full','POINTWISE=ise','POINTWISE_L5=w32']
        (root/f'bank{bank}/{scheme}_command.json').write_text(json.dumps(cmd))
        run(cmd,f'bank{bank}/build_{scheme}.log')
(root/'apps.done').write_text('PASS\n')
