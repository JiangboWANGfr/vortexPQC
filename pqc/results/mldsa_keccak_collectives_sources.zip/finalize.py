import csv
import hashlib
import json
import subprocess
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

base = Path(__file__).resolve().parent
root = base.parent.parent
manifest = json.loads((base / "manifest.json").read_text())
subprocess.run([sys.executable, str(base / "summarize.py")], check=True)
expected = manifest["expected_xrt_runs"]
passed, pending, failed = [], [], []
for name in expected:
    data = (base / name).read_text() if (base / name).exists() else ""
    if data.rstrip().endswith("PASSED!"):
        passed.append(name)
    elif "FAILED!" in data or "Assertion" in data or "FAIL " in data:
        failed.append(name)
    elif not Path("/proc", str(manifest["xrt_processes"][name])).exists():
        failed.append(name)
    else:
        pending.append(name)
parity = json.loads((base / "parity.json").read_text())
status = dict(updated_utc=datetime.now(timezone.utc).isoformat(),
              state="running" if pending else "failed" if failed else "complete",
              completed_xrt=passed, pending_xrt=pending, failed_xrt=failed,
              comparisons=parity, tolerance_percent=5.0,
              comparison_outliers=[r for r in parity if not r["exact_instructions"] or r["cycle_gap_percent"] > 5],
              scope="ML-DSA-65 native x1 Keccak hooks; software NTT; RV32IM W8T32",
              manifest=manifest)
results = root / "pqc/results"
results.mkdir(exist_ok=True)
for name, data in [("mldsa_keccak_collectives.csv", (base/"results.csv").read_text()),
                   ("mldsa_keccak_collectives_status.json", json.dumps(status, indent=2)+"\n")]:
    target = results / name
    temporary = target.with_suffix(target.suffix + ".tmp")
    temporary.write_text(data)
    temporary.replace(target)
rows = list(csv.DictReader((base / "results.csv").open()))
single = {(r["backend"], r["driver"]): r for r in rows if r["requests"] == "1" and r["first_input"] == "0"}
section = "\n## Current validation results\n\n"
section += "Status: **" + status["state"] + "**. Only completed, byte-verified runs enter the CSV.\n"
section += "XRT results are full AFU integration simulation; SimX rows are not RTL measurements.\n\n"
section += "| Backend | SimX M1 kernel cycles | XRT M1 kernel cycles | XRT speedup over C |\n|---|---:|---:|---:|\n"
for arm in ["c", "shuffle", "stage", "round", "pointer"]:
    sim = single.get((arm, "simx"))
    rtl = single.get((arm, "xrt"))
    ref = single.get(("c", "xrt"))
    speed = f'{int(ref["total_cycles"])/int(rtl["total_cycles"]):.4f}x' if ref and rtl else "pending"
    section += f'| {arm} | {int(sim["total_cycles"]):,} | {format(int(rtl["total_cycles"]), ",") if rtl else "pending"} | {speed} |\n'
section += "\nStage and Round pass SimX M8 with input IDs 0--7, and both pass M2 with IDs 1--2.\n"
section += "Stage low-RAM M2 also passes; its arena peak is 14,624 B of 24,576 B.\n"
section += "The lane-request ML-DSA baseline passes its two-request SimX regression.\n"
section += f'XRT runs completed: {len(passed)}/{len(expected)}; pending: {len(pending)}; failed: {len(failed)}.\n'
if parity:
    section += "\n| Arm / batch / first input | Exact retired instructions | Launch cycle gap vs XRT |\n|---|---|---:|\n"
    for row in parity:
        section += f'| {row["backend"]} / {row["requests"]} / {row["first_input"]} | {row["exact_instructions"]} | {row["cycle_gap_percent"]:.3f}% |\n'
    section += "\nA gap above 5% remains an unresolved model-comparison result; no tolerance is widened.\n"
section += "\nResults: `pqc/results/mldsa_keccak_collectives.csv`. Status, configuration, hashes and model comparisons: `pqc/results/mldsa_keccak_collectives_status.json`.\n"
section += "Raw logs, source snapshot, implementation patch, host allocator harness and reproduction commands: `pqc/results/mldsa_keccak_collectives_sources.zip`.\n"
section += "The original and DAC paper sources are unchanged. No synthesis, commit or push is performed by this experiment.\n"
doc = root / "docs/proposals/mldsa_keccak_collectives_proposal.md"
marker = "\n<!-- generated-results -->\n"
doc.write_text(doc.read_text().split(marker)[0] + marker + section)
archive = results / "mldsa_keccak_collectives_sources.zip"
tmp = archive.with_suffix(".zip.tmp")
with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED) as out:
    for name in ["manifest.json", "implementation.patch", "reproduce.sh", "summarize.py", "finalize.py", "monitor.py", "results.csv", "parity.json", "ci_collect.log", "lane_baseline_simx_m2.log", "validation_checks.log"]:
        path = base / name
        if path.exists(): out.write(path, name)
    out.writestr("status.json", json.dumps(status, indent=2)+"\n")
    for path in sorted((base / "source_snapshot").rglob("*")):
        if path.is_file(): out.write(path, str(path.relative_to(base)))
    for path in sorted((base / "fixed").glob("*/*")):
        if path.name in ["kernel.elf", "kernel.vxbin", "kernel.dump", "mldsa_profile"]:
            out.write(path, str(path.relative_to(base)))
    for path in sorted(base.glob("fixed_*.log")):
        if path.read_text().rstrip().endswith("PASSED!"):
            out.write(path, "logs/"+path.name)
    for path in sorted((base / "allocator_check").iterdir()):
        if path.suffix in [".h", ".cpp", ".log"]:
            out.write(path, "allocator_check/"+path.name)
    for name in ["c_simx_m1_s1_allocator_repro.log", "stage_simx_m8_s0.log"]:
        out.write(base / name, "allocator_regression_before_fix/"+name)
    for path in sorted((base / "runtime").glob("*.stamp")):
        out.write(path, "runtime_configuration/"+path.name)
    out.write(doc, "mldsa_keccak_collectives_proposal.md")
with zipfile.ZipFile(tmp) as check:
    assert check.testzip() is None
    assert "status.json" in check.namelist()
tmp.replace(archive)
print(f'Archive updated: {status["state"]}; {len(passed)}/{len(expected)} XRT runs complete')
