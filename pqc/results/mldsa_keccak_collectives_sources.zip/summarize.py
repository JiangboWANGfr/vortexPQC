import csv
import hashlib
import json
import re
from pathlib import Path

base = Path(__file__).resolve().parent
manifest = json.loads((base / "manifest.json").read_text())
rows = []
runs = {}
for log in sorted(base.glob("fixed_*.log")):
    match = re.fullmatch(r"fixed_(\w+)_(simx|xrt)_m(\d+)_s(\d+)\.log", log.name)
    if not match:
        continue
    arm, driver, batch, first = match.groups()
    data = log.read_text()
    if not data.rstrip().endswith("PASSED!"):
        continue
    assert "***" not in data, log
    batch, first = int(batch), int(first)
    b = re.search(r"BATCH: requests=(\d+) first_input=(\d+) makespan=(\d+)", data)
    assert b and tuple(map(int, b.groups()[:2])) == (batch, first), log
    perf = re.search(r"PERF: instrs=(\d+), cycles=(\d+)", data)
    assert perf, log
    chunks = re.split(r"REQUEST: id=(\d+) input=(\d+)\n", data)[1:]
    assert len(chunks) == 3 * batch, log
    actual = []
    for req, input_id, chunk in zip(chunks[0::3], chunks[1::3], chunks[2::3]):
        assert "REFERENCE: pk/sk/signature match portable C byte-for-byte" in chunk, log
        req, input_id = int(req), int(input_id)
        assert input_id == first + req
        cycles = re.search(r"CYCLES: keypair=(\d+) sign=(\d+) verify=(\d+) total=(\d+)", chunk)
        assert cycles
        phase = list(map(int, cycles.groups()))
        assert sum(phase[:3]) == phase[3] and min(phase) > 0
        memory = re.search(r"STACK: peak=(\d+) of (\d+) paintable \(slab (\d+)\)   ARENA: peak=(\d+) of (\d+) fail=(\d+)", chunk)
        assert memory
        stack, paint, slab, arena, capacity, fail = map(int, memory.groups())
        assert 0 < stack < paint <= slab and 0 < arena <= capacity and fail == 0
        counts = [int(re.search(r"^" + key + r"\s+(\d+)$", chunk, re.M)[1]) for key in ("keccak_f1600_x1", "keccak_f1600_x4", "poly_ntt", "poly_invntt", "rej_uniform")]
        actual.append((input_id, counts))
        row = dict(backend=arm, driver=driver, xlen=32, f_enabled=0, d_enabled=0,
                   cores=1, warps=8, threads=32, ram="low" if arm.endswith("_low") else "full",
                   requests=batch, first_input=first, request=req, input_id=input_id,
                   keypair_cycles=phase[0], sign_cycles=phase[1], verify_cycles=phase[2], total_cycles=phase[3],
                   batch_makespan=int(b[3]), retired_instructions=int(perf[1]), launch_cycles=int(perf[2]),
                   keccak_x1=counts[0], keccak_x4=counts[1], ntt=counts[2], intt=counts[3], rej_uniform=counts[4],
                   stack_peak=stack, arena_peak=arena, arena_capacity=capacity,
                   elf_sha256=manifest["arm_hashes"]["fixed/"+arm+"/kernel.elf"],
                   log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(), raw_log="logs/"+log.name)
        rows.append(row)
    runs[arm, driver, batch, first] = (int(perf[1]), int(perf[2]), int(b[3]), actual)
by_input = {}
for row in rows:
    key = row["ram"], row["input_id"]
    counts = tuple(row[name] for name in ("keccak_x1", "keccak_x4", "ntt", "intt", "rej_uniform"))
    assert key not in by_input or by_input[key] == counts, (key, "backend changes primitive counts")
    by_input[key] = counts
if rows:
    with (base / "results.csv").open("w") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0])
        writer.writeheader()
        writer.writerows(rows)
parity = []
for (arm, driver, batch, first), result in runs.items():
    if driver != "xrt" or (arm, "simx", batch, first) not in runs:
        continue
    sim = runs[arm, "simx", batch, first]
    assert sim[3] == result[3], (arm, "call counts differ")
    parity.append(dict(backend=arm, requests=batch, first_input=first,
                       exact_instructions=sim[0] == result[0], simx_instructions=sim[0], xrt_instructions=result[0],
                       simx_launch_cycles=sim[1], xrt_launch_cycles=result[1],
                       cycle_gap_percent=100*abs(sim[1]-result[1])/result[1],
                       kernel_gap_percent=100*abs(sim[2]-result[2])/result[2]))
(base / "parity.json").write_text(json.dumps(parity, indent=2)+"\n")
print(f"{len(runs)} completed runs, {len(rows)} verified requests, {len(parity)} model comparisons")
for row in parity:
    print(row)
