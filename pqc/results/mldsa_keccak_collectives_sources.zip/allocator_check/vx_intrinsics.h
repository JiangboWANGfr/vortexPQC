static unsigned mock_hart;
static inline unsigned vx_hart_id(void) { return mock_hart; }
