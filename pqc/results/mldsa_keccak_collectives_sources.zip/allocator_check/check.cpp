#include <cassert>
#include <cstdio>
#include <cstring>
#define __VORTEX__
#define MLD_CONFIG_FILE "vortex_mldsa_config.h"
extern "C" {
#include "mldsa_native.c"
}
#include "host_reference.h"
int main() {
  mock_hart = 0;
  auto outer = (uint8_t*)mld_arena_alloc(34);
  memset(outer, 0xa5, 34);
  for (unsigned n = 0; n < 10000; ++n) {
    auto a = mld_arena_alloc(97);
    auto b = mld_arena_alloc(1024);
    assert(a && b && ((uintptr_t)a % 32) == 0);
    mld_arena_free(b, 1024);
    mld_arena_free(a, 97);
    assert(mld_arena_top[mld_arena_index()] == 64);
    for (unsigned i = 0; i < 34; ++i) assert(outer[i] == 0xa5);
  }
  auto rest = mld_arena_alloc(MLD_ARENA_BYTES - 64);
  assert(rest && !mld_arena_alloc(1));
  assert(mld_arena_fail[mld_arena_index()] == 1);
  mld_arena_free(rest, MLD_ARENA_BYTES - 64);
  mld_arena_free(outer, 34);
  assert(mld_arena_top[mld_arena_index()] == 0);
  mld_arena_fail[mld_arena_index()] = 0;
  uint8_t seed[32], rnd[32], msg[32];
  uint8_t pk[1952], sk[4032], sig[3309], ref_pk[1952], ref_sk[4032], ref_sig[3309];
  for (unsigned id = 0; id < 64; ++id) {
    mock_hart = (id & 1) * VX_CFG_NUM_THREADS;
    uint32_t state = id;
    auto next = [&]() {state ^= state << 13; state ^= state >> 17; state ^= state << 5; return uint8_t(state);};
    for (unsigned i = 0; i < 32; ++i) seed[i] = id ? next() : i + 1;
    for (unsigned i = 0; i < 32; ++i) rnd[i] = id ? next() : 0x40 + i;
    for (unsigned i = 0; i < 32; ++i) msg[i] = id ? next() : 0x80 + i;
    assert(mldsa_keypair_internal(pk, sk, seed) == 0);
    assert(mld_arena_top[mld_arena_index()] == 0);
    assert(mldsa_signature_internal(sig, msg, 32, nullptr, 0, rnd, sk, 0) == 0);
    assert(mld_arena_top[mld_arena_index()] == 0);
    assert(mldsa_verify_internal(sig, msg, 32, nullptr, 0, pk, 0) == 0);
    assert(mld_arena_top[mld_arena_index()] == 0);
    assert(mld_arena_fail[mld_arena_index()] == 0);
    assert(mldsa_host_reference(seed, rnd, msg, 32, ref_pk, ref_sk, ref_sig) == 0);
    assert(memcmp(pk, ref_pk, sizeof pk) == 0);
    assert(memcmp(sk, ref_sk, sizeof sk) == 0);
    assert(memcmp(sig, ref_sig, sizeof sig) == 0);
  }
  printf("PASS: 10000 nested reuses, aligned allocation, OOM cleanup, 64 exact signatures; peak=%u capacity=%u\n", mld_arena_peak[0], MLD_ARENA_BYTES);
}
