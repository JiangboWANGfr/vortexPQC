import json
import subprocess
import sys
import time
from pathlib import Path

base = Path(__file__).resolve().parent
root = base.parent.parent
manifest = json.loads((base / "manifest.json").read_text())
last = None
while True:
    snapshot = [(name, (base / name).stat().st_size,
                 Path("/proc", str(pid)).exists())
                for name, pid in manifest["xrt_processes"].items()]
    if snapshot != last:
        result = subprocess.run([sys.executable, str(base / "finalize.py")])
        status_file = root / "pqc/results/mldsa_keccak_collectives_status.json"
        status = json.loads(status_file.read_text())
        if result.returncode:
            status["state"] = "analysis_failed"
            status["analysis_log"] = str(base / "monitor.log")
            status_file.write_text(json.dumps(status, indent=2)+"\n")
            sys.exit(result.returncode)
        if status["state"] != "running":
            break
        last = snapshot
    time.sleep(60)
