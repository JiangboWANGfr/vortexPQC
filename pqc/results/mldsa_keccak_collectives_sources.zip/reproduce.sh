#!/usr/bin/env bash
set -euo pipefail
# Run from a configured RV32 build tree after applying the archived source patch.
test -f config.mk
: "${LIBC_PATH:?set LIBC_PATH to the RV32IM soft-float libc}"
: "${LIBCRT_PATH:?set LIBCRT_PATH to the RV32IM soft-float libcrt}"
export CONFIGS="-DVX_CFG_EXT_F_DISABLE -DVX_CFG_EXT_D_DISABLE -DVX_CFG_EXT_PQC_ENABLE -DVX_CFG_EXT_NTT_ENABLE -DVX_CFG_EXT_KSG25_ENABLE -DVX_CFG_EXT_KROUND25_ENABLE -DVX_CFG_NUM_WARPS=8 -DVX_CFG_NUM_THREADS=32"
vortex_source=$(sed -n 's/^VORTEX_HOME ?= //p' config.mk)
"$vortex_source/configure"
output="$PWD/mldsa_collectives_reproduced"
mkdir -p "$output/runtime"
make -s -B -C sw/kernel
make -s -C sw/runtime/stub DESTDIR="$output/runtime"
make -s -C sw/runtime/simx DESTDIR="$output/runtime"
make -s -C sw/runtime/xrt DESTDIR="$output/runtime"
unset ABLATE KECCAK UNROLL MLDSA_RAM
for arm in c shuffle stage round pointer; do
    opts=(MLDSA_RAM=full)
    case "$arm" in
        c) opts+=(KECCAK=sg1) ;;
        shuffle) opts+=(KECCAK=sg25_sw UNROLL=1) ;;
        stage) opts+=(KECCAK=sg25 UNROLL=1) ;;
        round) opts+=(KECCAK=kround) ;;
        pointer) opts+=(KECCAK=pe) ;;
    esac
    make -s -C tests/pqc/mldsa_profile "${opts[@]}"
    mkdir -p "$output/$arm"
    cp tests/pqc/mldsa_profile/{mldsa_profile,kernel.elf,kernel.vxbin} "$output/$arm/"
    for driver in simx xrt; do
        (cd "$output/$arm" && LD_LIBRARY_PATH="$output/runtime" VORTEX_DRIVER="$driver" VORTEX_PROFILING=0 ./mldsa_profile -b 1 -s 0) > "$output/${arm}_${driver}_m1_s0.log" 2>&1
    done
    if [[ "$arm" == stage || "$arm" == round ]]; then
        for driver in simx xrt; do
            (cd "$output/$arm" && LD_LIBRARY_PATH="$output/runtime" VORTEX_DRIVER="$driver" VORTEX_PROFILING=0 ./mldsa_profile -b 2 -s 1) > "$output/${arm}_${driver}_m2_s1.log" 2>&1
        done
        (cd "$output/$arm" && LD_LIBRARY_PATH="$output/runtime" VORTEX_DRIVER=simx VORTEX_PROFILING=0 ./mldsa_profile -b 8 -s 0) > "$output/${arm}_simx_m8_s0.log" 2>&1
    fi
done
