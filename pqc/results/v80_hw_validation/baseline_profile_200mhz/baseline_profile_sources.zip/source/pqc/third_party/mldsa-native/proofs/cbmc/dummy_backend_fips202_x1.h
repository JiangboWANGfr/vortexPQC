/*
 * Copyright (c) The mldsa-native project authors
 * SPDX-License-Identifier: Apache-2.0 OR ISC OR MIT
 */

#ifndef MLD_DUMMY_FIPS202X1_BACKEND_H
#define MLD_DUMMY_FIPS202X1_BACKEND_H


#define MLD_USE_NATIVE_FIPS202_X1

#include "../../mldsa/src/fips202/native/api.h"

#endif /* !MLD_DUMMY_FIPS202X1_BACKEND_H */
