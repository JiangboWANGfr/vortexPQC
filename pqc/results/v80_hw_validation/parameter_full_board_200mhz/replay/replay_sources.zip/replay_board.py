import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import statistics
import subprocess
import time
import zipfile

REPO = Path(__file__).resolve().parent.parent
BOARD = REPO / 'build32_v80_pqc_hw'
SLASH = REPO.parent / 'slash'
OUT = REPO / 'pqc/results/v80_hw_validation/parameter_full_board_200mhz/replay'
OUT.mkdir(parents=True, exist_ok=True)
old_k = json.loads((REPO / 'pqc/docs/dac_paper2/data/mlkem768_board_200mhz.json').read_text())
old_d = json.loads((REPO / 'pqc/docs/dac_paper2/data/mldsa65_board_200mhz.json').read_text())
vbin = BOARD / 'hw/syn/xilinx/aved/v80_pqc_w8t32_200_id16_wt_multiout_aved_hw/bin/vortex_afu.vbin'
libraries = (SLASH / 'vrt/vrtd/build/libvrtd/src', SLASH / 'vrt/build/lib', BOARD / 'sw/runtime')
env = dict(os.environ, LD_LIBRARY_PATH=':'.join(map(str, libraries)), VORTEX_DRIVER='aved',
           VRT_DEVICE_BDF='02:00', VRT_VBIN_PATH=str(vbin), VORTEX_AVED_NO_PROGRAM='1',
           VORTEX_PROFILING='0')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def clock():
    command = [str(SLASH / 'smi/build/src/v80-smi'), 'debug', 'clockwiz', '-d', '02:00',
               '--get', '--region', 'user']
    result = int(subprocess.check_output(command, env=env, text=True))
    assert result == 200000000
    return result

with (BOARD / 'pqc_board.lock').open('w') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX)
    result = dict(clock_before=clock(), image_sha256=sha(vbin), runs=[], medians=[])
    assert result['image_sha256'] == old_d['vbin_sha256']
    for parameter, arms in (('K768', 'AD'), ('D65', 'AE')):
        for batch in (1, 8):
            for repeat in range(6):
                for arm in arms:
                    if parameter == 'K768':
                        source = old_k['arms'][arm]
                        folder = (REPO / source['kernel']).parent
                        project = 'mlkem_profile'
                        tail = '-t32'
                    else:
                        source = old_d['arms'][arm]
                        folder = REPO / source['folder']
                        project = 'mldsa_profile'
                        tail = '-s3'
                        assert sha(folder / project) == source['host_sha256']
                    assert sha(folder / 'kernel.vxbin') == source['kernel_sha256']
                    command = ['./' + project, f'-b{batch}', f'-w{batch}', tail]
                    log = OUT / f'{parameter}_{arm}_m{batch}_r{repeat}.log'
                    start = time.time()
                    with log.open('w') as stream:
                        run = subprocess.run(command, cwd=folder, env=env, stdout=stream,
                                             stderr=subprocess.STDOUT, timeout=180)
                    assert run.returncode == 0, log
                    text = log.read_text()
                    assert text.rstrip().endswith('PASSED!'), log
                    pattern = ('pk/sk/ct/ss_enc/ss_dec match byte-for-byte' if parameter == 'K768'
                               else 'pk/sk/signature match portable C byte-for-byte')
                    assert text.count(pattern) == batch, log
                    cycles = int(re.findall(r'^BATCH:.*makespan=(\d+)', text, re.M)[0])
                    result['runs'].append(dict(parameter=parameter, arm=arm, batch=batch,
                        repeat=repeat, cycles=cycles, command=command, cwd=str(folder),
                        kernel_sha256=sha(folder / 'kernel.vxbin'), host_sha256=sha(folder / project),
                        elapsed_seconds=time.time()-start, log=log.name, log_sha256=sha(log)))
                    print('PASS', log.stem, cycles, flush=True)
            medians = {}
            for arm in arms:
                median = statistics.median(r['cycles'] for r in result['runs']
                    if r['parameter'] == parameter and r['batch'] == batch and r['arm'] == arm and r['repeat'])
                previous = (old_k['measurements'][f'M{batch}'][arm]['median_makespan_cycles']
                            if parameter == 'K768' else old_d['medians'][str(batch)][arm])
                medians[arm] = median
                result['medians'].append(dict(parameter=parameter, batch=batch, arm=arm,
                    cycles=median, previous_cycles=previous, change_pct=100*(median/previous-1)))
            print('SPEEDUP', parameter, batch, medians[arms[0]] / medians[arms[1]], flush=True)
    result['clock_after'] = clock()
    (OUT / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
    with zipfile.ZipFile(OUT / 'replay_sources.zip', 'w', zipfile.ZIP_DEFLATED) as z:
        z.write(Path(__file__), 'replay_board.py')
        for path in list(OUT.glob('*.json')) + list(OUT.glob('*.log')):
            z.write(path, path.name)
    print('COMPLETE', flush=True)
