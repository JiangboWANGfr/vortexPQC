// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef __VX_PQC_H__
#define __VX_PQC_H__

// Kernel-side entry point for the PQC extension, so a kernel includes one thing.

#include "pqc/vx_pqc_defs.h"
#include "pqc/vx_keccak.h"
#include "pqc/vx_ntt.h"

#endif // __VX_PQC_H__
