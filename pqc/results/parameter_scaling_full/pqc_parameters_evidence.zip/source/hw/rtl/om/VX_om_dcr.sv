//!/bin/bash

// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

`include "VX_om_define.vh"

module VX_om_dcr import VX_gpu_pkg::*, VX_om_pkg::*; #(
    parameter `STRING INSTANCE_ID = ""
) (
    input wire clk,
    input wire reset,

    // Inputs
    VX_dcr_bus_if.slave     dcr_bus_if,

    // Output
    output om_dcrs_t        om_dcrs,
    output om_rt_dcrs_t     om_rt_dcrs [`VX_OM_MAX_RT]
);
    `UNUSED_SPARAM (INSTANCE_ID)
    `UNUSED_VAR (reset)

    // Decode write strobe and extract addr/data from the req-style DCR bus
    wire write_valid                    = dcr_bus_if.req_valid && dcr_bus_if.req_data.rw;
    wire [VX_DCR_ADDR_WIDTH-1:0] write_addr = dcr_bus_if.req_data.addr;
    wire [VX_DCR_DATA_WIDTH-1:0] write_data = dcr_bus_if.req_data.data;
    `UNUSED_VAR (write_data[31])

    // Tie off response side (DCRs are write-only here)
    assign dcr_bus_if.rsp_valid = 1'b0;
    assign dcr_bus_if.rsp_data  = '0;

`define DEPTH_TEST_ENABLE(func, writemask) \
        ~((func == `VX_OM_DEPTH_FUNC_ALWAYS) && ~writemask)

`define STENCIL_TEST_ENABLE(func, zpass, zfail) \
         ~((func  == `VX_OM_DEPTH_FUNC_ALWAYS) \
        && (zpass == `VX_OM_STENCIL_OP_KEEP)   \
        && (zfail == `VX_OM_STENCIL_OP_KEEP))

`define BLEND_ENABLE(mode_rgb, mode_a, src_rgb, src_a, dst_rgb, dst_a) \
         ~((mode_rgb == `VX_OM_BLEND_MODE_ADD)  \
        && (mode_a   == `VX_OM_BLEND_MODE_ADD)  \
        && (src_rgb  == `VX_OM_BLEND_FUNC_ONE)  \
        && (src_a    == `VX_OM_BLEND_FUNC_ONE)  \
        && (dst_rgb  == `VX_OM_BLEND_FUNC_ZERO) \
        && (dst_a    == `VX_OM_BLEND_FUNC_ZERO))

    om_dcrs_t    dcrs;
    om_rt_dcrs_t rt_dcrs [`VX_OM_MAX_RT];

    // Attachment the colour registers below write. Reset to 0 so a pass with a
    // single attachment never has to name one.
    reg [OM_RT_IDX_BITS-1:0] rt_sel;

    // DCRs write

    always @(posedge clk) begin
        if (reset) begin
            rt_sel <= '0;
        end else if (write_valid) begin
            if (write_addr == `VX_DCR_OM_RT_SELECT) begin
                rt_sel <= write_data[0 +: OM_RT_IDX_BITS];
            end
        end
    end

    always @(posedge clk) begin
        if (write_valid) begin
            case (write_addr)
                `VX_DCR_OM_CBUF_ADDR: begin
                    rt_dcrs[rt_sel].cbuf_addr <= write_data[`OM_ADDR_BITS-1:0];
                end
                `VX_DCR_OM_CBUF_PITCH: begin
                    rt_dcrs[rt_sel].cbuf_pitch <= write_data[OM_PITCH_BITS-1:0];
                end
                `VX_DCR_OM_CBUF_WRITEMASK: begin
                    rt_dcrs[rt_sel].cbuf_writemask <= write_data[3:0];
                end
                `VX_DCR_OM_ZBUF_ADDR: begin
                    dcrs.zbuf_addr <= write_data[`OM_ADDR_BITS-1:0];
                end
                `VX_DCR_OM_ZBUF_PITCH: begin
                    dcrs.zbuf_pitch <= write_data[OM_PITCH_BITS-1:0];
                end
                `VX_DCR_OM_DEPTH_FUNC: begin
                    dcrs.depth_func   <= write_data[0 +: OM_DEPTH_FUNC_BITS];
                end
                `VX_DCR_OM_DEPTH_WRITEMASK: begin
                    dcrs.depth_writemask <= write_data[0];
                end
                `VX_DCR_OM_STENCIL_FUNC: begin
                    dcrs.stencil_func[0]   <= write_data[0 +: OM_DEPTH_FUNC_BITS];
                    dcrs.stencil_func[1]   <= write_data[16 +: OM_DEPTH_FUNC_BITS];
                end
                `VX_DCR_OM_STENCIL_ZPASS: begin
                    dcrs.stencil_zpass[0]  <= write_data[0 +: OM_STENCIL_OP_BITS];
                    dcrs.stencil_zpass[1]  <= write_data[16 +: OM_STENCIL_OP_BITS];
                end
                `VX_DCR_OM_STENCIL_ZFAIL: begin
                    dcrs.stencil_zfail[0]  <= write_data[0 +: OM_STENCIL_OP_BITS];
                    dcrs.stencil_zfail[1]  <= write_data[16 +: OM_STENCIL_OP_BITS];

                end
                `VX_DCR_OM_STENCIL_FAIL: begin
                    dcrs.stencil_fail[0] <= write_data[0 +: OM_STENCIL_OP_BITS];
                    dcrs.stencil_fail[1] <= write_data[16 +: OM_STENCIL_OP_BITS];
                end
                `VX_DCR_OM_STENCIL_REF: begin
                    dcrs.stencil_ref[0] <= write_data[0 +: `VX_OM_STENCIL_BITS];
                    dcrs.stencil_ref[1] <= write_data[16 +: `VX_OM_STENCIL_BITS];
                end
                `VX_DCR_OM_STENCIL_MASK: begin
                    dcrs.stencil_mask[0] <= write_data[0 +: `VX_OM_STENCIL_BITS];
                    dcrs.stencil_mask[1] <= write_data[16 +: `VX_OM_STENCIL_BITS];
                end
                `VX_DCR_OM_STENCIL_WRITEMASK: begin
                    dcrs.stencil_writemask[0] <= write_data[0 +: `VX_OM_STENCIL_BITS];
                    dcrs.stencil_writemask[1] <= write_data[16 +: `VX_OM_STENCIL_BITS];
                end
                `VX_DCR_OM_BLEND_MODE: begin
                    rt_dcrs[rt_sel].blend_mode_rgb <= write_data[0  +: OM_BLEND_MODE_BITS];
                    rt_dcrs[rt_sel].blend_mode_a   <= write_data[16 +: OM_BLEND_MODE_BITS];
                end
                `VX_DCR_OM_BLEND_FUNC: begin
                    rt_dcrs[rt_sel].blend_src_rgb <= write_data[0  +: OM_BLEND_FUNC_BITS];
                    rt_dcrs[rt_sel].blend_src_a   <= write_data[8  +: OM_BLEND_FUNC_BITS];
                    rt_dcrs[rt_sel].blend_dst_rgb <= write_data[16 +: OM_BLEND_FUNC_BITS];
                    rt_dcrs[rt_sel].blend_dst_a   <= write_data[24 +: OM_BLEND_FUNC_BITS];
                end
                `VX_DCR_OM_BLEND_CONST: begin
                    rt_dcrs[rt_sel].blend_const <= write_data[0 +: 32];
                end
                `VX_DCR_OM_LOGIC_OP: begin
                    rt_dcrs[rt_sel].logic_op <= write_data[0 +: OM_LOGIC_OP_BITS];
                end
                `VX_DCR_OM_APERTURE_XBITS: begin
                    dcrs.aperture_xbits <= write_data[0 +: OM_APERTURE_BITS_W];
                end
                `VX_DCR_OM_APERTURE_YBITS: begin
                    dcrs.aperture_ybits <= write_data[0 +: OM_APERTURE_BITS_W];
                end
                `VX_DCR_OM_APERTURE_RECORD_SHIFT: begin
                    dcrs.aperture_record_shift <= write_data[0 +: 2];
                end
                `VX_DCR_OM_APERTURE_DEPTH_ONLY: begin
                    dcrs.aperture_depth_only <= write_data[0];
                end
                default:;
            endcase
        end
        dcrs.stencil_enable[0] <= `STENCIL_TEST_ENABLE(dcrs.stencil_func[0], dcrs.stencil_zpass[0], dcrs.stencil_zfail[0]);
        dcrs.stencil_enable[1] <= `STENCIL_TEST_ENABLE(dcrs.stencil_func[1], dcrs.stencil_zpass[1], dcrs.stencil_zfail[1]);
        dcrs.depth_enable      <= `DEPTH_TEST_ENABLE(dcrs.depth_func, dcrs.depth_writemask);
        for (integer i = 0; i < `VX_OM_MAX_RT; ++i) begin
            rt_dcrs[i].blend_enable <= `BLEND_ENABLE(rt_dcrs[i].blend_mode_rgb, rt_dcrs[i].blend_mode_a,
                                                     rt_dcrs[i].blend_src_rgb, rt_dcrs[i].blend_src_a,
                                                     rt_dcrs[i].blend_dst_rgb, rt_dcrs[i].blend_dst_a);
        end
    end

    // DCRs read
    assign om_dcrs = dcrs;

    for (genvar i = 0; i < `VX_OM_MAX_RT; ++i) begin : g_rt_dcrs
        assign om_rt_dcrs[i] = rt_dcrs[i];
    end

`ifdef DBG_TRACE_OM
    always @(posedge clk) begin
        if (write_valid) begin
            `TRACE(1, ("%d: %s-om-dcr: state=", $time, INSTANCE_ID))
            `TRACE_OM_DCR(1, write_addr)
            `TRACE(1, (", data=0x%0h\n", write_data))
        end
    end
`endif

endmodule
