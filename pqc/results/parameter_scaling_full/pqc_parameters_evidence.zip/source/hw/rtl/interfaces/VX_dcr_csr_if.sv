// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

`include "VX_define.vh"

interface VX_dcr_csr_if import VX_gpu_pkg::*; ();

    wire                            valid;
    wire [`VX_CSR_ADDR_BITS-1:0]    addr;
    wire [7:0]                      mpm_class;
    wire [VX_DCR_DATA_WIDTH-1:0]    value;
    wire                            ready;

    modport master (
        output valid,
        output addr,
        output mpm_class,
        input  value,
        input  ready
    );

    modport slave (
        input  valid,
        input  addr,
        input  mpm_class,
        output value,
        output ready
    );

endinterface
