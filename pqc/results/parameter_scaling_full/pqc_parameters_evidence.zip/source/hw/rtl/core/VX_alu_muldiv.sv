// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

`include "VX_define.vh"

module VX_alu_muldiv import VX_gpu_pkg::*; #(
    parameter `STRING INSTANCE_ID = "",
    parameter NUM_LANES = 1
) (
    input wire          clk,
    input wire          reset,

    // Inputs
    VX_execute_if.slave execute_if,

    // Outputs
    VX_result_if.master result_if
);
    `UNUSED_SPARAM (INSTANCE_ID)
    `UNUSED_VAR (execute_if.data.rs3_data)

    localparam TAG_WIDTH = $bits(alu_header_t);

    wire [INST_M_BITS-1:0] muldiv_op = INST_M_BITS'(execute_if.data.op_type);

    wire is_mulx_op = inst_m_is_mulx(muldiv_op);
    wire is_signed_op = inst_m_signed(muldiv_op);
`ifdef VX_CFG_XLEN_64
    wire is_alu_w = execute_if.data.op_args.alu.is_w;
`else
    wire is_alu_w = 0;
`endif

    wire [NUM_LANES-1:0][`VX_CFG_XLEN-1:0] mul_result_out;
    alu_header_t mul_hdr_out;

    wire mul_valid_in = execute_if.valid && is_mulx_op;
    wire mul_ready_in;
    wire mul_valid_out;
    wire mul_ready_out;

    wire is_mulh_in      = inst_m_is_mulh(muldiv_op);
    wire is_signed_mul_a = inst_m_signed_a(muldiv_op);
    wire is_signed_mul_b = is_signed_op;

`ifdef IMUL_DPI

    import "DPI-C" function void dpi_imul(input logic enable, input logic is_signed_a, input logic is_signed_b, input int a, input int b, output int resultl, output int resulth);
    import "DPI-C" function void dpi_lmul(input logic enable, input logic is_signed_a, input logic is_signed_b, input longint a, input longint b, output longint resultl, output longint resulth);

    wire [NUM_LANES-1:0][`VX_CFG_XLEN-1:0] mul_result_tmp;

    wire mul_fire_in = mul_valid_in && mul_ready_in;

    for (genvar i = 0; i < NUM_LANES; ++i) begin : g_mul_result_tmp
        reg [`VX_CFG_XLEN-1:0] mul_resultl, mul_resulth;
        wire [`VX_CFG_XLEN-1:0] mul_in1 = is_alu_w ? (execute_if.data.rs1_data[i] & `VX_CFG_XLEN'(32'hFFFFFFFF)) : execute_if.data.rs1_data[i];
        wire [`VX_CFG_XLEN-1:0] mul_in2 = is_alu_w ? (execute_if.data.rs2_data[i] & `VX_CFG_XLEN'(32'hFFFFFFFF)) : execute_if.data.rs2_data[i];
        always @(*) begin
        `ifdef VX_CFG_XLEN_64
            dpi_lmul (mul_fire_in, is_signed_mul_a, is_signed_mul_b, mul_in1, mul_in2, mul_resultl, mul_resulth);
        `else
            dpi_imul (mul_fire_in, is_signed_mul_a, is_signed_mul_b, mul_in1, mul_in2, mul_resultl, mul_resulth);
        `endif
        end
        assign mul_result_tmp[i] = is_mulh_in ? mul_resulth : (is_alu_w ? `VX_CFG_XLEN'($signed(mul_resultl[31:0])) : mul_resultl);
    end

    VX_shift_register #(
        .DATAW  (1 + TAG_WIDTH + (NUM_LANES * `VX_CFG_XLEN)),
        .DEPTH  (`LATENCY_IMUL),
        .RESETW (1)
    ) mul_shift_reg (
        .clk      (clk),
        .reset    (reset),
        .enable   (mul_ready_in),
        .data_in  ({mul_valid_in,  execute_if.data.header, mul_result_tmp}),
        .data_out ({mul_valid_out, mul_hdr_out,            mul_result_out})
    );

    assign mul_ready_in = mul_ready_out || ~mul_valid_out;

`else

    wire [NUM_LANES-1:0][2*(`VX_CFG_XLEN+1)-1:0] mul_result_tmp;
    wire is_mulh_out;
    wire is_mul_w_out;

`ifdef VX_CFG_XLEN_64

    wire [NUM_LANES-1:0][`VX_CFG_XLEN:0] mul_in1;
    wire [NUM_LANES-1:0][`VX_CFG_XLEN:0] mul_in2;

    for (genvar i = 0; i < NUM_LANES; ++i) begin : g_mul_in
        assign mul_in1[i] = is_alu_w ? {{(`VX_CFG_XLEN-31){execute_if.data.rs1_data[i][31]}}, execute_if.data.rs1_data[i][31:0]} : {is_signed_mul_a && execute_if.data.rs1_data[i][`VX_CFG_XLEN-1], execute_if.data.rs1_data[i]};
        assign mul_in2[i] = is_alu_w ? {{(`VX_CFG_XLEN-31){execute_if.data.rs2_data[i][31]}}, execute_if.data.rs2_data[i][31:0]} : {is_signed_mul_b && execute_if.data.rs2_data[i][`VX_CFG_XLEN-1], execute_if.data.rs2_data[i]};
    end

    wire mul_strode;
    wire mul_busy;

    VX_elastic_adapter mul_elastic_adapter (
        .clk       (clk),
        .reset     (reset),
        .valid_in  (mul_valid_in),
        .ready_in  (mul_ready_in),
        .valid_out (mul_valid_out),
        .ready_out (mul_ready_out),
        .strobe    (mul_strode),
        .busy      (mul_busy)
    );

    VX_serial_mul #(
        .A_WIDTH (`VX_CFG_XLEN+1),
        .LANES   (NUM_LANES),
        .SIGNED  (1)
    ) serial_mul (
        .clk       (clk),
        .reset     (reset),

        .strobe    (mul_strode),
        .busy      (mul_busy),

        .dataa     (mul_in1),
        .datab     (mul_in2),
        .result    (mul_result_tmp)
    );

    reg [TAG_WIDTH+2-1:0] mul_tag_r;
    always @(posedge clk) begin
        if (mul_valid_in && mul_ready_in) begin
            mul_tag_r <= {execute_if.data.header, is_mulh_in, is_alu_w};
        end
    end

    assign {mul_hdr_out, is_mulh_out, is_mul_w_out} = mul_tag_r;

`else

    for (genvar i = 0; i < NUM_LANES; ++i) begin : g_multiplier
        wire [`VX_CFG_XLEN:0] mul_in1 = {is_signed_mul_a && execute_if.data.rs1_data[i][`VX_CFG_XLEN-1], execute_if.data.rs1_data[i]};
        wire [`VX_CFG_XLEN:0] mul_in2 = {is_signed_mul_b && execute_if.data.rs2_data[i][`VX_CFG_XLEN-1], execute_if.data.rs2_data[i]};

        VX_multiplier #(
            .A_WIDTH (`VX_CFG_XLEN+1),
            .B_WIDTH (`VX_CFG_XLEN+1),
            .R_WIDTH (2*(`VX_CFG_XLEN+1)),
            .SIGNED  (1),
            .LATENCY (`LATENCY_IMUL)
        ) multiplier (
            .clk    (clk),
            .enable (mul_ready_in),
            .dataa  (mul_in1),
            .datab  (mul_in2),
            .result (mul_result_tmp[i])
        );
    end

    VX_shift_register #(
        .DATAW  (1 + TAG_WIDTH + 1 + 1),
        .DEPTH  (`LATENCY_IMUL),
        .RESETW (1)
    ) mul_shift_reg (
        .clk      (clk),
        .reset    (reset),
        .enable   (mul_ready_in),
        .data_in  ({mul_valid_in,  execute_if.data.header, is_mulh_in,  is_alu_w}),
        .data_out ({mul_valid_out, mul_hdr_out,            is_mulh_out, is_mul_w_out})
    );

    assign mul_ready_in = mul_ready_out || ~mul_valid_out;

`endif

    for (genvar i = 0; i < NUM_LANES; ++i) begin : g_mul_result_out
    `ifdef VX_CFG_XLEN_64
        assign mul_result_out[i] = is_mulh_out ? mul_result_tmp[i][2*(`VX_CFG_XLEN)-1:`VX_CFG_XLEN] :
                                                 (is_mul_w_out ? `VX_CFG_XLEN'($signed(mul_result_tmp[i][31:0])) :
                                                                 mul_result_tmp[i][`VX_CFG_XLEN-1:0]);
    `else
        assign mul_result_out[i] = is_mulh_out ? mul_result_tmp[i][2*(`VX_CFG_XLEN)-1:`VX_CFG_XLEN] : mul_result_tmp[i][`VX_CFG_XLEN-1:0];
        `UNUSED_VAR (is_mul_w_out)
    `endif
    end

`endif

    ///////////////////////////////////////////////////////////////////////////

    wire [NUM_LANES-1:0][`VX_CFG_XLEN-1:0] div_result_out;
    alu_header_t div_hdr_out;

    wire is_rem_op = inst_m_is_rem(muldiv_op);

    wire div_valid_in = execute_if.valid && ~is_mulx_op;
    wire div_ready_in;
    wire div_valid_out;
    wire div_ready_out;

    wire [NUM_LANES-1:0][`VX_CFG_XLEN-1:0] div_in1;
    wire [NUM_LANES-1:0][`VX_CFG_XLEN-1:0] div_in2;

    for (genvar i = 0; i < NUM_LANES; ++i) begin : g_div_in
    `ifdef VX_CFG_XLEN_64
        assign div_in1[i] = is_alu_w ? {{(`VX_CFG_XLEN-32){is_signed_op && execute_if.data.rs1_data[i][31]}}, execute_if.data.rs1_data[i][31:0]}: execute_if.data.rs1_data[i];
        assign div_in2[i] = is_alu_w ? {{(`VX_CFG_XLEN-32){is_signed_op && execute_if.data.rs2_data[i][31]}}, execute_if.data.rs2_data[i][31:0]}: execute_if.data.rs2_data[i];
    `else
        assign div_in1[i] = execute_if.data.rs1_data[i];
        assign div_in2[i] = execute_if.data.rs2_data[i];
    `endif
    end

`ifdef IDIV_DPI

    import "DPI-C" function void dpi_idiv(input logic enable, input logic is_signed, input int a, input int b, output int quotient, output int remainder);
    import "DPI-C" function void dpi_ldiv(input logic enable, input logic is_signed, input longint a, input longint b, output longint quotient, output longint remainder);

    wire [NUM_LANES-1:0][`VX_CFG_XLEN-1:0] div_result_in;
    wire div_fire_in = div_valid_in && div_ready_in;

    for (genvar i = 0; i < NUM_LANES; ++i) begin : g_div_result_in
        reg [`VX_CFG_XLEN-1:0] div_quotient, div_remainder;
        always @(*) begin
        `ifdef VX_CFG_XLEN_64
            dpi_ldiv (div_fire_in, is_signed_op, div_in1[i], div_in2[i], div_quotient, div_remainder);
        `else
            dpi_idiv (div_fire_in, is_signed_op, div_in1[i], div_in2[i], div_quotient, div_remainder);
        `endif
        end
        assign div_result_in[i] = is_rem_op ? (is_alu_w ? `VX_CFG_XLEN'($signed(div_remainder[31:0])) : div_remainder) :
                                              (is_alu_w ? `VX_CFG_XLEN'($signed(div_quotient[31:0])) : div_quotient);
    end

    VX_shift_register #(
        .DATAW  (1 + TAG_WIDTH + (NUM_LANES * `VX_CFG_XLEN)),
        .DEPTH  (`LATENCY_IMUL),
        .RESETW (1)
    ) div_shift_reg (
        .clk(clk),
        .reset    (reset),
        .enable   (div_ready_in),
        .data_in  ({div_valid_in,  execute_if.data.header, div_result_in}),
        .data_out ({div_valid_out, div_hdr_out,            div_result_out})
    );

    assign div_ready_in = div_ready_out || ~div_valid_out;

`else

    wire [NUM_LANES-1:0][`VX_CFG_XLEN-1:0] div_quotient, div_remainder;
    wire is_rem_op_out;
    wire is_div_w_out;
    wire div_strode;
    wire div_busy;

    VX_elastic_adapter div_elastic_adapter (
        .clk       (clk),
        .reset     (reset),
        .valid_in  (div_valid_in),
        .ready_in  (div_ready_in),
        .valid_out (div_valid_out),
        .ready_out (div_ready_out),
        .strobe    (div_strode),
        .busy      (div_busy)
    );

    VX_serial_div #(
        .WIDTHN (`VX_CFG_XLEN),
        .WIDTHD (`VX_CFG_XLEN),
        .WIDTHQ (`VX_CFG_XLEN),
        .WIDTHR (`VX_CFG_XLEN),
        .LANES  (NUM_LANES)
    ) serial_div (
        .clk       (clk),
        .reset     (reset),

        .strobe    (div_strode),
        .busy      (div_busy),

        .is_signed (is_signed_op),
        .numer     (div_in1),
        .denom     (div_in2),

        .quotient  (div_quotient),
        .remainder (div_remainder)
    );

    reg [TAG_WIDTH+2-1:0] div_tag_r;
    always @(posedge clk) begin
        if (div_valid_in && div_ready_in) begin
            div_tag_r <= {execute_if.data.header, is_rem_op, is_alu_w};
        end
    end

    assign {div_hdr_out, is_rem_op_out, is_div_w_out} = div_tag_r;

    for (genvar i = 0; i < NUM_LANES; ++i) begin : g_div_result_out
    `ifdef VX_CFG_XLEN_64
        assign div_result_out[i] = is_rem_op_out ? (is_div_w_out ? `VX_CFG_XLEN'($signed(div_remainder[i][31:0])) : div_remainder[i]) :
                                                   (is_div_w_out ? `VX_CFG_XLEN'($signed(div_quotient[i][31:0])) : div_quotient[i]);
    `else
        assign div_result_out[i] = is_rem_op_out ? div_remainder[i] : div_quotient[i];
        `UNUSED_VAR (is_div_w_out)
    `endif
    end

`endif

    // can accept new request?
    assign execute_if.ready = is_mulx_op ? mul_ready_in : div_ready_in;

    VX_stream_arb #(
        .NUM_INPUTS (2),
        .DATAW (TAG_WIDTH + (NUM_LANES * `VX_CFG_XLEN)),
        .ARBITER ("P"),
        .OUT_BUF (2)
    ) rsp_buf (
        .clk       (clk),
        .reset     (reset),
        .valid_in  ({div_valid_out, mul_valid_out}),
        .ready_in  ({div_ready_out, mul_ready_out}),
        .data_in   ({{div_hdr_out, div_result_out},
                     {mul_hdr_out, mul_result_out}}),
        .data_out  (result_if.data),
        .valid_out (result_if.valid),
        .ready_out (result_if.ready),
        `UNUSED_PIN (sel_out)
    );

endmodule
