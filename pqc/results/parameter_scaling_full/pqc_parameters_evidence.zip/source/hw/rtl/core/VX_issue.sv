// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

`include "VX_define.vh"

module VX_issue import VX_gpu_pkg::*; #(
    parameter `STRING INSTANCE_ID = ""
) (
    `SCOPE_IO_DECL

    input wire              clk,
    input wire              reset,

`ifdef PERF_ENABLE
    output issue_perf_t     issue_perf,
`endif

    VX_decode_if.slave      decode_if,
    VX_writeback_if.slave   writeback_if [`VX_CFG_ISSUE_WIDTH],
    VX_dispatch_if.master   dispatch_if [NUM_EX_UNITS * `VX_CFG_ISSUE_WIDTH],
    VX_issue_sched_if.master issue_sched_if [`VX_CFG_ISSUE_WIDTH]
);
    `STATIC_ASSERT ((`VX_CFG_ISSUE_WIDTH <= `VX_CFG_NUM_WARPS), ("invalid parameter"))

`ifdef PERF_ENABLE
    issue_perf_t per_issue_perf [`VX_CFG_ISSUE_WIDTH];
    `PERF_COUNTER_ADD (issue_perf, per_issue_perf, ibf_stalls, PERF_CTR_BITS, `VX_CFG_ISSUE_WIDTH, (`VX_CFG_ISSUE_WIDTH > 2))
    `PERF_COUNTER_ADD (issue_perf, per_issue_perf, scb_stalls, PERF_CTR_BITS, `VX_CFG_ISSUE_WIDTH, (`VX_CFG_ISSUE_WIDTH > 2))
    `PERF_COUNTER_ADD (issue_perf, per_issue_perf, opd_stalls, PERF_CTR_BITS, `VX_CFG_ISSUE_WIDTH, (`VX_CFG_ISSUE_WIDTH > 2))
    for (genvar i = 0; i < NUM_EX_UNITS; ++i) begin : g_issue_perf_units_uses
        `PERF_COUNTER_ADD (issue_perf, per_issue_perf, dispatch_stalls[i], PERF_CTR_BITS, `VX_CFG_ISSUE_WIDTH, (`VX_CFG_ISSUE_WIDTH > 2))
        `PERF_COUNTER_ADD (issue_perf, per_issue_perf, dispatch_instrs[i], PERF_CTR_BITS, `VX_CFG_ISSUE_WIDTH, (`VX_CFG_ISSUE_WIDTH > 2))
    end
`endif

    wire [ISSUE_ISW_W-1:0] decode_isw = wid_to_isw(decode_if.data.wid);

    wire [`VX_CFG_ISSUE_WIDTH-1:0] decode_ready_in;
    assign decode_if.ready = decode_ready_in[decode_isw];

    `SCOPE_IO_SWITCH (`VX_CFG_ISSUE_WIDTH);

    wire [`VX_CFG_ISSUE_WIDTH-1:0] issued_warps;
    wire [`VX_CFG_ISSUE_WIDTH-1:0][ISSUE_WIS_W-1:0] issued_warp_wis;

    for (genvar issue_id = 0; issue_id < `VX_CFG_ISSUE_WIDTH; ++issue_id) begin : g_slices

        VX_dispatch_if per_issue_dispatch_if[NUM_EX_UNITS]();
        VX_decode_if slice_decode_if();

        assign slice_decode_if.valid = decode_if.valid && (decode_isw == issue_id);
        assign slice_decode_if.data  = decode_if.data;
        assign decode_ready_in[issue_id] = slice_decode_if.ready;

        for (genvar w = 0; w < PER_ISSUE_WARPS; ++w) begin : g_ibuf_pop
            assign decode_if.ibuf_pop[wis_to_wid(ISSUE_WIS_W'(w), ISSUE_ISW_W'(issue_id))] = slice_decode_if.ibuf_pop[w];
        end

        VX_issue_slice #(
            .INSTANCE_ID (`SFORMATF(("%s%0d", INSTANCE_ID, issue_id))),
            .ISSUE_ID (issue_id)
        ) issue_slice (
            `SCOPE_IO_BIND(issue_id)
            .clk          (clk),
            .reset        (reset),
        `ifdef PERF_ENABLE
            .issue_perf   (per_issue_perf[issue_id]),
        `endif
            .decode_if    (slice_decode_if),
            .writeback_if (writeback_if[issue_id]),
            .dispatch_if  (per_issue_dispatch_if),
            .warp_issued  (issued_warps[issue_id]),
            .warp_issued_wis(issued_warp_wis[issue_id])
        );

        // Assign transposed dispatch_if
        for (genvar ex_id = 0; ex_id < NUM_EX_UNITS; ++ex_id) begin : g_dispatch_if
            `ASSIGN_VX_IF(dispatch_if[ex_id * `VX_CFG_ISSUE_WIDTH + issue_id], per_issue_dispatch_if[ex_id]);
        end
     end

    for (genvar i = 0; i < `VX_CFG_ISSUE_WIDTH; ++i) begin : g_issue_sched
        logic issued_r;
        logic [ISSUE_WIS_W-1:0] issued_wis_r;
        `BUFFER(issued_r,   issued_warps[i]);
        `BUFFER(issued_wis_r, issued_warp_wis[i]);
        assign issue_sched_if[i].valid = issued_r;
        assign issue_sched_if[i].wis   = issued_wis_r;
    end

endmodule
