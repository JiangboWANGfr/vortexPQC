// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

`include "VX_define.vh"

module VX_tcu_tfr_mul_i4 import VX_tcu_pkg::*; #(
    parameter `STRING INSTANCE_ID = "",
    parameter N   = 2,
    parameter TCK = 2 * N,
    parameter USE_DSP = 0,  // map the int4 multiplies onto DSP48 slices
    parameter PROD_REG = 0  // product/flag register stages (multiply-stage seam)
) (
    input wire                      clk,
    input wire                      enable,
    input wire                      valid_in,
    input wire [31:0]               req_id,

    input wire [TCU_MAX_INPUTS-1:0] vld_mask,
    input wire [3:0]                fmt_i,

    input wire [N-1:0][31:0]        a_row,
    input wire [N-1:0][31:0]        b_col,

    output logic [TCK-1:0][24:0]    result
);
    `UNUSED_SPARAM (INSTANCE_ID)
    `UNUSED_VAR ({clk, req_id, valid_in})

    wire is_signed_int = fmt_i[3] || tcu_fmt_is_signed_int(fmt_i);

    // Result-select format, delayed to post-seam timing.
    wire [3:0] fmt_i_r;
    VX_pipe_register #(
        .DATAW (4),
        .DEPTH (PROD_REG)
    ) pipe_fmt (
        .clk      (clk),
        .reset    (1'b0),
        .enable   (enable),
        .data_in  (fmt_i),
        .data_out (fmt_i_r)
    );

    // Multiplication and accumulation
    for (genvar i = 0; i < TCK; ++i) begin : g_lane

        wire signed [3:0][9:0] y_prod_i4;

        // Shared per-element extraction.
        wire [3:0][3:0] raw_a, raw_b;
        wire [3:0]      pvalid;
        for (genvar j = 0; j < 4; ++j) begin : g_ext
            assign raw_a[j]  = a_row[i/2][(i%2)*16 + j*4 +: 4];
            assign raw_b[j]  = b_col[i/2][(i%2)*16 + j*4 +: 4];
            assign pvalid[j] = vld_mask[i * 4 + j];
        end

        // Invalid lanes are masked post-seam so the DSP input cone stays flat.
        wire [3:0] pvalid_r;
        VX_pipe_register #(
            .DATAW (4),
            .DEPTH (PROD_REG)
        ) pipe_valid (
            .clk      (clk),
            .reset    (1'b0),
            .enable   (enable),
            .data_in  (pvalid),
            .data_out (pvalid_r)
        );

        if (USE_DSP != 0) begin : g_dsp
            // a*b == sign(a^b) * (|a|*|b|): pack two unsigned 4x4 magnitude
            // products per DSP48, then re-apply the sign in fabric. Two DSPs
            // cover the four int4 products of a lane (vs four with 1/DSP).
            wire [3:0][3:0] mag_a, mag_b;
            wire [3:0]      psign;
            for (genvar j = 0; j < 4; ++j) begin : g_mag
                wire sgn_a = is_signed_int & raw_a[j][3];
                wire sgn_b = is_signed_int & raw_b[j][3];
                assign mag_a[j] = sgn_a ? (4'(~raw_a[j]) + 4'b1) : raw_a[j];  // |a|
                assign mag_b[j] = sgn_b ? (4'(~raw_b[j]) + 4'b1) : raw_b[j];  // |b|
                assign psign[j] = sgn_a ^ sgn_b;
            end
            wire [3:0][7:0] magp;
            VX_tcu_tfr_wmul #(
                .N       (4),
                .LANES   (2),
                .USE_DSP (1),
                .OUT_REG (PROD_REG)
            ) m01 (
                .clk    (clk),
                .enable (enable),
                .a (mag_a[1:0]),
                .b (mag_b[1:0]),
                .p (magp[1:0])
            );
            VX_tcu_tfr_wmul #(
                .N       (4),
                .LANES   (2),
                .USE_DSP (1),
                .OUT_REG (PROD_REG)
            ) m23 (
                .clk    (clk),
                .enable (enable),
                .a (mag_a[3:2]),
                .b (mag_b[3:2]),
                .p (magp[3:2])
            );
            wire [3:0] psign_r;
            VX_pipe_register #(
                .DATAW (4),
                .DEPTH (PROD_REG)
            ) pipe_sign (
                .clk      (clk),
                .reset    (1'b0),
                .enable   (enable),
                .data_in  (psign),
                .data_out (psign_r)
            );
            for (genvar j = 0; j < 4; ++j) begin : g_sign
                wire signed [9:0] pf = psign_r[j] ? -$signed({2'b0, magp[j]})
                                                  :  $signed({2'b0, magp[j]});
                assign y_prod_i4[j] = pf & {10{pvalid_r[j]}};
            end
        end else begin : g_lut
            for (genvar j = 0; j < 4; ++j) begin : g_mul
                wire signed [4:0] s_a = is_signed_int ? $signed({raw_a[j][3], raw_a[j]}) : $signed({1'b0, raw_a[j]});
                wire signed [4:0] s_b = is_signed_int ? $signed({raw_b[j][3], raw_b[j]}) : $signed({1'b0, raw_b[j]});
                wire signed [9:0] prod_full = s_a * s_b;
                wire [9:0] prod_r;
                VX_pipe_register #(
                    .DATAW (10),
                    .DEPTH (PROD_REG)
                ) pipe_prod (
                    .clk      (clk),
                    .reset    (1'b0),
                    .enable   (enable),
                    .data_in  (prod_full),
                    .data_out (prod_r)
                );
                assign y_prod_i4[j] = prod_r & {10{pvalid_r[j]}};
            end
        end

        wire [9:0] y_i4_sum, y_i4_carry;
        VX_csa_tree #(
            .N (4),
            .W (10),
            .S (10)
        ) i4_csa (
            .operands (y_prod_i4),
            .sum      (y_i4_sum),
            .carry    (y_i4_carry)
        );

        wire [9:0] y_i4_add_res;
        VX_ks_adder #(
            .N (10),
            .BYPASS (`FORCE_BUILTIN_ADDER(10))
        ) i4_ksa (
            .cin   (1'b0),
            .dataa (y_i4_sum),
            .datab (y_i4_carry),
            .sum   (y_i4_add_res),
            `UNUSED_PIN(cout)
        );

        // Output muxing
        always_comb begin
            case ({1'b1, fmt_i_r})
                TCU_I4_ID: result[i] = 25'($signed(y_i4_add_res));
                TCU_U4_ID: result[i] = {15'b0, y_i4_add_res};
                default:   result[i] = '0;
            endcase
        end
    end

endmodule
