// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

`include "VX_define.vh"

module VX_tcu_tfr_mul_f16 import VX_tcu_pkg::*;
#(
    parameter `STRING INSTANCE_ID = "",
    parameter N     = 2,
    parameter TCK   = 2 * N,
    parameter W     = 25,
    parameter WA    = 28,
    parameter EXP_W = 10,
    parameter USE_DSP = 0,  // map the 11x11 mantissa multiply onto a DSP48 slice
    parameter PROD_REG = 0  // product/flag register stages (multiply-stage seam)
) (
    input wire                      clk,
    input wire                      enable,
    input wire                      valid_in,
    input wire [31:0]               req_id,

    input wire [TCU_MAX_INPUTS-1:0] vld_mask,
    input wire [3:0]                fmt_f,

    input wire [N-1:0][31:0]        a_row,
    input wire [N-1:0][31:0]        b_col,

    // result_exp/exceptions are pre-seam (classify cycle); result_sig is
    // post-seam (PROD_REG cycles later).
    output wire  [TCK-1:0][24:0]      result_sig,
    output logic [TCK-1:0][EXP_W-1:0] result_exp,
    output fedp_excep_t [TCK-1:0]     exceptions
);
    `UNUSED_SPARAM (INSTANCE_ID)
    `UNUSED_VAR ({clk, req_id, valid_in})
    `UNUSED_VAR (vld_mask)

    // Bank-select for the significand path, delayed to post-seam timing.
    logic sig_en;
    always_comb begin
        case (fmt_f)
        `ifdef VX_CFG_TCU_FP16_ENABLE
            TCU_FP16_ID,
            TCU_BF16_ID: sig_en = 1'b1;
        `endif
        `ifdef VX_CFG_TCU_TF32_ENABLE
            TCU_TF32_ID: sig_en = 1'b1;
        `endif
            default:     sig_en = 1'b0;
        endcase
    end

    wire sig_en_r;
    VX_pipe_register #(
        .DATAW (1),
        .DEPTH (PROD_REG)
    ) pipe_sig_en (
        .clk      (clk),
        .reset    (1'b0),
        .enable   (enable),
        .data_in  (sig_en),
        .data_out (sig_en_r)
    );

    localparam F32_BIAS  = 127;
    localparam S_FP32    = 23;
    localparam S_SUPER   = 22;
    localparam BIAS_BASE = F32_BIAS + S_FP32 - S_SUPER - W + WA - 1 + 128;

    localparam E_TF32 = VX_tcu_pkg::exp_bits(TCU_TF32_ID);
    localparam S_TF32 = VX_tcu_pkg::sign_pos(TCU_TF32_ID);
    localparam B_TF32 = (1 << (E_TF32 - 1)) - 1;
    localparam [7:0] BIAS_CONST_TF32 = 8'(BIAS_BASE - 2*B_TF32);

    localparam E_FP16 = VX_tcu_pkg::exp_bits(TCU_FP16_ID);
    localparam S_FP16 = VX_tcu_pkg::sign_pos(TCU_FP16_ID);
    localparam B_FP16 = (1 << (E_FP16 - 1)) - 1;
    localparam [7:0] BIAS_CONST_FP16 = 8'(BIAS_BASE - 2*B_FP16);

    localparam E_BF16 = VX_tcu_pkg::exp_bits(TCU_BF16_ID);
    localparam S_BF16 = VX_tcu_pkg::sign_pos(TCU_BF16_ID);
    localparam B_BF16 = (1 << (E_BF16 - 1)) - 1;
    localparam [7:0] BIAS_CONST_BF16 = 8'(BIAS_BASE - 2*B_BF16);

    `UNUSED_PARAM (BIAS_CONST_TF32)
    `UNUSED_PARAM (BIAS_CONST_BF16)
    `UNUSED_PARAM (S_TF32)
    `UNUSED_PARAM (S_BF16)
`ifndef VX_CFG_TCU_FP16_ENABLE
    `UNUSED_PARAM (BIAS_CONST_FP16)
    `UNUSED_PARAM (S_FP16)
`endif


    for (genvar i = 0; i < TCK; ++i) begin : g_lane

        wire lane_valid = vld_mask[i*4];
        localparam OFF_16 = (i % 2) * 16;
`ifndef VX_CFG_TCU_FP16_ENABLE
        `UNUSED_PARAM (OFF_16)
`endif

        // Input muxing and field extraction
        logic [7:0] raw_ea, raw_eb;
        logic [9:0] raw_ma, raw_mb;
        logic       raw_sa, raw_sb;
        logic [7:0] bias_sel;

        always_comb begin
            case (fmt_f)
            `ifdef VX_CFG_TCU_FP16_ENABLE
                TCU_FP16_ID: begin
                    raw_ea    = 8'(a_row[i/2][S_FP16-1+OFF_16 -: E_FP16]);
                    raw_eb    = 8'(b_col[i/2][S_FP16-1+OFF_16 -: E_FP16]);
                    raw_ma    = a_row[i/2][9+OFF_16 -: 10];
                    raw_mb    = b_col[i/2][9+OFF_16 -: 10];
                    raw_sa    = a_row[i/2][15+OFF_16];
                    raw_sb    = b_col[i/2][15+OFF_16];
                    bias_sel  = BIAS_CONST_FP16;
                end
                TCU_BF16_ID: begin
                    raw_ea    = a_row[i/2][S_BF16-1+OFF_16 -: E_BF16];
                    raw_eb    = b_col[i/2][S_BF16-1+OFF_16 -: E_BF16];
                    raw_ma    = {a_row[i/2][6+OFF_16 -: 7], 3'b0};
                    raw_mb    = {b_col[i/2][6+OFF_16 -: 7], 3'b0};
                    raw_sa    = a_row[i/2][15+OFF_16];
                    raw_sb    = b_col[i/2][15+OFF_16];
                    bias_sel  = BIAS_CONST_BF16;
                end
            `endif
            `ifdef VX_CFG_TCU_TF32_ENABLE
                TCU_TF32_ID: begin
                    if ((i % 2) == 0) begin
                        raw_ea    = a_row[i/2][S_TF32-1 -: E_TF32];
                        raw_eb    = b_col[i/2][S_TF32-1 -: E_TF32];
                        raw_ma    = a_row[i/2][9:0];
                        raw_mb    = b_col[i/2][9:0];
                        raw_sa    = a_row[i/2][18];
                        raw_sb    = b_col[i/2][18];
                        bias_sel  = BIAS_CONST_TF32;
                    end else begin
                        raw_ea    = '0;
                        raw_eb    = '0;
                        raw_ma    = '0;
                        raw_mb    = '0;
                        raw_sa    = '0;
                        raw_sb    = '0;
                        bias_sel  = '0;
                    end
                end
            `endif
                default: begin
                    raw_ea    = '0;
                    raw_eb    = '0;
                    raw_ma    = '0;
                    raw_mb    = '0;
                    raw_sa    = '0;
                    raw_sb    = '0;
                    bias_sel  = '0;
                end
            endcase
        end

        // Classification
        fedp_class_t cls_a_f16;
        VX_tcu_tfr_classifier #(
            .EXP_W (E_FP16),
            .MAN_W (10)
        ) class_a_f16 (
            .exp (raw_ea[E_FP16-1:0]),
            .man (raw_ma),
            .cls (cls_a_f16)
        );

        fedp_class_t cls_b_f16;
        VX_tcu_tfr_classifier #(
            .EXP_W (E_FP16),
            .MAN_W (10)
        ) class_b_f16 (
            .exp (raw_eb[E_FP16-1:0]),
            .man (raw_mb),
            .cls (cls_b_f16)
        );

        fedp_class_t cls_a_wide;
        VX_tcu_tfr_classifier #(
            .EXP_W (8),
            .MAN_W (10)
        ) class_a_wide (
            .exp (raw_ea),
            .man (raw_ma),
            .cls (cls_a_wide)
        );

        fedp_class_t cls_b_wide;
        VX_tcu_tfr_classifier #(
            .EXP_W (8),
            .MAN_W (10)
        ) class_b_wide (
            .exp (raw_eb),
            .man (raw_mb),
            .cls (cls_b_wide)
        );

        fedp_class_t cls_a;
        fedp_class_t cls_b;
        always_comb begin
            if (fmt_f == TCU_FP16_ID) begin
                cls_a = cls_a_f16;
                cls_b = cls_b_f16;
            end else begin
                cls_a = cls_a_wide;
                cls_b = cls_b_wide;
            end
        end

        // Operand preparation
        wire is_ea_zero = ~|raw_ea;
        wire is_eb_zero = ~|raw_eb;

        wire [7:0] ea_sel = is_ea_zero ? 8'b1 : raw_ea;
        wire [7:0] eb_sel = is_eb_zero ? 8'b1 : raw_eb;

        wire [10:0] ma_sel = {~is_ea_zero, raw_ma};
        wire [10:0] mb_sel = {~is_eb_zero, raw_mb};
        `UNUSED_VAR (cls_a.is_sub)
        `UNUSED_VAR (cls_b.is_sub)

        wire sign_sel = raw_sa ^ raw_sb;
        wire zero_sel = cls_a.is_zero | cls_b.is_zero;

        wire nan_in = cls_a.is_nan | cls_b.is_nan;
        wire inf_z  = (cls_a.is_inf & cls_b.is_zero) | (cls_a.is_zero & cls_b.is_inf);
        wire inf_op = cls_a.is_inf | cls_b.is_inf;

        wire nan_sel = nan_in | inf_z;
        wire inf_sel = inf_op & ~inf_z;

        wire [EXP_W-1:0] exp_final = EXP_W'(bias_sel) + EXP_W'(ea_sel) + EXP_W'(eb_sel);
        assign result_exp[i] = (~zero_sel && lane_valid) ? exp_final : '0;

        // Mantissa product: 11x11 -> 22. USE_DSP maps it to a DSP48 (the 22-bit
        // product fits one DSP48E2 27x18); PROD_REG lands in its PREG.
        wire [21:0] man_prod;
        VX_tcu_tfr_wmul #(
            .N (11),
            .USE_DSP (USE_DSP),
            .OUT_REG (PROD_REG)
        ) wtmul (
            .clk    (clk),
            .enable (enable),
            .a (ma_sel),
            .b (mb_sel),
            .p (man_prod)
        );

        wire sign_sel_r;
        VX_pipe_register #(
            .DATAW (1),
            .DEPTH (PROD_REG)
        ) pipe_sign (
            .clk      (clk),
            .reset    (1'b0),
            .enable   (enable),
            .data_in  (sign_sel),
            .data_out (sign_sel_r)
        );

        assign result_sig[i] = sig_en_r ? {sign_sel_r, man_prod, 2'b0} : '0;

        assign exceptions[i].is_nan = nan_sel && lane_valid;
        assign exceptions[i].is_inf = inf_sel && lane_valid;
        assign exceptions[i].sign   = sign_sel;
    end

endmodule
