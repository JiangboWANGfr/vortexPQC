// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

`include "VX_define.vh"

`ifndef SYNTHESIS
`define DSP_TEST
`include "dpi_float.vh"
`endif

// Function to convert IEEE-754 half precision (16-bit) to single precision (32-bit)
module fp16_to_fp32 (
    input  wire [15:0] fp16_in,   // FP16: 1 sign, 5 exponent, 10 fraction
    output wire [31:0] fp32_out   // FP32: 1 sign, 8 exponent, 23 fraction
);
    // Extract FP16 components
    wire        sign     = fp16_in[15];
    wire [4:0]  exponent = fp16_in[14:10];
    wire [9:0]  fraction = fp16_in[9:0];

    // Special case detection
    wire is_zero      = (exponent == 5'b0) && (fraction == 10'b0);
    wire is_denormal  = (exponent == 5'b0) && (fraction != 10'b0);
    wire is_infinity  = (exponent == 5'b11111) && (fraction == 10'b0);
    wire is_nan       = (exponent == 5'b11111) && (fraction != 10'b0);

    // Denormal handling - normalization and leading zero count
    wire [4:0]  leading_zeros;
    wire [9:0]  normalized_frac;
    `UNUSED_VAR (normalized_frac[9]);

    // Priority encoder for leading zero count (10-bit)
    assign leading_zeros =
        fraction[9] ? 5'd0 :
        fraction[8] ? 5'd1 :
        fraction[7] ? 5'd2 :
        fraction[6] ? 5'd3 :
        fraction[5] ? 5'd4 :
        fraction[4] ? 5'd5 :
        fraction[3] ? 5'd6 :
        fraction[2] ? 5'd7 :
        fraction[1] ? 5'd8 :
        fraction[0] ? 5'd9 : 5'd10;

    // Normalize denormal fraction
    assign normalized_frac = fraction << leading_zeros;

    // Calculate FP32 exponent
    wire [7:0] exp32 =
        is_denormal ? 8'd127 - 8'd14 - {3'b0, leading_zeros} + 8'd1 :  // 2^(-14 - (10 - leading_zeros))
        is_zero     ? 8'b0 :
        is_infinity ? 8'b11111111 :
        is_nan      ? 8'b11111111 :
        {3'b0, exponent} + 8'd112;  // Normalized: exp16 - 15 + 127 = exp16 + 112

    // Calculate FP32 fraction
    wire [22:0] frac32 =
        is_denormal ? {normalized_frac[8:0], 14'b0} :  // Use bits after leading one
        is_zero     ? 23'b0 :
        is_infinity ? 23'b0 :
        is_nan      ? {1'b1, fraction, 12'b0} :        // Preserve NaN payload
        {fraction, 13'b0};                             // Normalized

    // Final FP32 output
    assign fp32_out = {sign, exp32, frac32};

endmodule

// Module to convert BF16 (Brain Floating Point) to IEEE-754 FP32 (single precision)
module bf16_to_fp32 (
    input  wire [15:0] bf16_in,   // BF16: 1 sign, 8 exponent, 7 fraction
    output wire [31:0] fp32_out   // FP32: 1 sign, 8 exponent, 23 fraction
);
    // Extract BF16 components
    wire        sign     = bf16_in[15];
    wire [7:0]  exponent = bf16_in[14:7];
    wire [6:0]  fraction = bf16_in[6:0];

    // We simply need to extend the fraction with zeros
    wire [7:0]  fp32_exponent = exponent;
    wire [22:0] fp32_fraction = {fraction, 16'b0};

    // Final FP32 output
    assign fp32_out = {sign, fp32_exponent, fp32_fraction};

endmodule

module VX_tcu_fedp_dsp import VX_tcu_pkg::*; #(
    parameter `STRING INSTANCE_ID = "",
    parameter LATENCY = 0,
    parameter N = TCU_TC_K
) (
    input  wire clk,
    input  wire reset,
    input  wire enable,

    input  wire [4:0] fmt_s,
    input  wire [4:0] fmt_d,

    input  wire [N-1:0][31:0] a_row,
    input  wire [N-1:0][31:0] b_col,
    input  wire [31:0] c_val,
    output wire [31:0] d_val
);
    `UNUSED_SPARAM (INSTANCE_ID)
    localparam TCK = 2 * N;
    localparam LEVELS = $clog2(TCK);

    localparam FCVT_LATENCY = 1;
    localparam FMUL_LATENCY = 8;
    localparam FADD_LATENCY = 11;
    localparam FRED_LATENCY = LEVELS * FADD_LATENCY;
    localparam TOTAL_LATENCY= FCVT_LATENCY + FMUL_LATENCY + FRED_LATENCY + FADD_LATENCY;
    `STATIC_ASSERT (LATENCY == 0 || LATENCY == TOTAL_LATENCY, ("invalid latency! expected=%0d, actual=%0d", TOTAL_LATENCY, LATENCY));

    localparam C_DELAY = FCVT_LATENCY + FMUL_LATENCY + FRED_LATENCY;

    `UNUSED_VAR ({fmt_d});

    wire [TCK-1:0][15:0] a_row16, b_col16;

    for (genvar i = 0; i < N; i++) begin : g_unpack
        assign a_row16[2*i]   = a_row[i][15:0];
        assign a_row16[2*i+1] = a_row[i][31:16];
        assign b_col16[2*i]   = b_col[i][15:0];
        assign b_col16[2*i+1] = b_col[i][31:16];
    end

    wire [TCK-1:0][31:0] a_row32, b_col32;

    // convert to fp32

    for (genvar i = 0; i < TCK; i++) begin : g_cvt
        wire [31:0] a_row_fp16, b_col_fp16;
        wire [31:0] a_row_bf16, b_col_bf16;

        fp16_to_fp32 cvt_row_fp16 (
            .fp16_in  (a_row16[i]),
            .fp32_out (a_row_fp16)
        );

        fp16_to_fp32 cvt_col_fp16 (
            .fp16_in  (b_col16[i]),
            .fp32_out (b_col_fp16)
        );

        bf16_to_fp32 cvt_row_bf16 (
            .bf16_in  (a_row16[i]),
            .fp32_out (a_row_bf16)
        );

        bf16_to_fp32 cvt_col_bf16 (
            .bf16_in  (b_col16[i]),
            .fp32_out (b_col_bf16)
        );

        reg [31:0] a_row_sel, a_col_sel;

        always @(*) begin
            case (fmt_s)
            TCU_FP16_ID: begin
                a_row_sel = a_row_fp16;
                a_col_sel = b_col_fp16;
            end
        `ifdef VX_CFG_TCU_FP16_ENABLE
            TCU_BF16_ID: begin
                a_row_sel = a_row_bf16;
                a_col_sel = b_col_bf16;
            end
        `endif
            default: begin
                a_row_sel = 'x;
                a_col_sel = 'x;
            end
            endcase
        end

        VX_pipe_register #(
            .DATAW (32+32),
            .DEPTH (FCVT_LATENCY)
        ) pipe_cvt (
            .clk     (clk),
            .reset   (reset),
            .enable  (enable),
            .data_in ({a_row_sel, a_col_sel}),
            .data_out({a_row32[i], b_col32[i]})
        );
    end

    wire [31:0] mult_result [TCK];

    // multiplication stage
    for (genvar i = 0; i < TCK; i++) begin : g_prod
    `ifdef DSP_TEST
        wire [63:0] a_h = {32'hffffffff, a_row32[i]};
        wire [63:0] b_h = {32'hffffffff, b_col32[i]};
        reg [63:0] c_h;
        reg [4:0] fflags;
        `UNUSED_VAR({c_h[63:32], fflags});
        always @(*) begin
            dpi_fmul(enable, int'(0), a_h, b_h, 3'b0, c_h, fflags);
        end
        `BUFFER_EX(mult_result[i], c_h[31:0], enable, 0, FMUL_LATENCY);
    `else
        xil_fmul fmul (
            .aclk                (clk),
            .aclken              (enable),
            .s_axis_a_tvalid     (1'b1),
            .s_axis_a_tdata      (a_row32[i]),
            .s_axis_b_tvalid     (1'b1),
            .s_axis_b_tdata      (b_col32[i]),
            `UNUSED_PIN (m_axis_result_tvalid),
            .m_axis_result_tdata (mult_result[i])
        );
    `endif
    end

    wire [31:0] red_in [LEVELS+1][TCK];

    for (genvar i = 0; i < TCK; i++) begin : g_red_inputs
        assign red_in[0][i] = mult_result[i];
    end

    // accumulate reduction tree
    for (genvar lvl = 0; lvl < LEVELS; lvl++) begin : g_red_tree
        localparam integer CURSZ = TCK >> lvl;
        localparam integer OUTSZ = CURSZ >> 1;
        for (genvar i = 0; i < OUTSZ; i++) begin : g_add
        `ifdef DSP_TEST
            wire [63:0] a_h = {32'hffffffff, red_in[lvl][2*i+0]};
            wire [63:0] b_h = {32'hffffffff, red_in[lvl][2*i+1]};
            reg [63:0] c_h;
            reg [4:0] fflags;
            `UNUSED_VAR({c_h[63:32], fflags});
            always @(*) begin
                dpi_fadd(enable, int'(0), a_h, b_h, 3'b0, c_h, fflags);
            end
            `BUFFER_EX(red_in[lvl+1][i], c_h[31:0], enable, 0, FADD_LATENCY);
        `else
            xil_fadd fadd_red (
                .aclk                (clk),
                .aclken              (enable),
                .s_axis_a_tvalid     (1'b1),
                .s_axis_a_tdata      (red_in[lvl][2*i+0]),
                .s_axis_b_tvalid     (1'b1),
                .s_axis_b_tdata      (red_in[lvl][2*i+1]),
                .s_axis_operation_tvalid (1'b1),
                .s_axis_operation_tdata (8'b0), // 0=add
                `UNUSED_PIN (m_axis_result_tvalid),
                .m_axis_result_tdata (red_in[lvl+1][i])
            );
        `endif
        end
    end

    wire [31:0] delayed_c;

    VX_pipe_register #(
        .DATAW (32),
        .DEPTH (C_DELAY)
    ) pipe_c (
        .clk     (clk),
        .reset   (reset),
        .enable  (enable),
        .data_in (c_val[31:0]),
        .data_out(delayed_c)
    );

    // Integer dot product - 3-stage pipeline:
    //   Stage 1a: individual element products in native width (registered)
    //   Stage 1b: per-word sum of products (registered)
    //   Stage 2:  cross-word sum + C (piped to match FP latency)
    // Total: 1 + 1 + (TOTAL_LATENCY-2) = TOTAL_LATENCY cycles
    wire is_int = tcu_fmt_is_int(fmt_s);

    wire [N-1:0][31:0] int_word_prod;

    for (genvar i = 0; i < N; i++) begin : g_int_mul
        localparam MAX_PRODS = 8; // max elements per 32-bit word (INT4 has 8)
        wire [MAX_PRODS-1:0][31:0] elem_prods;

        // Stage 1a: elements 0..3 (valid for INT8/UINT8/INT4/UINT4)
        for (genvar j = 0; j < 4; j++) begin : g_elem_lo
            wire signed [15:0] i8_prod = $signed(a_row[i][8*j +: 8]) * $signed(b_col[i][8*j +: 8]);
            wire        [15:0] u8_prod = a_row[i][8*j +: 8] * b_col[i][8*j +: 8];
            wire signed  [7:0] i4_prod = $signed(a_row[i][4*j +: 4]) * $signed(b_col[i][4*j +: 4]);
            wire         [7:0] u4_prod = a_row[i][4*j +: 4] * b_col[i][4*j +: 4];

            reg [31:0] prod_sel;
            always @(*) begin
                case (fmt_s)
                    TCU_I8_ID: prod_sel = {{16{i8_prod[15]}}, i8_prod};
                    TCU_U8_ID: prod_sel = {16'b0, u8_prod};
                    TCU_I4_ID: prod_sel = {{24{i4_prod[7]}}, i4_prod};
                    TCU_U4_ID: prod_sel = {24'b0, u4_prod};
                    default:   prod_sel = '0;
                endcase
            end

            VX_pipe_register #(
                .DATAW (32),
                .DEPTH (1)
            ) pipe_elem (
                .clk     (clk),
                .reset   (reset),
                .enable  (enable),
                .data_in (prod_sel),
                .data_out(elem_prods[j])
            );
        end

        // Stage 1a: elements 4..7 (only valid for INT4/UINT4)
        for (genvar j = 4; j < MAX_PRODS; j++) begin : g_elem_hi
            wire signed [7:0] i4_prod = $signed(a_row[i][4*j +: 4]) * $signed(b_col[i][4*j +: 4]);
            wire        [7:0] u4_prod = a_row[i][4*j +: 4] * b_col[i][4*j +: 4];

            reg [31:0] prod_sel;
            always @(*) begin
                case (fmt_s)
                    TCU_I4_ID: prod_sel = {{24{i4_prod[7]}}, i4_prod};
                    TCU_U4_ID: prod_sel = {24'b0, u4_prod};
                    default:   prod_sel = '0;
                endcase
            end

            VX_pipe_register #(
                .DATAW (32),
                .DEPTH (1)
            ) pipe_elem (
                .clk     (clk),
                .reset   (reset),
                .enable  (enable),
                .data_in (prod_sel),
                .data_out(elem_prods[j])
            );
        end

        // Stage 1b: sum all element products per word (registered)
        reg [31:0] word_sum;
        always @(*) begin
            word_sum = 0;
            for (int j = 0; j < MAX_PRODS; j++) begin
                word_sum = word_sum + elem_prods[j];
            end
        end

        VX_pipe_register #(
            .DATAW (32),
            .DEPTH (1)
        ) pipe_word_sum (
            .clk     (clk),
            .reset   (reset),
            .enable  (enable),
            .data_in (word_sum),
            .data_out(int_word_prod[i])
        );
    end

    // Delay c_val and is_int by 2 cycles to align with Stage 1b output
    wire [31:0] int_c_s2;
    wire is_int_s2;

    VX_pipe_register #(
        .DATAW (32 + 1),
        .DEPTH (2)
    ) pipe_int_ctrl (
        .clk     (clk),
        .reset   (reset),
        .enable  (enable),
        .data_in ({c_val, is_int}),
        .data_out({int_c_s2, is_int_s2})
    );

    // Stage 2: cross-word accumulate + C (combinational, then piped to match FP latency)
    reg [31:0] int_acc;
    always @(*) begin
        int_acc = int_c_s2;
        for (int i = 0; i < N; i++) begin
            int_acc = int_acc + int_word_prod[i];
        end
    end

    wire [31:0] int_result;
    wire is_int_out;

    VX_pipe_register #(
        .DATAW (32 + 1),
        .DEPTH (TOTAL_LATENCY - 2)
    ) pipe_int (
        .clk     (clk),
        .reset   (reset),
        .enable  (enable),
        .data_in ({int_acc, is_int_s2}),
        .data_out({int_result, is_int_out})
    );

    // final FP accumulation
    wire [31:0] fp_result;
`ifdef DSP_TEST
    wire [63:0] a_h = {32'hffffffff, red_in[LEVELS][0]};
    wire [63:0] b_h = {32'hffffffff, delayed_c};
    reg [63:0] c_h;
    reg [4:0] fflags;
    `UNUSED_VAR({c_h[63:32], fflags});
    always @(*) begin
        dpi_fadd(enable, int'(0), a_h, b_h, 3'b0, c_h, fflags);
    end
    `BUFFER_EX(fp_result, c_h[31:0], enable, 0, FADD_LATENCY);
`else
    xil_fadd fadd_acc (
        .aclk                (clk),
        .aclken              (enable),
        .s_axis_a_tvalid     (1'b1),
        .s_axis_a_tdata      (red_in[LEVELS][0]),
        .s_axis_b_tvalid     (1'b1),
        .s_axis_b_tdata      (delayed_c),
        .s_axis_operation_tvalid (1'b1),
        .s_axis_operation_tdata (8'b0), // 0=add
        `UNUSED_PIN (m_axis_result_tvalid),
        .m_axis_result_tdata (fp_result)
    );
`endif

    // Output mux: integer or floating-point result
    assign d_val = is_int_out ? int_result : fp_result;

endmodule
