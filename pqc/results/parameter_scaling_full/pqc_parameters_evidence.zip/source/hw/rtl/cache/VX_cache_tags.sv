// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

`include "VX_cache_define.vh"

// Single-array tag store with per-way write-enable.
//
// All NUM_WAYS tags for a set live in one block-RAM word (read in parallel for
// the hit compare); a per-way write-enable updates a single way on a fill. This
// replaces the previous NUM_WAYS separate tag arrays with one BRAM.
//
// The tag BRAM holds the TAG ONLY. The per-sector valid vector is decoupled into
// a side LUTRAM (like the dirty vector): a sector refill ORs the fetched sector
// into the resident line's valid vector -- a read-modify-write. Done in the tag
// BRAM that RMW puts a tag-read -> compare -> valid-OR -> BRAM-write arc on the
// write-data path; in a per-bit-write LUTRAM the refill is a local per-bit set,
// so the tag BRAM write is just the registered line_tag and never depends on the
// read.

module VX_cache_tags import VX_gpu_pkg::*; #(
    parameter CACHE_SIZE    = 1024,           // Size of cache in bytes
    parameter LINE_SIZE     = 16,             // Size of line inside a bank in bytes
    parameter NUM_BANKS     = 1,              // Number of banks
    parameter NUM_WAYS      = 1,              // Number of associative ways
    parameter WORD_SIZE     = 1,              // Size of a word in bytes
    parameter SECTOR_SIZE   = LINE_SIZE,      // Size of a sector in bytes (fill/eviction granule); = LINE_SIZE => 1 sector
    parameter WRITEBACK     = 0,              // Enable cache writeback
    parameter AMO_ENABLE    = 0               // Enable the AMO-passthrough line invalidate (non-LLC banks only)
) (
    input wire                          clk,
    input wire                          reset,

    // inputs
    input wire                          stall,
    input wire                          init,
    input wire                          flush,
    input wire                          fill,
    input wire                          read,
    input wire                          write,
    input wire                          invalidate, // clear valid on the hit way
    input wire [`CS_LINE_SEL_BITS-1:0]  line_idx,
    input wire [`CS_LINE_SEL_BITS-1:0]  line_idx_n,
    input wire [`CS_TAG_SEL_BITS-1:0]   line_tag,
    input wire [`UP(`CS_SECTOR_SEL_BITS)-1:0] sector_idx, // requested sector within the line
    input wire [`CS_WAY_SEL_WIDTH-1:0]  evict_way,
    // fill target way as one-hot, taken from line_present/victim directly:
    // the binary evict_way round trip (encode, mux, per-way compare) put the
    // tag-read cone on this array's own write-enable pins.
    input wire [NUM_WAYS-1:0]           fill_way_oh,

    // outputs
    output wire [NUM_WAYS-1:0]          tag_matches,
    // per-way "line resident" = tag match with any sector valid, ignoring the
    // requested sector. Distinguishes a sector miss (line present, sector
    // invalid -> refill that sector into this way, no eviction) from a line
    // miss (line absent -> allocate a victim way). Equals tag_matches when
    // there is a single sector per line.
    output wire [NUM_WAYS-1:0]          line_present,
    output wire                         evict_dirty,
    // per-sector dirty vector of the evict way (drives the multi-beat per-sector
    // writeback); a single bit == evict_dirty when 1 sector/line.
    output wire [`CS_SECTORS_PER_LINE-1:0] evict_dirty_mask,
    output wire [`CS_TAG_SEL_BITS-1:0]  evict_tag
);
    //          tag store: tag only   (valid + dirty decoupled into side LUTRAMs)
    localparam SEC = `CS_SECTORS_PER_LINE;
    `UNUSED_VAR (read)

    // one-hot of the requested sector (SEC=1 => constant 1)
    wire [SEC-1:0] sec_oh = SEC'(1) << sector_idx;

    wire [NUM_WAYS-1:0][`CS_TAG_SEL_BITS-1:0] read_tag;
    wire [NUM_WAYS-1:0][SEC-1:0] read_valid;
    wire [NUM_WAYS-1:0][SEC-1:0] read_dirty;

    if (WRITEBACK) begin : g_evict_tag_wb
        assign evict_dirty = (| read_dirty[evict_way]); // dirty if any sector dirty
        assign evict_dirty_mask = read_dirty[evict_way];
        assign evict_tag = read_tag[evict_way];
    end else begin : g_evict_tag_wt
        `UNUSED_VAR (read_dirty)
        `UNUSED_VAR (read_tag)
        assign evict_dirty = 1'b0;
        assign evict_dirty_mask = '0;
        assign evict_tag = '0;
    end

    // Per-way decoded write strobes and payloads. At most one operation type
    // fires per cycle (input arbitration in the bank). The tag store holds the
    // tag only and is written (with the registered line_tag) only on a fill, so
    // its write never depends on the tag compare.
    wire [NUM_WAYS-1:0] line_write;
    wire [NUM_WAYS-1:0][`CS_TAG_SEL_BITS-1:0] line_wdata;
    wire [NUM_WAYS-1:0][`CS_TAG_SEL_BITS-1:0] tag_rdata;

    // Decoupled per-sector valid store: NUM_WAYS*SEC bits/set in LUTRAM, per-bit
    // write-enable. A sector refill sets its bit locally instead of ORing through
    // the tag BRAM. Placed next to the compare so its route collapses.
    wire [NUM_WAYS-1:0][SEC-1:0] valid_wren;
    wire [NUM_WAYS-1:0][SEC-1:0] valid_wdata;
    wire [NUM_WAYS-1:0][SEC-1:0] valid_rdata;

    // Decoupled per-sector dirty store (writeback only): NUM_WAYS*SEC bits/set
    // in LUTRAM, per-bit write-enable. Placed locally next to the compare so its
    // route collapses; keeps the wide tag-compare->dirty-set loop off the tag BRAM.
    wire [NUM_WAYS-1:0][SEC-1:0] dirty_wren;
    wire [NUM_WAYS-1:0][SEC-1:0] dirty_wdata;
    wire [NUM_WAYS-1:0][SEC-1:0] dirty_rdata;

    for (genvar i = 0; i < NUM_WAYS; ++i) begin : g_way_decode
        wire way_en   = (NUM_WAYS == 1) || (evict_way == i);
        wire do_init  = init; // init all ways
        // The fill way select comes in one-hot (line_present or the registered
        // victim decode); the binary way_en compare stays only for flush, whose
        // way is the registered st0 way_idx and never this cycle's tag read.
        wire do_fill  = fill && ((NUM_WAYS == 1) || fill_way_oh[i]);
        wire do_flush = flush && (!WRITEBACK || way_en); // flush all ways in writethrough mode
        wire do_write = WRITEBACK && write && tag_matches[i]; // only write on tag hit

        // Tag store: the tag changes only on a fill (a refill rewrites the
        // identical tag, harmless), so its write-enable does not depend on the
        // compare and its write-data is the registered line_tag. init/flush/
        // invalidate only touch the valid vector (below), never the tag.
        assign line_write[i] = do_fill;
        assign line_wdata[i] = line_tag;

        // Read-First BRAM: a fill committed on the previous cycle isn't yet in
        // the readout. The bypass is keyed on the SET and the FILLED WAY: that
        // way's stale entry is replaced with the filled line's {tag, valid},
        // so a same-set request neither false-hits the just-evicted line nor
        // misses the just-installed one. The bypass must HOLD across a pipe
        // stall (gated by ~stall): when a fill is followed by a dependent
        // replay and the pipe stalls in between (e.g. a multi-beat per-sector
        // writeback), the held tag readout still misses the fill, so a plain
        // 1-cycle buffer would expire mid-stall and the replay would
        // spuriously miss the just-filled line.
        wire rdw_fill_raw;
        wire [SEC-1:0] rdw_sec_oh;
        wire [`CS_TAG_SEL_BITS-1:0]  rdw_tag;
        wire [`CS_LINE_SEL_BITS-1:0] rdw_set;
        wire rdw_refill;
        `BUFFER_EX(rdw_fill_raw, do_fill, ~stall, 1, 1);
        `BUFFER_EX(rdw_sec_oh, sec_oh, ~stall, $bits(rdw_sec_oh), 1);
        `BUFFER_EX(rdw_tag, line_tag, ~stall, $bits(rdw_tag), 1);
        `BUFFER_EX(rdw_set, line_idx, ~stall, $bits(rdw_set), 1);
        // do_fill is way-gated, so rdw_fill_raw identifies the filled way.
        wire way_filled = rdw_fill_raw && (line_idx == rdw_set);

        // Tag equality with the bypass folded in: both compares run in parallel
        // and way_filled selects the result, so the set compare never sits in
        // series with the wide tag compare on the tag->data write-enable arc.
        wire tag_eq = way_filled ? (line_tag == rdw_tag) : (line_tag == tag_rdata[i]);

        // hit: tag match AND the requested sector is valid. read_valid folds in
        // a same-set fill from the previous cycle (see the bypass above), so
        // this compare is exact even on the fill's write edge.
        wire raw_hit = read_valid[i][sector_idx] && tag_eq;
        // AMO passthrough invalidate: clear the requested sector's valid.
        wire do_inval = (AMO_ENABLE != 0) && invalidate && raw_hit;

        // A fill into a way that already holds this line (a sector refill) sets
        // the fetched sector in the existing valid vector; a fill into a fresh
        // victim way installs only the fetched sector (others cleared). With
        // 1 sector/line a fill is always to a fresh way.
        wire fill_refill = do_fill && tag_eq && (| read_valid[i]);
        `BUFFER_EX(rdw_refill, do_fill && fill_refill, ~stall, 1, 1);

        // Per-sector valid update as per-bit set/clear for the LUTRAM (no
        // read-modify-write): set the filled sector; clear the whole line on
        // init/flush, the other sectors on a fresh victim install, the requested
        // sector on invalidate.
        wire [SEC-1:0] vset_oh = do_fill ? sec_oh : {SEC{1'b0}};
        wire [SEC-1:0] vclr_oh = ((do_init || do_flush)     ? {SEC{1'b1}} : {SEC{1'b0}})
                               | ((do_fill && ~fill_refill) ? ~sec_oh     : {SEC{1'b0}})
                               | (do_inval                  ? sec_oh      : {SEC{1'b0}});
        assign valid_wren[i]  = vset_oh | vclr_oh;
        assign valid_wdata[i] = vset_oh;

        // Tag from the tag BRAM, valid from the decoupled LUTRAM. Both share the
        // same look-ahead read / read-first access pattern, so the way_filled
        // bypass corrects the just-filled line for both. A fresh fill REPLACED
        // this way's entry; a refill set its sector in the resident line's vector.
        wire [SEC-1:0] rdata_valid = valid_rdata[i];
        assign read_tag[i]   = way_filled ? rdw_tag : tag_rdata[i];
        assign read_valid[i] = way_filled ? (rdw_refill ? (rdata_valid | rdw_sec_oh) : rdw_sec_oh)
                                          : rdata_valid;

        // ---- decoupled per-sector dirty (writeback only) ----
        if (WRITEBACK) begin : g_dirty
            // set the written sector on a write hit; clear sectors on
            // fill/inval; clear all on init/flush or a fresh (evicting) fill.
            wire [SEC-1:0] dset_oh  = do_write ? sec_oh : {SEC{1'b0}};
            wire           dclr_all = do_init || do_flush || (do_fill && ~fill_refill);
            wire [SEC-1:0] dclr_oh  = (do_inval ? sec_oh : {SEC{1'b0}})
                                    | ((do_fill && fill_refill) ? sec_oh : {SEC{1'b0}});
            assign dirty_wren[i]  = dset_oh | dclr_oh | {SEC{dclr_all}};
            assign dirty_wdata[i] = dset_oh; // 1 only where setting; 0 on any clear

            // Read-first forwarding for the dirty LUTRAM (same-set, 1 cycle, held
            // across stall): a dirty update to this set last cycle isn't in the
            // readout when the next request reads the same set. Clear wins over
            // the stale readout; set wins over clear (mutually exclusive ops).
            wire same_set = (line_idx == line_idx_n);
            wire [SEC-1:0] rdw_dset, rdw_dclr;
            wire rdw_dclr_all;
            `BUFFER_EX(rdw_dset, (same_set ? dset_oh : {SEC{1'b0}}), ~stall, SEC, 1);
            `BUFFER_EX(rdw_dclr, (same_set ? dclr_oh : {SEC{1'b0}}), ~stall, SEC, 1);
            `BUFFER_EX(rdw_dclr_all, same_set && dclr_all, ~stall, 1, 1);
            assign read_dirty[i] = (dirty_rdata[i] & ~rdw_dclr & ~{SEC{rdw_dclr_all}}) | rdw_dset;
        end else begin : g_no_dirty
            `UNUSED_VAR (do_write)
            assign dirty_wren[i]  = '0;
            assign dirty_wdata[i] = '0;
            assign read_dirty[i]  = {SEC{1'b0}};
        end

        assign tag_matches[i] = raw_hit;
        // line resident in this way: tag matches and at least one sector valid
        // (a same-cycle-prior fill is folded into tag_eq/read_valid).
        assign line_present[i] = tag_eq && (| read_valid[i]);
    end

    // Single tag array: one BRAM word holds all ways' tags; per-way write-enable
    // updates a single way on a fill. Read at line_idx_n (one cycle ahead),
    // written at line_idx, read-first to match the fill/replay ordering.
    VX_dp_ram #(
        .DATAW (NUM_WAYS * `CS_TAG_SEL_BITS),
        .WRENW (NUM_WAYS),
        .SIZE  (`CS_LINES_PER_BANK),
        .OUT_REG (1),
        .RDW_MODE ("R")
    ) tag_store (
        .clk   (clk),
        .reset (reset),
        .read  (~stall),
        // fill alone: only fills write the tag store, and the fill way select
        // (one-hot) always names exactly one way, so |line_write == fill --
        // an identity synthesis cannot prove, leaving the way-select cone on
        // the array's global enable.
        .write (fill),
        .wren  (line_write),
        .waddr (line_idx),
        .raddr (line_idx_n),
        .wdata (line_wdata),
        .rdata (tag_rdata)
    );

    // Decoupled per-sector valid store: mirrors the tag BRAM's access pattern
    // (look-ahead read, read-first) so pipeline alignment is identical, with
    // per-bit write-enable so a sector refill sets its bit without reading back.
    VX_dp_ram #(
        .DATAW    (NUM_WAYS * SEC),
        .WRENW    (NUM_WAYS * SEC),
        .SIZE     (`CS_LINES_PER_BANK),
        .OUT_REG  (1),
        .LUTRAM   (1),
        .RDW_MODE ("R")
    ) valid_store (
        .clk   (clk),
        .reset (reset),
        .read  (~stall),
        .write (| valid_wren),
        .wren  (valid_wren),
        .waddr (line_idx),
        .raddr (line_idx_n),
        .wdata (valid_wdata),
        .rdata (valid_rdata)
    );

    // Decoupled per-sector dirty store (writeback only). Mirrors the tag store's
    // access pattern (look-ahead read, read-first) so pipeline alignment is
    // identical; 1-bit/way/sector LUTRAM keeps it off the tag BRAM write path.
    if (WRITEBACK) begin : g_dirty_store
        VX_dp_ram #(
            .DATAW    (NUM_WAYS * SEC),
            .WRENW    (NUM_WAYS * SEC),
            .SIZE     (`CS_LINES_PER_BANK),
            .OUT_REG  (1),
            .LUTRAM   (1),
            .RDW_MODE ("R")
        ) dirty_store (
            .clk   (clk),
            .reset (reset),
            .read  (~stall),
            .write (| dirty_wren),
            .wren  (dirty_wren),
            .waddr (line_idx),
            .raddr (line_idx_n),
            .wdata (dirty_wdata),
            .rdata (dirty_rdata)
        );
    end else begin : g_no_dirty_store
        assign dirty_rdata = '0;
        `UNUSED_VAR ({dirty_wren, dirty_wdata, dirty_rdata})
    end

endmodule
