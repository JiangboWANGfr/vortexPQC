// Copyright © 2019-2023
// Licensed under the Apache License, Version 2.0.

`include "VX_define.vh"

// ============================================================================
// VX_cp_core — top-level Command Processor wrapper.
//
// Integrates everything in rtl/cp/ into one block the AFU shim can
// instantiate alongside Vortex:
//
//                         ┌──────────────────────────┐
//   AXI4-Lite host ──────►│  VX_cp_axil_regfile      │── per-queue
//   (control plane)       │                          │   cpe_state
//                         └──┬───────────────────────┘
//                            │ q_state[NUM_QUEUES]
//                  ┌─────────┴────────┬──────────────┬──────────┐
//                  │ fetch[NUM_QUEUES] │ engine[N]    │ cmpl     │
//                  │ + embedded unpack │  + 4 bid     │  retire  │
//                  │  → cmd_in stream  │    arbiters  │   slots  │
//                  └─────────┬─────────┴───┬──────────┴────┬─────┘
//                            │              │               │
//                            ▼              ▼               ▼
//      ┌──────────────────────────────┐   ┌────────────────────────┐
//      │  host xbar: fetch[N] + cmpl  │   │  dev xbar: DMA(dev) +   │
//      │            + DMA(host)       │   │            event       │
//      └───────────────┬──────────────┘   └───────────┬────────────┘
//                      ▼ axi_host (AXI4)              ▼ axi_dev (AXI4)
//
//   Dual data plane: XRT pins each kernel AXI master to exactly one memory
//   resource, so the CP carries two — axi_host reaches host memory (the
//   command ring lives there; it is one end of every upload/download) and
//   axi_dev reaches device memory. The DMA engine straddles both: its
//   opcode picks the read-source and write-destination port.
//
//   The shared KMU launch / DCR proxy connect to gpu_if (Vortex side).
//
// AXI master TID layout (per xbar):
//   bit [ID_W-1 : ID_W-SRC_W]  = source index (xbar sets/inspects this for
//                                response routing)
//   bit [ID_W-SRC_W-1 : 0]     = sub-tag, source-defined
// ============================================================================

// Connect a VX_mem_axi_if `src` (master) to a `slot` of an xbar's `src`
// array (the xbar drives that array as an AXI slave).
`define CP_AXI_LINK(slot, src)            \
  assign slot.awvalid = src.awvalid;      \
  assign slot.awaddr  = src.awaddr;       \
  assign slot.awid    = src.awid;         \
  assign slot.awlen   = src.awlen;        \
  assign slot.awsize  = src.awsize;       \
  assign slot.awburst = src.awburst;      \
  assign src.awready  = slot.awready;     \
  assign slot.wvalid  = src.wvalid;       \
  assign slot.wdata   = src.wdata;        \
  assign slot.wstrb   = src.wstrb;        \
  assign slot.wlast   = src.wlast;        \
  assign src.wready   = slot.wready;      \
  assign src.bvalid   = slot.bvalid;      \
  assign src.bid      = slot.bid;         \
  assign src.bresp    = slot.bresp;       \
  assign slot.bready  = src.bready;       \
  assign slot.arvalid = src.arvalid;      \
  assign slot.araddr  = src.araddr;       \
  assign slot.arid    = src.arid;         \
  assign slot.arlen   = src.arlen;        \
  assign slot.arsize  = src.arsize;       \
  assign slot.arburst = src.arburst;      \
  assign src.arready  = slot.arready;     \
  assign src.rvalid   = slot.rvalid;      \
  assign src.rdata    = slot.rdata;       \
  assign src.rid      = slot.rid;         \
  assign src.rlast    = slot.rlast;       \
  assign src.rresp    = slot.rresp;       \
  assign slot.rready  = src.rready

module VX_cp_core
  import VX_cp_pkg::*;
#(
  parameter int NUM_QUEUES = VX_CP_NUM_QUEUES_C,
  parameter int ADDR_W     = 64,
  parameter int DATA_W     = 512,
  parameter int ID_W       = VX_CP_AXI_TID_WIDTH_C,
  parameter int AXIL_AW    = 16
)(
  input  wire                       clk,
  input  wire                       reset,

  // Host control plane (AXI4-Lite slave).
  VX_cp_axil_s_if.slave             axil_s,

  // Host-memory data plane (AXI4 master) — command ring + completion +
  // host side of every upload/download.
  VX_mem_axi_if.master             axi_host,

  // Device-memory data plane (AXI4 master) — device side of upload/download
  // and event-counter traffic.
  VX_mem_axi_if.master             axi_dev,

  // AFU host-port drain counters, packed by VX_afu_wrap; regfile debug regs.
  input  wire [31:0]               dbg_host_w_counts,
  input  wire [31:0]               dbg_host_r_counts,

  // GPU-facing handshake (Vortex DCR + start/busy).
  VX_cp_gpu_if.master               gpu_if,

  // One-cycle pulse after any queue retires a command (drives the
  // platform irq pin). Named `irq` rather than `interrupt` because the
  // latter is a SystemVerilog reserved keyword (Verilator SYMRSVDWORD).
  output wire                       irq
);

  // Host xbar sources: fetch[NUM_QUEUES] + completion + DMA(host side).
  localparam int N_SRC_HOST = NUM_QUEUES + 2;
  // Device xbar sources: DMA(dev side) + event unit.
  localparam int N_SRC_DEV  = 2;

  // Source-slot indices.
  localparam int SLOT_CMPL     = NUM_QUEUES;       // host xbar
  localparam int SLOT_DMA_HOST = NUM_QUEUES + 1;   // host xbar
  localparam int SLOT_DMA_DEV  = 0;                // dev xbar
  localparam int SLOT_EVENT    = 1;                // dev xbar

  // ----- Regfile-owned per-queue programmable state -----
  cpe_state_t q_state          [NUM_QUEUES];
  logic       q_reset_pulse    [NUM_QUEUES];

  // Telemetry inputs from CPEs to the regfile.
  logic [63:0] q_head_to_reg   [NUM_QUEUES];
  logic [63:0] q_seqnum_to_reg [NUM_QUEUES];
  logic [31:0] q_error_to_reg  [NUM_QUEUES];

  // Aggregated CP status seen by the host through CP_STATUS.
  logic cp_busy;
  logic cp_error;

  wire [`VX_DCR_DATA_BITS-1:0] dcr_last_rsp_data;

  // Queue-reset plumbing (used by the regfile port map directly below and by
  // the g_queue_reset block; declared BEFORE first use -- Vivado mints 1-bit
  // implicit nets at a pre-declaration use and keeps both, which silently
  // severed q_clear_ack from the real q_clear in synthesis while Verilator
  // accepted the ordering. Same footgun as the drain-counter wires in
  // VX_afu_wrap.)
  logic       q_reset_pending [NUM_QUEUES];
  logic       q_clear         [NUM_QUEUES];
  logic       fetch_idle      [NUM_QUEUES];
  logic       engine_idle     [NUM_QUEUES];

  VX_cp_axil_regfile #(
    .NUM_QUEUES (NUM_QUEUES),
    .ADDR_W     (AXIL_AW)
  ) u_regfile (
    .clk            (clk),
    .reset          (reset),
    .axil_s         (axil_s),
    .cp_busy        (cp_busy),
    .cp_error       (cp_error),
    .q_head         (q_head_to_reg),
    .q_seqnum       (q_seqnum_to_reg),
    .q_error        (q_error_to_reg),
    .last_dcr_rsp   (dcr_last_rsp_data),
    .q_state        (q_state),
    .q_reset_pulse  (q_reset_pulse),
    .q_clear_ack    (q_clear),
    .dbg_host_w_counts (dbg_host_w_counts),
    .dbg_host_r_counts (dbg_host_r_counts)
  );

  // ----- Per-CPE wires -----
  logic [63:0] seqnum_out [NUM_QUEUES];

  // Bid lines to the four arbiters.
  VX_cp_engine_bid_if bid_kmu   [NUM_QUEUES] ();
  VX_cp_engine_bid_if bid_dma   [NUM_QUEUES] ();
  VX_cp_engine_bid_if bid_dcr   [NUM_QUEUES] ();
  VX_cp_engine_bid_if bid_event [NUM_QUEUES] ();

  // Retire + profile pulses from each CPE. retire_evt is held by the
  // engine until retire_ready (from VX_cp_completion) handshakes.
  logic        retire_evt    [NUM_QUEUES];
  logic [63:0] retire_seqnum [NUM_QUEUES];
  logic        retire_ready  [NUM_QUEUES];
  logic        submit_evt    [NUM_QUEUES];
  logic        start_evt     [NUM_QUEUES];
  logic        end_evt       [NUM_QUEUES];
  logic [63:0] profile_slot  [NUM_QUEUES];

  // Per-CPE fetch → engine streaming command port.
  logic       cpe_cmd_valid [NUM_QUEUES];
  cmd_t       cpe_cmd       [NUM_QUEUES];
  logic       cpe_cmd_ready [NUM_QUEUES];

  // Shared-resource done pulses.
  logic launch_done, dma_done, dcr_done, event_done;

  // Per-CPE AXI sub-master ports (fetch is the only AXI user per CPE).
  VX_mem_axi_if #(.ADDR_W(ADDR_W), .DATA_W(DATA_W), .ID_W(ID_W))
                       fetch_axi [NUM_QUEUES] ();

  // ----- N CPEs (fetch + engine) -----
  generate
    for (genvar q = 0; q < NUM_QUEUES; ++q) begin : g_cpe
      VX_cp_fetch #(.QID(q)) u_fetch (
        .clk           (clk),
        .reset         (reset),
        .state_in      (q_state[q]),
        .head_out      (q_head_to_reg[q]),
        .cmd_out_valid (cpe_cmd_valid[q]),
        .cmd_out       (cpe_cmd[q]),
        .cmd_out_ready (cpe_cmd_ready[q]),
        .stop_req      (q_reset_pending[q]),
        .clear         (q_clear[q]),
        .idle          (fetch_idle[q]),
        .axi_m         (fetch_axi[q])
      );

      VX_cp_engine #(.QID(q)) u_engine (
        .clk           (clk),
        .reset         (reset),
        .prio_in       (q_state[q].prio),
        .seqnum_out    (seqnum_out[q]),
        .cmd_in_valid  (cpe_cmd_valid[q]),
        .cmd_in        (cpe_cmd[q]),
        .cmd_in_ready  (cpe_cmd_ready[q]),
        .bid_kmu       (bid_kmu[q]),
        .bid_dma       (bid_dma[q]),
        .bid_dcr       (bid_dcr[q]),
        .bid_event     (bid_event[q]),
        // Done pulses are broadcast from the shared resource modules to
        // every CPE; only the granted CPE is in S_WAIT_DONE when the
        // matching pulse arrives.
        .kmu_done_i    (launch_done),
        .dma_done_i    (dma_done),
        .dcr_done_i    (dcr_done),
        .event_done_i  (event_done),
        .retire_evt    (retire_evt[q]),
        .retire_seqnum (retire_seqnum[q]),
        .retire_ready_i(retire_ready[q]),
        .submit_evt    (submit_evt[q]),
        .start_evt     (start_evt[q]),
        .end_evt       (end_evt[q]),
        .profile_slot  (profile_slot[q]),
        .clear         (q_clear[q]),
        .idle          (engine_idle[q])
      );

      // Telemetry up to the regfile.
      assign q_seqnum_to_reg[q] = seqnum_out[q];
      assign q_error_to_reg [q] = 32'd0;   // per-queue error reporting reserved
    end
  endgenerate

  // ----- Four resource arbiters (round-robin) -----
  wire        kmu_valid   [NUM_QUEUES];
  wire [1:0]  kmu_prio    [NUM_QUEUES];
  cmd_t       kmu_cmd     [NUM_QUEUES];
  logic       kmu_grant   [NUM_QUEUES];

  wire        dma_valid   [NUM_QUEUES];
  wire [1:0]  dma_prio    [NUM_QUEUES];
  cmd_t       dma_cmd     [NUM_QUEUES];
  logic       dma_grant   [NUM_QUEUES];

  wire        dcr_valid   [NUM_QUEUES];
  wire [1:0]  dcr_prio    [NUM_QUEUES];
  cmd_t       dcr_cmd     [NUM_QUEUES];
  logic       dcr_grant   [NUM_QUEUES];

  wire        event_valid [NUM_QUEUES];
  wire [1:0]  event_prio  [NUM_QUEUES];
  cmd_t       event_cmd   [NUM_QUEUES];
  logic       event_grant [NUM_QUEUES];

  generate
    for (genvar q = 0; q < NUM_QUEUES; ++q) begin : g_unpack_bids
      assign kmu_valid[q]     = bid_kmu[q].valid;
      assign kmu_prio[q]      = bid_kmu[q].priority_;
      assign kmu_cmd[q]       = bid_kmu[q].cmd;
      assign bid_kmu[q].grant = kmu_grant[q];

      assign dma_valid[q]     = bid_dma[q].valid;
      assign dma_prio[q]      = bid_dma[q].priority_;
      assign dma_cmd[q]       = bid_dma[q].cmd;
      assign bid_dma[q].grant = dma_grant[q];

      assign dcr_valid[q]     = bid_dcr[q].valid;
      assign dcr_prio[q]      = bid_dcr[q].priority_;
      assign dcr_cmd[q]       = bid_dcr[q].cmd;
      assign bid_dcr[q].grant = dcr_grant[q];

      assign event_valid[q]     = bid_event[q].valid;
      assign event_prio[q]      = bid_event[q].priority_;
      assign event_cmd[q]       = bid_event[q].cmd;
      assign bid_event[q].grant = event_grant[q];
    end
  endgenerate

  VX_cp_arbiter #(.N(NUM_QUEUES)) u_arb_kmu (
    .clk(clk), .reset(reset),
    .bid_valid(kmu_valid), .bid_priority(kmu_prio), .bid_grant(kmu_grant)
  );
  VX_cp_arbiter #(.N(NUM_QUEUES)) u_arb_dma (
    .clk(clk), .reset(reset),
    .bid_valid(dma_valid), .bid_priority(dma_prio), .bid_grant(dma_grant)
  );
  VX_cp_arbiter #(.N(NUM_QUEUES)) u_arb_dcr (
    .clk(clk), .reset(reset),
    .bid_valid(dcr_valid), .bid_priority(dcr_prio), .bid_grant(dcr_grant)
  );
  VX_cp_arbiter #(.N(NUM_QUEUES)) u_arb_event (
    .clk(clk), .reset(reset),
    .bid_valid(event_valid), .bid_priority(event_prio), .bid_grant(event_grant)
  );

  // ----- Pick the granted bid's cmd for each shared resource -----
  logic any_kmu_grant, any_dma_grant, any_dcr_grant, any_event_grant;
  cmd_t granted_kmu_cmd, granted_dma_cmd, granted_dcr_cmd, granted_event_cmd;
  always_comb begin
    any_kmu_grant = 1'b0; granted_kmu_cmd = '0;
    any_dma_grant = 1'b0; granted_dma_cmd = '0;
    any_dcr_grant = 1'b0; granted_dcr_cmd = '0;
    any_event_grant = 1'b0; granted_event_cmd = '0;
    for (int i = 0; i < NUM_QUEUES; ++i) begin
      if (kmu_grant[i])   begin any_kmu_grant   = 1'b1; granted_kmu_cmd   = kmu_cmd[i];   end
      if (dma_grant[i])   begin any_dma_grant   = 1'b1; granted_dma_cmd   = dma_cmd[i];   end
      if (dcr_grant[i])   begin any_dcr_grant   = 1'b1; granted_dcr_cmd   = dcr_cmd[i];   end
      if (event_grant[i]) begin any_event_grant = 1'b1; granted_event_cmd = event_cmd[i]; end
    end
  end

  `UNUSED_VAR (granted_kmu_cmd)

  // Internal CP-side bundle; the register slice isolating it from the Vortex
  // boundary (gpu_if) is instantiated at the bottom of the module.
  VX_cp_gpu_if gpu_if_int();

  // ----- Shared KMU launch (consumes the kmu bid grant) -----
  VX_cp_launch u_launch (
    .clk      (clk),
    .reset    (reset),
    .grant    (any_kmu_grant),
    .start    (gpu_if_int.start),
    .gpu_busy (gpu_if_int.busy),
    .done     (launch_done)
  );

  // ----- Shared DCR proxy -----
  VX_cp_dcr_proxy u_dcr (
    .clk           (clk),
    .reset         (reset),
    .grant         (any_dcr_grant),
    .cmd           (granted_dcr_cmd),
    .done          (dcr_done),
    .last_rsp_data (dcr_last_rsp_data),
    .dcr_req_valid (gpu_if_int.dcr_req_valid),
    .dcr_req_rw    (gpu_if_int.dcr_req_rw),
    .dcr_req_addr  (gpu_if_int.dcr_req_addr),
    .dcr_req_data  (gpu_if_int.dcr_req_data),
    .dcr_rsp_valid (gpu_if_int.dcr_rsp_valid),
    .dcr_rsp_data  (gpu_if_int.dcr_rsp_data)
  );
  `UNUSED_VAR (gpu_if_int.dcr_req_ready)

  // ----- DMA (straddles host + dev xbars) -----
  VX_mem_axi_if #(.ADDR_W(ADDR_W), .DATA_W(DATA_W), .ID_W(ID_W)) dma_host_axi ();
  VX_mem_axi_if #(.ADDR_W(ADDR_W), .DATA_W(DATA_W), .ID_W(ID_W)) dma_dev_axi  ();
  VX_mem_axi_if #(.ADDR_W(ADDR_W), .DATA_W(DATA_W), .ID_W(ID_W)) cmpl_axi     ();
  VX_mem_axi_if #(.ADDR_W(ADDR_W), .DATA_W(DATA_W), .ID_W(ID_W)) event_axi    ();

  VX_cp_dma u_dma (
    .clk      (clk),
    .reset    (reset),
    .grant    (any_dma_grant),
    .cmd      (granted_dma_cmd),
    .done     (dma_done),
    .axi_host (dma_host_axi),
    .axi_dev  (dma_dev_axi)
  );

  // ----- Event unit (CMD_EVENT_SIGNAL / CMD_EVENT_WAIT) -----
  VX_cp_event_unit u_event (
    .clk   (clk),
    .reset (reset),
    .grant (any_event_grant),
    .cmd   (granted_event_cmd),
    .done  (event_done),
    .axi_m (event_axi)
  );

  // ----- Completion writeback (host memory) -----
  wire [63:0] cmpl_addr_arr [NUM_QUEUES];
  generate
    for (genvar q = 0; q < NUM_QUEUES; ++q) begin : g_cmpl_addr
      assign cmpl_addr_arr[q] = q_state[q].cmpl_addr;
    end
  endgenerate

  VX_cp_completion #(
    .NUM_QUEUES (NUM_QUEUES)
  ) u_completion (
    .clk           (clk),
    .reset         (reset),
    .retire_evt    (retire_evt),
    .retire_seqnum (retire_seqnum),
    .cmpl_addr     (cmpl_addr_arr),
    .retire_ready  (retire_ready),
    .axi_m         (cmpl_axi)
  );

  // ============================================================================
  // Host xbar — fetch[N] + completion + DMA(host) → axi_host.
  // ============================================================================
  VX_mem_axi_if #(.ADDR_W(ADDR_W), .DATA_W(DATA_W), .ID_W(ID_W))
                       xbar_host_src [N_SRC_HOST] ();

  generate
    for (genvar q = 0; q < NUM_QUEUES; ++q) begin : g_host_fetch
      `CP_AXI_LINK(xbar_host_src[q], fetch_axi[q]);
    end
  endgenerate

  `CP_AXI_LINK(xbar_host_src[SLOT_CMPL],     cmpl_axi);
  `CP_AXI_LINK(xbar_host_src[SLOT_DMA_HOST], dma_host_axi);

  // Register slice that breaks the long, routing-dominated path from the CP
  // masters to the far-side host-memory AXI so the kernel clock can close.
  VX_mem_axi_if #(
    .ADDR_W (ADDR_W),
    .DATA_W (DATA_W),
    .ID_W   (ID_W)
  ) axi_host_pre [1] ();

  // Multi-outstanding (ID-routed) fan-in: sources leave the top LOG2UP(N) ID
  // bits free; the arb tags them with the source index and demuxes B/R back,
  // so the CP's sources keep concurrent transactions in flight.
  VX_mem_axi_xbar #(
    .NUM_INPUTS  (N_SRC_HOST),
    .NUM_OUTPUTS (1),
    .ADDR_WIDTH  (ADDR_W),
    .DATA_WIDTH  (DATA_W),
    .ID_WIDTH    (ID_W),
    .MULTI_OUT   (1)
  ) u_xbar_host (
    .clk   (clk),
    .reset (reset),
    .s     (xbar_host_src),
    .m     (axi_host_pre)
  );

  VX_mem_axi_slice #(
    .ADDR_WIDTH (ADDR_W),
    .DATA_WIDTH (DATA_W),
    .ID_WIDTH   (ID_W)
  ) u_slice_host (
    .clk   (clk),
    .reset (reset),
    .s     (axi_host_pre[0]),
    .m     (axi_host)
  );

  // ============================================================================
  // Device xbar — DMA(dev) + event → axi_dev.
  // ============================================================================
  VX_mem_axi_if #(.ADDR_W(ADDR_W), .DATA_W(DATA_W), .ID_W(ID_W))
                       xbar_dev_src [N_SRC_DEV] ();

  `CP_AXI_LINK(xbar_dev_src[SLOT_DMA_DEV], dma_dev_axi);
  `CP_AXI_LINK(xbar_dev_src[SLOT_EVENT],   event_axi);

  // Register slice on the path to device memory (memory subsystem).
  VX_mem_axi_if #(
    .ADDR_W (ADDR_W),
    .DATA_W (DATA_W),
    .ID_W   (ID_W)
  ) axi_dev_pre [1] ();

  VX_mem_axi_xbar #(
    .NUM_INPUTS  (N_SRC_DEV),
    .NUM_OUTPUTS (1),
    .ADDR_WIDTH  (ADDR_W),
    .DATA_WIDTH  (DATA_W),
    .ID_WIDTH    (ID_W),
    .MULTI_OUT   (1)
  ) u_xbar_dev (
    .clk   (clk),
    .reset (reset),
    .s     (xbar_dev_src),
    .m     (axi_dev_pre)
  );

  VX_mem_axi_slice #(
    .ADDR_WIDTH (ADDR_W),
    .DATA_WIDTH (DATA_W),
    .ID_WIDTH   (ID_W)
  ) u_slice_dev (
    .clk   (clk),
    .reset (reset),
    .s     (axi_dev_pre[0]),
    .m     (axi_dev)
  );

  // ----- Aggregated status -----
  // Busy if any CPE has a command in flight or any shared resource is active.
  always_comb begin
    cp_busy = 1'b0;
    cp_error = 1'b0;
    for (int i = 0; i < NUM_QUEUES; ++i) begin
      if (cpe_cmd_valid[i]) cp_busy = 1'b1;
    end
    if (any_kmu_grant || any_dma_grant || any_dcr_grant ||
        any_event_grant) cp_busy = 1'b1;
  end

  // ----- Queue reset (Q_CONTROL.reset / CP_CTRL.reset_all) -----
  //
  // The pulse from the regfile is latched as a *pending* request rather than
  // applied immediately. While it is pending the fetch stops issuing new
  // reads, so the CPE drains to idle on its own; the clear is then applied in
  // the single cycle when both the fetch and the engine report idle. That
  // keeps the head pointer, the retire counter and the host-visible tail
  // consistent, and it never abandons an AXI read the fetch has in flight.
  //
  // Without this the counters survived a process exit, a fresh process
  // inherited them, and its queue silently never ran because the fetch gate
  // is `head < tail` on absolute byte counts.
  generate
    for (genvar q = 0; q < NUM_QUEUES; ++q) begin : g_queue_reset
      always_ff @(posedge clk) begin
        if (reset) begin
          q_reset_pending[q] <= 1'b0;
        end else if (q_reset_pulse[q]) begin
          q_reset_pending[q] <= 1'b1;
        end else if (q_clear[q]) begin
          q_reset_pending[q] <= 1'b0;
        end
      end

      assign q_clear[q] = q_reset_pending[q]
                       && fetch_idle[q]
                       && engine_idle[q];
    end
  endgenerate

  // ----- IRQ: one-cycle pulse after any queue retires a command.
  // No host-visible ack/ISR register yet (runtime polls Q_SEQNUM);
  // this drives the platform irq pin for future interrupt-driven launch-wait. -----
  reg irq_r;
  always_ff @(posedge clk) begin
    if (reset) begin
      irq_r <= 1'b0;
    end else begin
      irq_r <= 1'b0;
      for (int q = 0; q < NUM_QUEUES; ++q) begin
        if (retire_evt[q])
          irq_r <= 1'b1;
      end
    end
  end
  assign irq = irq_r;

  // Profiling pulses fired by each engine are not routed externally yet;
  // suppress unused-signal warnings here.
  generate
    for (genvar q = 0; q < NUM_QUEUES; ++q) begin : g_unused_prof
      `UNUSED_VAR (submit_evt[q])
      `UNUSED_VAR (start_evt[q])
      `UNUSED_VAR (end_evt[q])
      `UNUSED_VAR (profile_slot[q])
    end
  endgenerate

  `UNUSED_PARAM (ADDR_W)
  `UNUSED_PARAM (DATA_W)

  // Register slice on the CP <-> Vortex boundary (SLR-safe crossing).
  VX_cp_gpu_slice u_gpu_slice (
    .clk      (clk),
    .reset    (reset),
    .cp_side  (gpu_if_int),
    .gpu_side (gpu_if)
  );

endmodule : VX_cp_core

`undef CP_AXI_LINK
