//!/bin/bash

// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

`include "VX_tex_define.vh"

module VX_tex_core import VX_gpu_pkg::*; import VX_tex_pkg::*; #(
    parameter `STRING INSTANCE_ID = "",
    parameter NUM_LANES = 1,
    parameter TAG_WIDTH = 1
) (
    `SCOPE_IO_DECL

    input wire  clk,
    input wire  reset,

    // PERF
`ifdef PERF_ENABLE
    VX_tex_perf_if.master   perf_tex_if,
`endif

    VX_mem_bus_if.master    cache_bus_if [TCACHE_NUM_REQS],

    VX_dcr_bus_if.slave     dcr_bus_if,

    VX_tex_bus_if.slave     tex_bus_if
);
    `UNUSED_SPARAM (INSTANCE_ID)

    localparam BLEND_FRAC_W = (TEX_NUM_LEVELS * 2 * NUM_LANES * `TEX_BLEND_FRAC);
    localparam LODFRAC_W = (NUM_LANES * `VX_TEX_LOD_FRAC_BITS);
    localparam BORDER_W = (TEX_NUM_LEVELS * 4 * NUM_LANES);
    localparam W_ADDR_BITS = `TEX_ADDR_BITS + 6;

    // DCRs

    tex_dcrs_t tex_dcrs;

    VX_tex_dcr #(
        .INSTANCE_ID ($sformatf("%s-dcr", INSTANCE_ID)),
        .NUM_STAGES  (`VX_TEX_STAGE_COUNT)
    ) tex_dcr (
        .clk        (clk),
        .reset      (reset),
        .dcr_bus_if (dcr_bus_if),
        .stage      (tex_bus_if.req_data.stage),
        .tex_dcrs   (tex_dcrs)
    );

    // Texture stage select

    wire                                        req_valid;
    wire [NUM_LANES-1:0]                        req_mask;
    wire [TEX_FILTER_BITS-1:0]                 req_filter;
    wire [TEX_FORMAT_BITS-1:0]                 req_format;
    wire [1:0][TEX_WRAP_BITS-1:0]              req_wraps;
    wire [1:0][TEX_LOD_BITS-1:0]            req_logdims;
    wire [`TEX_ADDR_BITS-1:0]                   req_baseaddr;
    wire [31:0]                                 req_bordercolor;
    wire [1:0][NUM_LANES-1:0][31:0]             req_coords;
    wire [NUM_LANES-1:0][TEX_NUM_LEVELS-1:0][TEX_LOD_BITS-1:0] req_miplevel, sel_miplevel;
    wire [NUM_LANES-1:0][TEX_NUM_LEVELS-1:0][`TEX_MIPOFF_BITS-1:0] req_mipoff, sel_mipoff;
    wire [NUM_LANES-1:0][`VX_TEX_LOD_FRAC_BITS-1:0] req_lodfrac, sel_lodfrac;
    wire [TAG_WIDTH-1:0]                        req_tag;
    wire                                        req_ready;

    // Both levels a sample can read are selected here and fetched by one
    // request, so nothing downstream has to pair two responses.
    wire mip_linear = tex_dcrs.filter[TEX_FILTER_BITS-1];

    for (genvar i = 0; i < NUM_LANES; ++i) begin : g_mip_sel
        // The lod operand names an integer level, except under mip-linear where
        // it is fixed-point: the level in the high bits and the weight between
        // it and the next above in the low ones. A caller that never asks for a
        // blend therefore never has to know about the fractional form.
        wire [TEX_LOD_BITS-1:0] level_lo = mip_linear
            ? tex_bus_if.req_data.lod[i][`VX_TEX_LOD_FRAC_BITS +: TEX_LOD_BITS]
            : tex_bus_if.req_data.lod[i][TEX_LOD_BITS-1:0];
        // The top of the chain has no level above it, so the upper set repeats
        // the lower one and the weight then blends a value with itself. The
        // increment is as wide as the table index, so left alone it would wrap
        // to entry zero and blend the smallest level with the largest.
        wire at_top = (level_lo == TEX_LOD_BITS'(`VX_TEX_LOD_MAX));
        assign sel_miplevel[i][0] = level_lo;
        assign sel_miplevel[i][1] = at_top ? level_lo : (level_lo + TEX_LOD_BITS'(1));
        assign sel_mipoff[i][0] = tex_dcrs.mipoff[sel_miplevel[i][0]];
        assign sel_mipoff[i][1] = tex_dcrs.mipoff[sel_miplevel[i][1]];
        assign sel_lodfrac[i] = mip_linear ? tex_bus_if.req_data.lod[i][0 +: `VX_TEX_LOD_FRAC_BITS]
                                           : `VX_TEX_LOD_FRAC_BITS'(0);
    end

    VX_elastic_buffer #(
        .DATAW   (NUM_LANES  + TEX_FILTER_BITS + TEX_FORMAT_BITS + 2 * TEX_WRAP_BITS + 2 * TEX_LOD_BITS + `TEX_ADDR_BITS + 32 + NUM_LANES * (2 * 32 + `VX_TEX_LOD_FRAC_BITS + TEX_NUM_LEVELS * (TEX_LOD_BITS + `TEX_MIPOFF_BITS)) + TAG_WIDTH),
        .OUT_REG (1)
    ) pipe_reg (
        .clk       (clk),
        .reset     (reset),
        .valid_in  (tex_bus_if.req_valid),
        .ready_in  (tex_bus_if.req_ready),
        .data_in   ({tex_bus_if.req_data.mask, tex_dcrs.filter, tex_dcrs.format, tex_dcrs.wraps, tex_dcrs.logdims, tex_dcrs.baseaddr, tex_dcrs.border, tex_bus_if.req_data.coords, sel_miplevel, sel_mipoff, sel_lodfrac, tex_bus_if.req_data.tag}),
        .data_out  ({req_mask, req_filter, req_format, req_wraps, req_logdims, req_baseaddr, req_bordercolor, req_coords, req_miplevel, req_mipoff, req_lodfrac, req_tag}),
        .valid_out (req_valid),
        .ready_out (req_ready)
    );

    // address generation

    wire mem_req_valid;
    wire [NUM_LANES-1:0] mem_req_mask;
    wire [TEX_FILTER_BITS-1:0] mem_req_filter;
    wire [`TEX_LGSTRIDE_BITS-1:0] mem_req_lgstride;
    wire [NUM_LANES-1:0][TEX_NUM_LEVELS-1:0][1:0][`TEX_BLEND_FRAC-1:0] mem_req_blends;
    wire [NUM_LANES-1:0][`VX_TEX_LOD_FRAC_BITS-1:0] mem_req_lodfrac;
    wire [NUM_LANES-1:0][TEX_NUM_LEVELS-1:0][3:0] mem_req_border;
    wire [NUM_LANES-1:0][TEX_NUM_LEVELS-1:0][3:0][31:0] mem_req_addr;
    wire [NUM_LANES-1:0][TEX_NUM_LEVELS-1:0][W_ADDR_BITS-1:0] mem_req_baseaddr;
    wire [(TAG_WIDTH + TEX_FORMAT_BITS + 32)-1:0] mem_req_info;
    wire mem_req_ready;

    // The border colour rides the request rather than being read at the
    // sampler, for the same reason the format does: the state a sample merges
    // under is the state it was issued under.
    VX_tex_addr #(
        .INSTANCE_ID ($sformatf("%s-addr", INSTANCE_ID)),
        .REQ_TAGW    (TAG_WIDTH + TEX_FORMAT_BITS + 32),
        .NUM_LANES   (NUM_LANES)
    ) tex_addr (
        .clk        (clk),
        .reset      (reset),

        // inputs
        .req_valid  (req_valid),
        .req_mask   (req_mask),
        .req_coords (req_coords),
        .req_format (req_format),
        .req_filter (req_filter),
        .req_wraps  (req_wraps),
        .req_baseaddr(req_baseaddr),
        .req_miplevel(req_miplevel),
        .req_mipoff (req_mipoff),
        .req_lodfrac(req_lodfrac),
        .req_logdims(req_logdims),
        .req_tag    ({req_tag, req_format, req_bordercolor}),
        .req_ready  (req_ready),

        // outputs
        .rsp_valid  (mem_req_valid),
        .rsp_mask   (mem_req_mask),
        .rsp_filter (mem_req_filter),
        .rsp_lgstride(mem_req_lgstride),
        .rsp_baseaddr(mem_req_baseaddr),
        .rsp_addr   (mem_req_addr),
        .rsp_blends (mem_req_blends),
        .rsp_border (mem_req_border),
        .rsp_lodfrac(mem_req_lodfrac),
        .rsp_tag    (mem_req_info),
        .rsp_ready  (mem_req_ready)
    );

    // retrieve texel values from memory

    wire mem_rsp_valid;
    wire [NUM_LANES-1:0][TEX_NUM_LEVELS-1:0][3:0][31:0] mem_rsp_data;
    wire [(TAG_WIDTH + TEX_FORMAT_BITS + 32 + BLEND_FRAC_W + BORDER_W + LODFRAC_W)-1:0] mem_rsp_info;
    wire mem_rsp_ready;

    VX_tex_mem #(
        .INSTANCE_ID ($sformatf("%s-mem", INSTANCE_ID)),
        .REQ_TAGW    (TAG_WIDTH + TEX_FORMAT_BITS + 32 + BLEND_FRAC_W + BORDER_W + LODFRAC_W),
        .NUM_LANES   (NUM_LANES)
    ) tex_mem (
        .clk       (clk),
        .reset     (reset),

        // memory interface
        .cache_bus_if (cache_bus_if),

        // inputs
        .req_valid (mem_req_valid),
        .req_mask  (mem_req_mask),
        .req_filter(mem_req_filter),
        .req_lgstride(mem_req_lgstride),
        .req_baseaddr(mem_req_baseaddr),
        .req_addr  (mem_req_addr),
        .req_tag   ({mem_req_info, mem_req_blends, mem_req_border, mem_req_lodfrac}),
        .req_ready (mem_req_ready),

        // outputs
        .rsp_valid (mem_rsp_valid),
        .rsp_data  (mem_rsp_data),
        .rsp_tag   (mem_rsp_info),
        .rsp_ready (mem_rsp_ready)
    );

    // apply sampler

    wire sampler_rsp_valid;
    wire [NUM_LANES-1:0][31:0] sampler_rsp_data;
    wire [TAG_WIDTH-1:0] sampler_rsp_info;
    wire sampler_rsp_ready;

    wire [LODFRAC_W-1:0] mem_rsp_lodfrac = mem_rsp_info[0 +: LODFRAC_W];
    wire [BORDER_W-1:0] mem_rsp_border = mem_rsp_info[LODFRAC_W +: BORDER_W];
    wire [BLEND_FRAC_W-1:0] mem_rsp_blends = mem_rsp_info[(LODFRAC_W + BORDER_W) +: BLEND_FRAC_W];
    wire [31:0] mem_rsp_bordercolor = mem_rsp_info[(LODFRAC_W + BORDER_W + BLEND_FRAC_W) +: 32];
    wire [TEX_FORMAT_BITS-1:0] mem_rsp_format = mem_rsp_info[(LODFRAC_W + BORDER_W + BLEND_FRAC_W + 32) +: TEX_FORMAT_BITS];
    wire [TAG_WIDTH-1:0] mem_rsp_tag = mem_rsp_info[(LODFRAC_W + BORDER_W + BLEND_FRAC_W + 32 + TEX_FORMAT_BITS) +: TAG_WIDTH];

    VX_tex_sampler #(
        .INSTANCE_ID ($sformatf("%s-sampler", INSTANCE_ID)),
        .REQ_TAGW    (TAG_WIDTH),
        .NUM_LANES   (NUM_LANES)
    ) tex_sampler (
        .clk        (clk),
        .reset      (reset),

        // inputs
        .req_valid  (mem_rsp_valid),
        .req_data   (mem_rsp_data),
        .req_blends (mem_rsp_blends),
        .req_border (mem_rsp_border),
        .req_bordercolor (mem_rsp_bordercolor),
        .req_lodfrac(mem_rsp_lodfrac),
        .req_format (mem_rsp_format),
        .req_tag    (mem_rsp_tag),
        .req_ready  (mem_rsp_ready),

        // outputs
        .rsp_valid  (sampler_rsp_valid),
        .rsp_data   (sampler_rsp_data),
        .rsp_tag    (sampler_rsp_info),
        .rsp_ready  (sampler_rsp_ready)
    );

    VX_elastic_buffer #(
        .DATAW   (NUM_LANES * 32 + TAG_WIDTH),
        .SIZE    (2),
        .OUT_REG (2) // external bus should be registered
    ) rsp_buf (
        .clk       (clk),
        .reset     (reset),
        .valid_in  (sampler_rsp_valid),
        .ready_in  (sampler_rsp_ready),
        .data_in   ({sampler_rsp_data, sampler_rsp_info}),
        .data_out  ({tex_bus_if.rsp_data.texels, tex_bus_if.rsp_data.tag}),
        .valid_out (tex_bus_if.rsp_valid),
        .ready_out (tex_bus_if.rsp_ready)
    );

`ifdef SCOPE
`ifdef DBG_SCOPE_TEX
    `SCOPE_IO_SWITCH (1);
    wire cache_bus_req_fire_0 = cache_bus_if[0].req_valid && cache_bus_if[0].req_ready;
    wire cache_bus_rsp_fire_0 = cache_bus_if[0].rsp_valid && cache_bus_if[0].rsp_ready;
    wire [TCACHE_TAG_WIDTH-UUID_WIDTH-1:0] cache_bus_req_tag  = cache_bus_if[0].req_data.tag[TCACHE_TAG_WIDTH-UUID_WIDTH-1:0];
    wire [UUID_WIDTH-1:0] cache_bus_req_uuid = cache_bus_if[0].req_data.tag[TCACHE_TAG_WIDTH-1 -: UUID_WIDTH];
    wire [TCACHE_TAG_WIDTH-UUID_WIDTH-1:0] cache_bus_rsp_tag  = cache_bus_if[0].rsp_data.tag[TCACHE_TAG_WIDTH-UUID_WIDTH-1:0];
    wire [UUID_WIDTH-1:0] cache_bus_rsp_uuid = cache_bus_if[0].rsp_data.tag[TCACHE_TAG_WIDTH-1 -: UUID_WIDTH];
    wire [TEX_REQ_ARB1_TAG_WIDTH-UUID_WIDTH-1:0] tex_bus_req_tag = tex_bus_if.req_data.tag[TEX_REQ_ARB1_TAG_WIDTH-UUID_WIDTH-1:0];
    wire [UUID_WIDTH-1:0] tex_bus_req_uuid = tex_bus_if.req_data.tag[TEX_REQ_ARB1_TAG_WIDTH-1 -: UUID_WIDTH];
    wire [TEX_REQ_ARB1_TAG_WIDTH-UUID_WIDTH-1:0] tex_bus_rsp_tag = tex_bus_if.rsp_data.tag[TEX_REQ_ARB1_TAG_WIDTH-UUID_WIDTH-1:0];
    wire [UUID_WIDTH-1:0] tex_bus_rsp_uuid = tex_bus_if.rsp_data.tag[TEX_REQ_ARB1_TAG_WIDTH-1 -: UUID_WIDTH];
    wire tex_bus_req_fire = tex_bus_if.req_valid && tex_bus_if.req_ready;
    wire tex_bus_rsp_fire = tex_bus_if.rsp_valid && tex_bus_if.rsp_ready;
    `NEG_EDGE (reset_negedge, reset);
    `SCOPE_TAP_EX (0, 5, 8, 5, (
            TCACHE_ADDR_WIDTH + 1 + TCACHE_TAG_WIDTH +
            (TCACHE_WORD_SIZE * 8) + TCACHE_TAG_WIDTH +
            VX_DCR_ADDR_WIDTH + VX_DCR_DATA_WIDTH +
            1 * (1 + 2 * 32 + TEX_LODF_BITS) + TEX_STAGE_BITS + TAG_WIDTH +
            1 * 32 + TAG_WIDTH +
            `TEX_ADDR_BITS + `TEX_MIPOFF_BITS + 2 * TEX_LOD_BITS
        ), {
            cache_bus_if[0].req_valid,
            cache_bus_if[0].req_ready,
            cache_bus_if[0].rsp_valid,
            cache_bus_if[0].rsp_ready,
            tex_bus_if.req_valid,
            tex_bus_if.req_ready,
            tex_bus_if.rsp_valid,
            tex_bus_if.rsp_ready
        }, {
            cache_bus_req_fire_0,
            cache_bus_rsp_fire_0,
            dcr_bus_if.write_valid,
            tex_bus_req_fire,
            tex_bus_rsp_fire
        },{
            cache_bus_if[0].req_data.addr,
            cache_bus_if[0].req_data.rw,
            cache_bus_req_tag,
            cache_bus_req_uuid,
            cache_bus_if[0].rsp_data.data,
            cache_bus_rsp_tag,
            cache_bus_rsp_uuid,
            dcr_bus_if.write_addr,
            dcr_bus_if.write_data,
            tex_bus_if.req_data.mask[0],
            tex_bus_if.req_data.coords[0][0],
            tex_bus_if.req_data.coords[1][0],
            tex_bus_if.req_data.lod[0],
            tex_bus_if.req_data.stage,
            tex_bus_req_tag,
            tex_bus_req_uuid,
            tex_bus_if.rsp_data.texels[0],
            tex_bus_rsp_tag,
            tex_bus_rsp_uuid,
            tex_dcrs.baseaddr,
            tex_dcrs.mipoff[0],
            tex_dcrs.logdims[0],
            tex_dcrs.logdims[1]
        },
        reset_negedge, 1'b0, 4096
    );
`else
    `SCOPE_IO_UNUSED()
`endif
`endif
`ifdef CHIPSCOPE
    ila_tex ila_tex_inst (
        .clk    (clk),
        .probe0 ({cache_bus_if[0].rsp_data.data, cache_bus_if[0].rsp_data.tag, cache_bus_if[0].rsp_ready, cache_bus_if[0].rsp_valid, cache_bus_if[0].req_data.tag, cache_bus_if[0].req_data.addr, cache_bus_if[0].req_data.rw, cache_bus_if[0].req_valid, cache_bus_if[0].req_ready}),
        .probe1 ({dcr_bus_if.write_valid, dcr_bus_if.write_addr, dcr_bus_if.write_data}),
        .probe2 ({tex_bus_if.req_valid, tex_bus_if.req_data, tex_bus_if.req_ready}),
        .probe3 ({tex_bus_if.rsp_valid, tex_bus_if.rsp_data, tex_bus_if.rsp_ready})
    );
`endif

`ifdef PERF_ENABLE
    wire [`CLOG2(TCACHE_NUM_REQS+1)-1:0] perf_mem_req_per_cycle;
    wire [`CLOG2(TCACHE_NUM_REQS+1)-1:0] perf_mem_rsp_per_cycle;
    wire [`CLOG2(TCACHE_NUM_REQS+1)+1-1:0] perf_pending_reads_cycle;

    wire [TCACHE_NUM_REQS-1:0] perf_mem_req_fire;
    for (genvar i = 0; i < TCACHE_NUM_REQS; ++i) begin : g_perf_mem_req_fire
        assign perf_mem_req_fire[i] = cache_bus_if[i].req_valid && cache_bus_if[i].req_ready;
    end

    wire [TCACHE_NUM_REQS-1:0] perf_mem_rsp_fire;
    for (genvar i = 0; i < TCACHE_NUM_REQS; ++i) begin : g_perf_mem_rsp_fire
        assign perf_mem_rsp_fire[i] = cache_bus_if[i].rsp_valid && cache_bus_if[i].rsp_ready;
    end

    `POP_COUNT(perf_mem_req_per_cycle, perf_mem_req_fire);
    `POP_COUNT(perf_mem_rsp_per_cycle, perf_mem_rsp_fire);

    reg [PERF_CTR_BITS-1:0] perf_pending_reads;
    assign perf_pending_reads_cycle = perf_mem_req_per_cycle - perf_mem_rsp_per_cycle;

    always @(posedge clk) begin
        if (reset) begin
            perf_pending_reads <= '0;
        end else begin
            perf_pending_reads <= $signed(perf_pending_reads) + PERF_CTR_BITS'($signed(perf_pending_reads_cycle));
        end
    end

    wire perf_stall_cycle = tex_bus_if.req_valid & ~tex_bus_if.req_ready;

    reg [PERF_CTR_BITS-1:0] perf_mem_reads;
    reg [PERF_CTR_BITS-1:0] perf_mem_latency;
    reg [PERF_CTR_BITS-1:0] perf_stall_cycles;

    always @(posedge clk) begin
        if (reset) begin
            perf_mem_reads    <= '0;
            perf_mem_latency  <= '0;
            perf_stall_cycles <= '0;
        end else begin
            perf_mem_reads    <= perf_mem_reads + PERF_CTR_BITS'(perf_mem_req_per_cycle);
            perf_mem_latency  <= perf_mem_latency + PERF_CTR_BITS'(perf_pending_reads);
            perf_stall_cycles <= perf_stall_cycles + PERF_CTR_BITS'(perf_stall_cycle);
        end
    end

    assign perf_tex_if.mem_reads    = perf_mem_reads;
    assign perf_tex_if.mem_latency  = perf_mem_latency;
    assign perf_tex_if.stall_cycles = perf_stall_cycles;
`endif

`ifdef DBG_TRACE_TEX
    always @(posedge clk) begin
        if (tex_bus_if.req_valid && tex_bus_if.req_ready) begin
            `TRACE(1, ("%d: %s-req: valid=%b, stage=%0d, lod=0x%0h, u=",
                    $time, INSTANCE_ID, tex_bus_if.req_data.mask, tex_bus_if.req_data.stage, tex_bus_if.req_data.lod))
            `TRACE_ARRAY1D(1, "0x%0h", tex_bus_if.req_data.coords[0], NUM_LANES)
            `TRACE(1, (", v="))
            `TRACE_ARRAY1D(1, "0x%0h", tex_bus_if.req_data.coords[1], NUM_LANES)
            `TRACE(1, (", tag=0x%0h (#%0d)\n", tex_bus_if.req_data.tag, tex_bus_if.req_data.tag[TAG_WIDTH-1 -: UUID_WIDTH]))
        end
        if (tex_bus_if.rsp_valid && tex_bus_if.rsp_ready) begin
            `TRACE(1, ("%d: %s-rsp: texels=", $time, INSTANCE_ID))
            `TRACE_ARRAY1D(1, "0x%0h", tex_bus_if.rsp_data.texels, NUM_LANES)
            `TRACE(1, (", tag=0x%0h (#%0d)\n", tex_bus_if.rsp_data.tag, tex_bus_if.rsp_data.tag[TAG_WIDTH-1 -: UUID_WIDTH]))
        end
    end
`endif

endmodule
