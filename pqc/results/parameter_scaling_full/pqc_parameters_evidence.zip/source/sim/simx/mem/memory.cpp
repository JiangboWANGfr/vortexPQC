// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <VX_types.h>
#include "memory.h"
#include <vector>
#include <queue>
#include <sstream>
#include <unordered_map>
#include <iostream>
#include <stdlib.h>
#include <dram_sim.h>
#include <algorithm>
#include <cassert>

#include "mem_block_pool.h"
#include "constants.h"
#include "types.h"
#include "debug.h"
#include "VX_config.h"

using namespace vortex;

class Memory::Impl {
private:
	// A completed read is not visible to the device the same cycle it leaves
	// the DRAM model: the platform stages the response and completes a
	// registered valid/ready handshake at the device boundary, adding two
	// cycles beyond the response register.
	static constexpr uint64_t RSP_BOUNDARY_DELAY = 3;

	Memory*   simobject_;
	Config    config_;
	MemCrossBar::Ptr mem_xbar_;
	DramSim   dram_sim_;
	RAM*      ram_;
	Memory::PreSendHook pre_send_hook_;
	mutable PerfStats perf_stats_;
	struct DramCallbackArgs {
		MemReq request;
		std::shared_ptr<mem_block_t> rsp_data;  // captured at request time for reads
		bool ready;
	};
	std::vector<std::queue<std::shared_ptr<DramCallbackArgs>>> pending_reqs_;
	std::vector<uint32_t> pending_writes_;

public:
	Impl(Memory* simobject, const Config& config)
		: simobject_(simobject)
		, config_(config)
		, dram_sim_(config.num_banks, config.block_size, config.clock_ratio)
		, ram_(nullptr)
		, pending_reqs_(config.num_banks)
		, pending_writes_(config.num_banks, 0)
	{
		char sname[100];
		snprintf(sname, 100, "%s-xbar", simobject->name().c_str());
		mem_xbar_ = MemCrossBar::Create(sname, ArbiterType::RoundRobin, config.num_ports, config.num_banks,
			[lg2_block_size = log2ceil(config.block_size), num_banks = config.num_banks](const MemCrossBar::ReqType& req) {
    	// Custom logic to calculate the output index using bank interleaving
			return (uint32_t)((req.addr >> lg2_block_size) & (num_banks-1));
		});
		for (uint32_t i = 0; i < config.num_ports; ++i) {
			simobject->mem_req_in.at(i).bind(&mem_xbar_->ReqIn.at(i));
			mem_xbar_->RspOut.at(i).bind(&simobject->mem_rsp_out.at(i));
		}
	}

	~Impl() {}

	const PerfStats& perf_stats() const {
		perf_stats_.bank_stalls = mem_xbar_->collisions();
		return perf_stats_;
	}

	bool pending_writes() const {
		for (auto count : pending_writes_) {
			if (count != 0)
				return true;
		}
		return false;
	}

	void reset() {
		dram_sim_.reset();
		for (auto& queue : pending_reqs_) {
			queue = {};
		}
		std::fill(pending_writes_.begin(), pending_writes_.end(), 0);
	}

	void tick() {
		dram_sim_.tick();

		// The device memory bus retires requests in order within each bank.
		for (uint32_t i = 0; i < config_.num_banks; ++i) {
			auto& queue = pending_reqs_.at(i);
			if (queue.empty() || !queue.front()->ready || mem_xbar_->RspIn.at(i).full()) {
				continue;
			}
			const auto& args = queue.front();
			if (!args->request.is_write()) {
				MemRsp mem_rsp{args->request.tag, args->request.hart_id, args->request.uuid};
				mem_rsp.data = args->rsp_data;
				if (!mem_xbar_->RspIn.at(i).try_send(mem_rsp, RSP_BOUNDARY_DELAY)) {
					continue;
				}
				DT(3, simobject_->name() << " mem-rsp" << i << ": " << mem_rsp);
			} else {
				assert(pending_writes_.at(i) != 0);
				--pending_writes_.at(i);
			}
			queue.pop();
		}

		for (uint32_t i = 0; i < config_.num_banks; ++i) {
			if (mem_xbar_->ReqOut.at(i).empty())
				continue;

			auto& mem_req = mem_xbar_->ReqOut.at(i).peek();
			if (mem_req.is_write()) {
				if (pending_writes_.at(i) == config_.max_pending_writes)
					continue;
			} else if (pending_writes_.at(i) != 0) {
				continue;
			}

			std::shared_ptr<mem_block_t> rsp_data;
			if (ram_) {
				uint64_t line_addr = mem_req.addr & ~uint64_t(VX_CFG_MEM_BLOCK_SIZE - 1);
				// Cache fills/writebacks are simulator-internal traffic and
				// don't carry the kernel's intent (e.g. a write-back cache
				// reads a write-only buffer to fill the line on write-miss,
				// since memory buses lack per-region read/write permissions).
				// Suppress ACL for the duration; ACL still guards upload/download.
				ram_->enable_acl(false);
				if (mem_req.is_write()) {
					// Apply byte-enabled write to RAM at request arrival.
					// IO_COUT-range bytes are tapped to the print buffer and
					// not stored in RAM.
					if (mem_req.data) {
						for (uint32_t b = 0; b < VX_CFG_MEM_BLOCK_SIZE; ++b) {
							if (mem_req.byteen & (1ull << b)) {
								uint8_t value = (*mem_req.data)[b];
								ram_->write(&value, line_addr + b, 1);
							}
						}
					}
				} else {
					// Capture the line at request time; response carries it back.
					rsp_data = make_mem_block();
					ram_->read(rsp_data->data(), line_addr, VX_CFG_MEM_BLOCK_SIZE);
				}
				ram_->enable_acl(true);
			}

			if (pre_send_hook_) {
				pre_send_hook_(mem_req);
			}

			// enqueue the request to the memory system
			auto req_args = std::make_shared<DramCallbackArgs>(DramCallbackArgs{mem_req, rsp_data, false});
			pending_reqs_.at(i).push(req_args);
			pending_writes_.at(i) += mem_req.is_write();
			dram_sim_.send_request(
				mem_req.addr,
				mem_req.is_write(),
				[req_args](void*)->bool {
					req_args->ready = true;
					return true;
				},
				nullptr
			);

			DT(3, simobject_->name() << " mem-req" << i << ": " << mem_req);
			mem_xbar_->ReqOut.at(i).pop();
		}
	}

	void attach_ram(RAM* ram) {
		ram_ = ram;
	}

	void set_pre_send_hook(Memory::PreSendHook hook) {
		pre_send_hook_ = std::move(hook);
	}
};

///////////////////////////////////////////////////////////////////////////////

Memory::Memory(const SimContext& ctx, const char* name, const Config& config)
	: SimObject<Memory>(ctx, name)
	, mem_req_in(config.num_ports, this)
	, mem_rsp_out(config.num_ports, this)
	, impl_(new Impl(this, config))
{}

Memory::~Memory() {
  delete impl_;
}

void Memory::on_reset() {
  impl_->reset();
}

void Memory::on_tick() {
  impl_->tick();
}

void Memory::attach_ram(RAM* ram) {
  impl_->attach_ram(ram);
}

void Memory::set_pre_send_hook(PreSendHook hook) {
  impl_->set_pre_send_hook(std::move(hook));
}

const Memory::PerfStats &Memory::perf_stats() const {
	return impl_->perf_stats();
}

bool Memory::pending_writes() const {
	return impl_->pending_writes();
}
