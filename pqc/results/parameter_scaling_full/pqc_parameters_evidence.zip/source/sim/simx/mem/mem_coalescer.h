// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "types.h"

namespace vortex {

class MemCoalescer : public SimObject<MemCoalescer> {
public:
  SimChannel<LsuReq> ReqIn;
  SimChannel<LsuRsp> RspOut;

  // Per-channel memory-side ports: the coalescer drives the cache ports
  // directly (the lane fan-out/fan-in boundary is combinational).
  std::vector<SimChannel<MemReq>> ReqOut;
  std::vector<SimChannel<MemRsp>> RspIn;

  struct PerfStats {
    uint64_t misses = 0;

    PerfStats& operator+=(const PerfStats& rhs) {
      this->misses += rhs.misses;
      return *this;
    }
  };

  MemCoalescer(
    const SimContext& ctx,
    const char* name,
    uint32_t input_size,
    uint32_t output_size,
    uint32_t line_size,
    uint32_t queue_size,
    uint32_t delay
  );

  const PerfStats& perf_stats() const;

protected:
  void on_reset();
  void on_tick();

private:
  void flush_out_round();

  struct pending_req_t {
    uint32_t tag;
    BitVector<> mask;
  };

  // One coalesced round awaiting per-channel issue (handles per-lane
  // backpressure without re-coalescing).
  struct out_round_t {
    bool valid = false;
    BitVector<> lanes;        // output lanes still to send
    std::vector<MemReq> reqs; // per output lane
    BitVector<> cur_mask;     // input lanes covered by this round
  };

  uint32_t input_size_;
  uint32_t output_size_;
  uint32_t output_ratio_;

  HashTable<pending_req_t> pending_rd_reqs_;
  BitVector<> sent_mask_;
  out_round_t out_round_;
  uint32_t line_size_;
  uint32_t delay_;
  PerfStats perf_stats_;

  friend class SimObject<MemCoalescer>;
};

}