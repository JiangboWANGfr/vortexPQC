// Copyright © 2019-2023
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <iostream>
#include <string>
#include <sstream>
#include <stdlib.h>
#include <string.h>
#include <iomanip>
#include <vector>
#include <unordered_map>
#include <util.h>
#include "debug.h"
#include "types.h"
#include "decode.h"
#include "decompressor.h"
#include "instr.h"
#include "gfx_doctrine.h"

#ifdef VX_CFG_EXT_TCU_ENABLE
#include "tensor_cfg.h"
#include "tcu_unit.h"
#endif

using namespace vortex;

static op_string_t op_string(const Instr &instr) {
  auto op_type = instr.get_op_type();
  auto instrArgs = instr.get_args();
  return visit_var(op_type,
    [&](AluType alu_type)-> op_string_t {
      auto aluArgs = std::get<IntrAluArgs>(instrArgs);
      switch (alu_type) {
      case AluType::LUI:   return {"LUI", to_hex_str(aluArgs.imm)};
      case AluType::AUIPC: return {"AUIPC", to_hex_str(aluArgs.imm)};
      case AluType::ADD: {
        if (aluArgs.is_imm) {
          return {aluArgs.is_w ? "ADDIW":"ADDI", to_hex_str(aluArgs.imm)};
        } else {
          return {aluArgs.is_w ? "ADDW":"ADD", ""};
        }
      }
      case AluType::SUB: {
        if (aluArgs.is_imm) {
          return {aluArgs.is_w ? "SUBW":"SUB", to_hex_str(aluArgs.imm)};
        } else {
          return {aluArgs.is_w ? "SUBW":"SUB", ""};
        }
      }
      case AluType::SLL: {
        if (aluArgs.is_imm) {
          return {aluArgs.is_w ? "SLLIW":"SLLI", to_hex_str(aluArgs.imm)};
        } else {
          return {aluArgs.is_w ? "SLLW":"SLL", ""};
        }
      }
      case AluType::SRL: {
        if (aluArgs.is_imm) {
          return {aluArgs.is_w ? "SRLIW":"SRLI", to_hex_str(aluArgs.imm)};
        } else {
          return {aluArgs.is_w ? "SRLW":"SRL", ""};
        }
      }
      case AluType::SRA: {
        if (aluArgs.is_imm) {
          return {aluArgs.is_w ? "SRAIW":"SRAI", to_hex_str(aluArgs.imm)};
        } else {
          return {aluArgs.is_w ? "SRAW":"SRA", ""};
        }
      }
      case AluType::SLT: {
        if (aluArgs.is_imm) {
          return {"SLTI", to_hex_str(aluArgs.imm)};
        } else {
          return {"SLT", ""};
        }
      }
      case AluType::SLTU: {
        if (aluArgs.is_imm) {
          return {"SLTIU", to_hex_str(aluArgs.imm)};
        } else {
          return {"SLTU", ""};
        }
      }
      case AluType::AND: {
        if (aluArgs.is_imm) {
          return {"ANDI", to_hex_str(aluArgs.imm)};
        } else {
          return {"AND", ""};
        }
      }
      case AluType::OR: {
        if (aluArgs.is_imm) {
          return {"ORI", to_hex_str(aluArgs.imm)};
        } else {
          return {"OR", ""};
        }
      }
      case AluType::XOR: {
        if (aluArgs.is_imm) {
          return {"XORI", to_hex_str(aluArgs.imm)};
        } else {
          return {"XOR", ""};
        }
      }
      case AluType::CZERO: return {aluArgs.imm ? "CZERO.NEZ":"CZERO.EQZ", ""};
      default:
        std::abort();
      }
    },
    [&](VoteType vote_type)-> op_string_t {
      switch (vote_type) {
      case VoteType::ALL: return {"VOTE.ALL", ""};
      case VoteType::ANY: return {"VOTE.ANY", ""};
      case VoteType::UNI: return {"VOTE.UNI", ""};
      case VoteType::BAL: return {"VOTE.BAL", ""};
      default:
        std::abort();
      }
    },
    [&](ShflType shfl_type)-> op_string_t {
      switch (shfl_type) {
      case ShflType::UP:   return {"SHFL.UP", ""};
      case ShflType::DOWN: return {"SHFL.DOWN", ""};
      case ShflType::BFLY: return {"SHFL.BFLY", ""};
      case ShflType::IDX:  return {"SHFL.IDX", ""};
      default:
        std::abort();
      }
    },
    [&](WgatherType)-> op_string_t {
      return {"WGATHER", ""};
    },
#ifdef VX_CFG_EXT_KSG25_ENABLE
    [&](Ksg25Type type)-> op_string_t {
      switch (type) {
      case Ksg25Type::THETA_L: return {"KTHETA.L.SG25", ""};
      case Ksg25Type::THETA_H: return {"KTHETA.H.SG25", ""};
      case Ksg25Type::RHOPI_L: return {"KRHOPI.L.SG25", ""};
      case Ksg25Type::RHOPI_H: return {"KRHOPI.H.SG25", ""};
      case Ksg25Type::CHII_L: return {"KCHII.L.SG25", ""};
      case Ksg25Type::CHII_H: return {"KCHII.H.SG25", ""};
      default:
        std::abort();
      }
    },
#endif
#ifdef VX_CFG_EXT_KROUND25_ENABLE
    [&](Kround25Type type)-> op_string_t {
      auto aluArgs = std::get<IntrAluArgs>(instrArgs);
      return {type == Kround25Type::ROUND_L ? "KROUND.L.SG25" : "KROUND.H.SG25",
              std::to_string(aluArgs.imm)};
    },
#endif
    [&](BrType br_type)-> op_string_t {
      auto brArgs = std::get<IntrBrArgs>(instrArgs);
      switch (br_type) {
      case BrType::BR: {
        switch (brArgs.cmp) {
        case 0: return {"BEQ",  to_hex_str(brArgs.offset)};
        case 1: return {"BNE",  to_hex_str(brArgs.offset)};
        case 4: return {"BLT",  to_hex_str(brArgs.offset)};
        case 5: return {"BGE",  to_hex_str(brArgs.offset)};
        case 6: return {"BLTU", to_hex_str(brArgs.offset)};
        case 7: return {"BGEU", to_hex_str(brArgs.offset)};
        default:
          std::abort();
        }
      }
      case BrType::JAL:  return {"JAL", to_hex_str(brArgs.offset)};
      case BrType::JALR: return {"JALR", to_hex_str(brArgs.offset)};
      case BrType::SYS:
        switch (brArgs.offset) {
        case 0x000: return {"ECALL", ""};
        case 0x001: return {"EBREAK", ""};
        case 0x002: return {"URET", ""};
        case 0x102: return {"SRET", ""};
        case 0x302: return {"MRET", ""};
        default:
          std::abort();
        }
      default:
        std::abort();
      }
    },
    [&](MdvType mdv_type)-> op_string_t {
      auto mdvArgs = std::get<IntrMdvArgs>(instrArgs);
      switch (mdv_type) {
      case MdvType::MUL:    return {mdvArgs.is_w ? "MULW":"MUL", ""};
      case MdvType::MULHU:  return {"MULHU", ""};
      case MdvType::MULH:   return {"MULH", ""};
      case MdvType::MULHSU: return {"MULHSU", ""};
      case MdvType::DIV:    return {mdvArgs.is_w ? "DIVW":"DIV", ""};
      case MdvType::DIVU:   return {mdvArgs.is_w ? "DIVUW":"DIVU", ""};
      case MdvType::REM:    return {mdvArgs.is_w ? "REMW":"REM", ""};
      case MdvType::REMU:   return {mdvArgs.is_w ? "REMUW":"REMU", ""};
      default:
        std::abort();
      }
    },
    [&](FpuType fpu_type)-> op_string_t {
      auto fpuArgs = std::get<IntrFpuArgs>(instrArgs);
      switch (fpu_type) {
      case FpuType::FADD:   return {fpuArgs.is_f64 ? "FADD.D":"FADD.S", ""};
      case FpuType::FSUB:   return {fpuArgs.is_f64 ? "FSUB.D":"FSUB.S", ""};
      case FpuType::FMUL:   return {fpuArgs.is_f64 ? "FMUL.D":"FMUL.S", ""};
      case FpuType::FDIV:   return {fpuArgs.is_f64 ? "FDIV.D":"FDIV.S", ""};
      case FpuType::FSQRT:  return {fpuArgs.is_f64 ? "FSQRT.D":"FSQRT.S", ""};
      case FpuType::FMADD:  return {fpuArgs.is_f64 ? "FMADD.D":"FMADD.S", ""};
      case FpuType::FMSUB:  return {fpuArgs.is_f64 ? "FMSUB.D":"FMSUB.S", ""};
      case FpuType::FNMADD: return {fpuArgs.is_f64 ? "FNMADD.D":"FNMADD.S", ""};
      case FpuType::FNMSUB: return {fpuArgs.is_f64 ? "FNMSUB.D":"FNMSUB.S", ""};
      case FpuType::F2I: {
        switch (fpuArgs.cvt) {
        case 0: return {fpuArgs.is_f64 ? "FCVT.W.D":"FCVT.W.S", ""};
        case 1: return {fpuArgs.is_f64 ? "FCVT.WU.D":"FCVT.WU.S", ""};
        case 2: return {fpuArgs.is_f64 ? "FCVT.L.D":"FCVT.L.S", ""};
        case 3: return {fpuArgs.is_f64 ? "FCVT.LU.D":"FCVT.LU.S", ""};
        default:
          std::abort();
        }
      }
      case FpuType::I2F: {
        switch (fpuArgs.cvt) {
        case 0: return {fpuArgs.is_f64 ? "FCVT.D.W":"FCVT.S.W", ""};
        case 1: return {fpuArgs.is_f64 ? "FCVT.D.WU":"FCVT.S.WU", ""};
        case 2: return {fpuArgs.is_f64 ? "FCVT.D.L":"FCVT.S.L", ""};
        case 3: return {fpuArgs.is_f64 ? "FCVT.D.LU":"FCVT.S.LU", ""};
        default:
          std::abort();
        }
      }
      case FpuType::F2F: return {fpuArgs.is_f64 ? "FCVT.D.S":"FCVT.S.D", ""};
      case FpuType::FCMP: {
        switch (fpuArgs.frm) {
        case 0: return {fpuArgs.is_f64 ? "FLE.D":"FLE.S", ""};
        case 1: return {fpuArgs.is_f64 ? "FLT.D":"FLT.S", ""};
        case 2: return {fpuArgs.is_f64 ? "FEQ.D":"FEQ.S", ""};
        default:
          std::abort();
        }
      }
      case FpuType::FSGNJ: {
        switch (fpuArgs.frm) {
        case 0: return {fpuArgs.is_f64 ? "FSGNJ.D":"FSGNJ.S", ""};
        case 1: return {fpuArgs.is_f64 ? "FSGNJN.D":"FSGNJN.S", ""};
        case 2: return {fpuArgs.is_f64 ? "FSGNJX.D":"FSGNJX.S", ""};
        default:
          std::abort();
        }
      }
      case FpuType::FCLASS: return {fpuArgs.is_f64 ? "FCLASS.D":"FCLASS.S", ""};
      case FpuType::FMVXW:  return {fpuArgs.is_f64 ? "FMV.X.D":"FMV.X.S", ""};
      case FpuType::FMVWX:  return {fpuArgs.is_f64 ? "FMV.D.X":"FMV.S.X", ""};
      case FpuType::FMINMAX: {
        switch (fpuArgs.frm) {
        case 0: return {fpuArgs.is_f64 ? "FMIN.D":"FMIN.S", ""};
        case 1: return {fpuArgs.is_f64 ? "FMAX.D":"FMAX.S", ""};
        default:
          std::abort();
        }
      }
      default:
        std::abort();
      }
    },
    [&](LsuType lsu_type)-> op_string_t {
      switch (lsu_type) {
      case LsuType::LOAD: {
        auto lsuArgs = std::get<IntrLsuArgs>(instrArgs);
        bool dst_float = (instr.get_dest_reg().type == RegType::Float);
        // packLD detection: Float dest with sub-word width (LB or LH).
        if (dst_float && lsuArgs.width == 0) return {"PACKLB.F", ""};
        if (dst_float && lsuArgs.width == 1) return {"PACKLH.F", ""};
        if (dst_float) {
          switch (lsuArgs.width) {
          case 2: return {"FLW", to_hex_str(lsuArgs.offset)};
          case 3: return {"FLD", to_hex_str(lsuArgs.offset)};
          default:
            std::abort();
          }
        } else {
          switch (lsuArgs.width) {
          case 0: return {"LB",  to_hex_str(lsuArgs.offset)};
          case 1: return {"LH",  to_hex_str(lsuArgs.offset)};
          case 2: return {"LW",  to_hex_str(lsuArgs.offset)};
          case 3: return {"LD",  to_hex_str(lsuArgs.offset)};
          case 4: return {"LBU", to_hex_str(lsuArgs.offset)};
          case 5: return {"LHU", to_hex_str(lsuArgs.offset)};
          case 6: return {"LWU", to_hex_str(lsuArgs.offset)};
          default:
            std::abort();
          }
        }
      }
      case LsuType::STORE: {
        auto lsuArgs = std::get<IntrLsuArgs>(instrArgs);
        // For stores, the data source (rs2) carries the type info.
        bool src_float = (instr.get_src_reg(1).type == RegType::Float);
        if (src_float) {
          switch (lsuArgs.width) {
          case 2: return {"FSW", to_hex_str(lsuArgs.offset)};
          case 3: return {"FSD", to_hex_str(lsuArgs.offset)};
          default:
            std::abort();
          }
        } else {
          switch (lsuArgs.width) {
          case 0: return {"SB", to_hex_str(lsuArgs.offset)};
          case 1: return {"SH", to_hex_str(lsuArgs.offset)};
          case 2: return {"SW", to_hex_str(lsuArgs.offset)};
          case 3: return {"SD", to_hex_str(lsuArgs.offset)};
          default:
            std::abort();
          }
        }
      }
      case LsuType::FENCE: return {"FENCE", ""};
      default:
        std::abort();
      }
    },
    [&](AmoType amo_type)-> op_string_t {
      auto amoArgs = std::get<IntrAmoArgs>(instrArgs);
      switch (amoArgs.width) {
      case 2: {
        switch (amo_type) {
        case AmoType::LR:      return {"LR.W", ""};
        case AmoType::SC:      return {"SC.W", ""};
        case AmoType::AMOADD:  return {"AMOADD.W", ""};
        case AmoType::AMOSWAP: return {"AMOSWAP.W", ""};
        case AmoType::AMOAND:  return {"AMOAND.W", ""};
        case AmoType::AMOOR:   return {"AMOOR.W", ""};
        case AmoType::AMOXOR:  return {"AMOXOR.W", ""};
        case AmoType::AMOMIN:  return {"AMOMIN.W", ""};
        case AmoType::AMOMAX:  return {"AMOMAX.W", ""};
        case AmoType::AMOMINU: return {"AMOMINU.W", ""};
        case AmoType::AMOMAXU: return {"AMOMAXU.W", ""};
        case AmoType::AMOCAS:  return {"AMOCAS.W", ""};
        default:
          std::abort();
        }
      }
      case 3: {
        switch (amo_type) {
        case AmoType::LR:      return {"LR.D", ""};
        case AmoType::SC:      return {"SC.D", ""};
        case AmoType::AMOADD:  return {"AMOADD.D", ""};
        case AmoType::AMOSWAP: return {"AMOSWAP.D", ""};
        case AmoType::AMOAND:  return {"AMOAND.D", ""};
        case AmoType::AMOOR:   return {"AMOOR.D", ""};
        case AmoType::AMOXOR:  return {"AMOXOR.D", ""};
        case AmoType::AMOMIN:  return {"AMOMIN.D", ""};
        case AmoType::AMOMAX:  return {"AMOMAX.D", ""};
        case AmoType::AMOMINU: return {"AMOMINU.D", ""};
        case AmoType::AMOMAXU: return {"AMOMAXU.D", ""};
        case AmoType::AMOCAS:  return {"AMOCAS.D", ""};
        default:
          std::abort();
        }
      }
      default:
        std::abort();
      }
    },
    [&](CsrType csr_type)-> op_string_t {
      auto csrArgs = std::get<IntrCsrArgs>(instrArgs);
      if (csrArgs.is_imm) {
        switch (csr_type) {
        case CsrType::CSRRW: return {"CSRRWI", to_hex_str(csrArgs.imm) + ", " + to_hex_str(csrArgs.csr)};
        case CsrType::CSRRS: return {"CSRRSI", to_hex_str(csrArgs.imm) + ", " + to_hex_str(csrArgs.csr)};
        case CsrType::CSRRC: return {"CSRRCI", to_hex_str(csrArgs.imm) + ", " + to_hex_str(csrArgs.csr)};
        default:
          std::abort();
        }
      } else {
        switch (csr_type) {
        case CsrType::CSRRW: return {"CSRRW", to_hex_str(csrArgs.csr)};
        case CsrType::CSRRS: return {"CSRRS", to_hex_str(csrArgs.csr)};
        case CsrType::CSRRC: return {"CSRRC", to_hex_str(csrArgs.csr)};
        default:
          std::abort();
        }
      }
    },
    [&](WctlType wctl_type)-> op_string_t {
      auto wctlArgs = std::get<IntrWctlArgs>(instrArgs);
      switch (wctl_type) {
      case WctlType::TMC:    return {"TMC", ""};
      case WctlType::WSPAWN: return {"WSPAWN", ""};
      case WctlType::SPLIT:  return {wctlArgs.is_cond_neg ? "SPLIT.N":"SPLIT", ""};
      case WctlType::JOIN:   return {"JOIN", ""};
      case WctlType::BAR: {
        if (wctlArgs.is_sync_bar) {
          return {"BAR", ""};
        } else {
          if (wctlArgs.is_bar_arrive) return {"BAR.ARRIVE", ""};
          else return {"BAR.WAIT", ""};
        }
      }
      case WctlType::PRED:   return {wctlArgs.is_cond_neg ? "PRED.N":"PRED", ""};
      case WctlType::WSYNC:  return {"WSYNC", ""};
      default:
        std::abort();
      }
    }
#ifdef VX_CFG_EXT_PQC_ENABLE
    ,[&](PqcType /*pqc_type*/)-> op_string_t {
      return {"PQC.KECCAKF", ""};
    }
#endif
#ifdef VX_CFG_EXT_NTT_ENABLE
    ,[&](NttType ntt_type)-> op_string_t {
      switch (ntt_type) {
      case NttType::MUL_K: return {"NTTMUL.K", ""};
      case NttType::MUL_D: return {"NTTMUL.D", ""};
      case NttType::BF_CT_K:
      case NttType::BF_GS_K: {
        auto nttArgs = std::get<IntrNttArgs>(instrArgs);
        return {(ntt_type == NttType::BF_CT_K ? "NTTBF.CT.K.XOR" : "NTTBF.GS.K.XOR")
                + std::to_string(1u << nttArgs.stage), ""};
      }
      case NttType::BF_CT_D:
      case NttType::BF_GS_D: {
        auto nttArgs = std::get<IntrNttArgs>(instrArgs);
        return {(ntt_type == NttType::BF_CT_D ? "NTTBF.CT.D.XOR" : "NTTBF.GS.D.XOR")
                + std::to_string(1u << nttArgs.stage), ""};
      }
      default: std::abort();
      }
    }
#endif
#ifdef VX_CFG_EXT_DXA_ENABLE
    ,[&](DxaType /*dxa_type*/)-> op_string_t {
      return {"DXA.ISSUE", ""};
    }
#endif
  #ifdef VX_CFG_EXT_TCU_ENABLE
    ,[&](TcuType tcu_type)-> op_string_t {
      auto tpuArgs = std::get<IntrTcuArgs>(instrArgs);
      return TcuUnit::op_string(tcu_type, tpuArgs);
    }
  #endif // VX_CFG_EXT_TCU_ENABLE
  #ifdef VX_CFG_EXT_TEX_ENABLE
    ,[&](TexType /*tex_type*/)-> op_string_t {
      return {"TEX", ""};
    }
  #endif
  #ifdef VX_CFG_EXT_OM_ENABLE
    ,[&](OmType /*om_type*/)-> op_string_t {
      return {"OM", ""};
    }
  #endif
  #ifdef VX_CFG_EXT_RTU_ENABLE
    ,[&](GfxwType rtu_type)-> op_string_t {
      switch (rtu_type) {
      case GfxwType::CB_RET: return {"GFXW.CB_RET", ""};
      case GfxwType::TRACE: return {"GFXW.TRACE", ""};
      case GfxwType::WAIT:  return {"GFXW.WAIT",  ""};
      case GfxwType::GETWF:  return {"GFXW.GETWF",  ""};
      case GfxwType::GETW:   return {"GFXW.GETW",   ""};
      }
      return {"GFXW.?", ""};
    }
  #endif
 );
 return {"", ""};
}

namespace vortex {
std::ostream &operator<<(std::ostream &os, const Instr &instr) {
  auto sintr = ::op_string(instr);
  int sep = 0;
  os << sintr.op;
  auto rd = instr.get_dest_reg();
  if (rd.type != RegType::None) {
    if (sep++ != 0) { os << ", "; } else { os << " "; }
    os << rd;
  }
  for (uint32_t i = 0; i < Instr::MAX_REG_SOURCES; ++i) {
    auto rs = instr.get_src_reg(i);
    if (rs.type != RegType::None) {
      if (sep++ != 0) { os << ", "; } else { os << " "; }
      os << rs;
    }
  }
  if (sintr.arg != "") {
    if (sep++ != 0) { os << ", "; } else { os << " "; }
    os << sintr.arg;
  }
  if (instr.fu_lock_) {
    os << " [fu_lock";
    if (instr.fu_unlock_) {
      os << ",fu_unlock";
    }
    os << "]";
  }
  return os;
}
}

Decoder::Decoder(const SimContext& ctx, const char* name, PoolAllocator<Instr, 64>& instr_pool)
  : SimObject<Decoder>(ctx, name)
  , instr_pool_(instr_pool)
{}

Decoder::~Decoder() {}

Instr::Ptr Decoder::decode(uint32_t code, uint64_t uuid) {
  // Detect RVC from the raw bits and expand to a 32-bit instruction.
  const bool is_rvc = (code & 0x3u) != 0x3u;
  if (is_rvc) {
    auto r = rvc_decompress(code & 0xFFFFu);
    assert(!r.illegal && "illegal RVC encoding");
    code = r.instr32;
  }
  auto op = Opcode((code >> shift_opcode) & mask_opcode);
  auto funct2 = (code >> shift_funct2) & mask_funct2;
  auto funct3 = (code >> shift_funct3) & mask_funct3;
  auto funct5 = (code >> shift_funct5) & mask_funct5;
  auto funct6 = (code >> shift_funct6) & mask_funct6;
  auto funct7 = (code >> shift_funct7) & mask_funct7;
  __unused(funct6);

  auto rd  = (code >> shift_rd)  & mask_reg;
  auto rs1 = (code >> shift_rs1) & mask_reg;
  auto rs2 = (code >> shift_rs2) & mask_reg;
  auto rs3 = (code >> shift_rs3) & mask_reg;

  auto instr = std::allocate_shared<Instr>(instr_pool_, uuid, FUType::ALU);

  switch (op) {
  case Opcode::LUI:
  case Opcode::AUIPC: { // RV32I: LUI / AUIPC
    auto imm20 = (code >> shift_funct3) << shift_funct3;
    instr->set_op_type((op == Opcode::LUI) ? AluType::LUI : AluType::AUIPC);
    instr->set_args(IntrAluArgs{1, 0, imm20});
    instr->set_dest_reg(rd, RegType::Integer);
  } break;
#ifdef VX_CFG_XLEN_64
  case Opcode::R_W:
  case Opcode::I_W:
#endif
  case Opcode::R:
  case Opcode::I: {
    bool is_w = (op == Opcode::R_W) || (op == Opcode::I_W);
    bool is_imm = (op == Opcode::I) || (op == Opcode::I_W);
    if (op == Opcode::R && funct7 == 0x7) {
      uint32_t imm;
      if (funct3 == 0x5) { // CZERO.EQZ
        imm = 0;
      } else
      if (funct3 == 0x7) { // CZERO.NEZ
        imm = 1;
      } else {
        std::abort();
      }
      instr->set_op_type(AluType::CZERO);
      instr->set_args(IntrAluArgs{0, 0, imm});
    } else
    if ((op == Opcode::R || op == Opcode::R_W) && (funct7 == 0x1)) {
      switch (funct3) {
      case 0: instr->set_op_type(MdvType::MUL); break;
      case 1: instr->set_op_type(MdvType::MULH); break;
      case 2: instr->set_op_type(MdvType::MULHSU); break;
      case 3: instr->set_op_type(MdvType::MULHU); break;
      case 4: instr->set_op_type(MdvType::DIV); break;
      case 5: instr->set_op_type(MdvType::DIVU); break;
      case 6: instr->set_op_type(MdvType::REM); break;
      case 7: instr->set_op_type(MdvType::REMU); break;
      default:
        std::abort();
      }
      instr->set_args(IntrMdvArgs{is_w});
    } else {
      uint32_t imm = 0;
      if (funct3 == 0x1 || funct3 == 0x5) {
        // Shift instructions
        imm = rs2; // uint5
      #ifdef VX_CFG_XLEN_64
        imm |= ((funct7 & 0x1) << 5);
      #endif
      } else {
        auto imm12 = code >> shift_rs2;
        imm = sext(imm12, width_i_imm);
      }
      switch (funct3) {
      case 0: instr->set_op_type((!is_imm && funct7 == 0x20) ? AluType::SUB : AluType::ADD); break;
      case 1: instr->set_op_type(AluType::SLL); break;
      case 2: instr->set_op_type(AluType::SLT); break;
      case 3: instr->set_op_type(AluType::SLTU); break;
      case 4: instr->set_op_type(AluType::XOR); break;
      // For RV64I SRAI/SRLI with shamt[5]=1, the upper-imm field is funct6
      // (bits[31:26]), and bit 25 carries shamt[5] — which makes funct7 read
      // back as 0x21 instead of 0x20. Match on funct6 (top 6 bits of funct7)
      // so SRAI with shamt >= 32 isn't mis-decoded as SRLI.
      case 5: instr->set_op_type((((funct7 >> 1) == 0x10)) ? AluType::SRA : AluType::SRL); break;
      case 6: instr->set_op_type(AluType::OR); break;
      case 7: instr->set_op_type(AluType::AND); break;
      default:
        std::abort();
      }
      instr->set_args(IntrAluArgs{is_imm, is_w, imm});
    }
    instr->set_dest_reg(rd, RegType::Integer);
    instr->set_src_reg(0, rs1, RegType::Integer);
    if (!is_imm) {
      instr->set_src_reg(1, rs2, RegType::Integer);
    }
  } break;
  case Opcode::B: {
    auto bit_11   = rd & 0x1;
    auto bits_4_1 = rd >> 1;
    auto bit_10_5 = funct7 & 0x3f;
    auto bit_12   = funct7 >> 6;
    auto imm12 = (bits_4_1 << 1) | (bit_10_5 << 5) | (bit_11 << 11) | (bit_12 << 12);
    auto addr = sext(imm12, width_i_imm+1);
    instr->set_op_type(BrType::BR);
    instr->set_args(IntrBrArgs{funct3, is_rvc, addr});
    instr->set_src_reg(0, rs1, RegType::Integer);
    instr->set_src_reg(1, rs2, RegType::Integer);
    instr->set_wstall(true);
  } break;
  case Opcode::JAL: {
    auto unordered  = code >> shift_funct3;
    auto bits_19_12 = unordered & 0xff;
    auto bit_11     = (unordered >> 8) & 0x1;
    auto bits_10_1  = (unordered >> 9) & 0x3ff;
    auto bit_20     = (unordered >> 19) & 0x1;
    auto imm20 = (bits_10_1 << 1) | (bit_11 << 11) | (bits_19_12 << 12) | (bit_20 << 20);
    auto addr = sext(imm20, width_j_imm+1);
    instr->set_op_type(BrType::JAL);
    instr->set_args(IntrBrArgs{0, is_rvc, addr});
    instr->set_dest_reg(rd, RegType::Integer);
    instr->set_wstall(true);
  } break;
  case Opcode::JALR: {
    auto imm12 = code >> shift_rs2;
    auto addr = sext(imm12, width_i_imm);
    instr->set_op_type(BrType::JALR);
    instr->set_args(IntrBrArgs{0, is_rvc, addr});
    instr->set_dest_reg(rd, RegType::Integer);
    instr->set_src_reg(0, rs1, RegType::Integer);
    instr->set_wstall(true);
  } break;
  case Opcode::L:
  case Opcode::FL:
  case Opcode::S:
  case Opcode::FS: {
    instr->set_fu_type(FUType::LSU);
    bool is_float = (op == Opcode::FL || op == Opcode::FS);
    bool is_load = (op == Opcode::L || op == Opcode::FL);
    {
      instr->set_src_reg(0, rs1, RegType::Integer);
      uint32_t imm12 = 0;
      if (is_load) {
        imm12 = code >> shift_rs2;
        instr->set_dest_reg(rd, is_float ? RegType::Float : RegType::Integer);
      } else {
        imm12 = (funct7 << width_reg) | rd;
        instr->set_src_reg(1, rs2, is_float ? RegType::Float : RegType::Integer);
      }
      auto offset = sext(imm12, width_i_imm);
      instr->set_op_type(is_load ? LsuType::LOAD : LsuType::STORE);
      instr->set_args(IntrLsuArgs{funct3, /*stride*/ 0, (int32_t)offset});
    }
  } break;
  case Opcode::FENCE: {
    instr->set_fu_type(FUType::LSU);
    instr->set_op_type(LsuType::FENCE);
    instr->set_args(IntrLsuArgs{0, 0, 0});
  } break;
  case Opcode::AMO: {
    instr->set_fu_type(FUType::LSU);
    uint32_t aq = (code >> shift_aq) & mask_aq;
    uint32_t rl = (code >> shift_rl) & mask_rl;
    switch (funct5) {
    case 0x00: instr->set_op_type(AmoType::AMOADD); break;
    case 0x01: instr->set_op_type(AmoType::AMOSWAP); break;
    case 0x02: instr->set_op_type(AmoType::LR); break;
    case 0x03: instr->set_op_type(AmoType::SC); break;
    case 0x04: instr->set_op_type(AmoType::AMOXOR); break;
    case 0x08: instr->set_op_type(AmoType::AMOOR); break;
    case 0x0c: instr->set_op_type(AmoType::AMOAND); break;
    case 0x10: instr->set_op_type(AmoType::AMOMIN); break;
    case 0x14: instr->set_op_type(AmoType::AMOMAX); break;
    case 0x18: instr->set_op_type(AmoType::AMOMINU); break;
    case 0x1c: instr->set_op_type(AmoType::AMOMAXU); break;
    case 0x05: instr->set_op_type(AmoType::AMOCAS); break;
    default:
      std::abort();
    }
    instr->set_args(IntrAmoArgs{funct3, aq, rl});
    instr->set_dest_reg(rd, RegType::Integer);
    instr->set_src_reg(0, rs1, RegType::Integer);
    instr->set_src_reg(1, rs2, RegType::Integer);
    if (funct5 == 0x05) {
      // Compare-and-swap reads rd as well as writing it: rd carries the
      // comparand in, the loaded word out. It has to join the source set or
      // the operand collector supplies a stale comparand and the swap decides
      // on the wrong value.
      instr->set_src_reg(2, rd, RegType::Integer);
    }
  } break;
  case Opcode::SYS: {
    if (funct3 != 0) { // CSRRW/CSRRS/CSRRC — dispatched to the SFU's CSR sub-unit
      instr->set_fu_type(FUType::SFU);
      instr->set_dest_reg(rd, RegType::Integer);
      switch (funct3) {
      case 1: case 5: instr->set_op_type(CsrType::CSRRW); break;
      case 2: case 6: instr->set_op_type(CsrType::CSRRS); break;
      case 3: case 7: instr->set_op_type(CsrType::CSRRC); break;
      default:
        std::abort();
      }
      auto imm12 = code >> shift_rs2;
      if (funct3 < 5) {
        instr->set_src_reg(0, rs1, RegType::Integer);
        instr->set_args(IntrCsrArgs{0, 0, imm12});
      } else { // zimm
        instr->set_args(IntrCsrArgs{1, rs1, imm12});
      }
    } else { // ECALL/EBREACK/URET/SRET/MRET
      auto imm12 = code >> shift_rs2;
      instr->set_op_type(BrType::SYS);
      instr->set_args(IntrBrArgs{0, 0, imm12});
      instr->set_wstall(true);
    }
  } break;
  case Opcode::FCI: {
    instr->set_fu_type(FUType::FPU);
    instr->set_args(IntrFpuArgs{funct3, rs2, (funct7 & 0x1)});
    switch (funct7) {
    case 0x00: // RV32F: FADD.S
    case 0x01: // RV32D: FADD.D
      instr->set_op_type(FpuType::FADD);
      instr->set_dest_reg(rd, RegType::Float);
      instr->set_src_reg(0, rs1, RegType::Float);
      instr->set_src_reg(1, rs2, RegType::Float);
      break;
    case 0x04: // RV32F: FSUB.S
    case 0x05: // RV32D: FSUB.D
      instr->set_op_type(FpuType::FSUB);
      instr->set_dest_reg(rd, RegType::Float);
      instr->set_src_reg(0, rs1, RegType::Float);
      instr->set_src_reg(1, rs2, RegType::Float);
      break;
    case 0x08: // RV32F: FMUL.S
    case 0x09: // RV32D: FMUL.D
      instr->set_op_type(FpuType::FMUL);
      instr->set_dest_reg(rd, RegType::Float);
      instr->set_src_reg(0, rs1, RegType::Float);
      instr->set_src_reg(1, rs2, RegType::Float);
      break;
    case 0x10: // RV32F: FSGNJ.S, FSGNJN.S, FSGNJX.S
    case 0x11: // RV32D: FSGNJ.D, FSGNJN.D, FSGNJX.D
      instr->set_op_type(FpuType::FSGNJ);
      instr->set_dest_reg(rd, RegType::Float);
      instr->set_src_reg(0, rs1, RegType::Float);
      instr->set_src_reg(1, rs2, RegType::Float);
      break;
    case 0x14: // RV32F: FMIN.S, FMAX.S
    case 0x15: // RV32D: FMIN.D, FMAX.D
      instr->set_op_type(FpuType::FMINMAX);
      instr->set_dest_reg(rd, RegType::Float);
      instr->set_src_reg(0, rs1, RegType::Float);
      instr->set_src_reg(1, rs2, RegType::Float);
      break;
    case 0x0c: // RV32F: FDIV.S
    case 0x0d: // RV32D: FDIV.D
      instr->set_op_type(FpuType::FDIV);
      instr->set_dest_reg(rd, RegType::Float);
      instr->set_src_reg(0, rs1, RegType::Float);
      instr->set_src_reg(1, rs2, RegType::Float);
      break;
    case 0x20: // FCVT.S.D
    case 0x21: // FCVT.D.S
      instr->set_op_type(FpuType::F2F);
      instr->set_dest_reg(rd, RegType::Float);
      instr->set_src_reg(0, rs1, RegType::Float);
      break;
    case 0x2c: // FSQRT.S
    case 0x2d: // FSQRT.D
      instr->set_op_type(FpuType::FSQRT);
      instr->set_dest_reg(rd, RegType::Float);
      instr->set_src_reg(0, rs1, RegType::Float);
      break;
    case 0x50: // FLE.S, FLT.S, FEQ.S
    case 0x51: // FLE.D, FLT.D, FEQ.D
      instr->set_op_type(FpuType::FCMP);
      instr->set_dest_reg(rd, RegType::Integer);
      instr->set_src_reg(0, rs1, RegType::Float);
      instr->set_src_reg(1, rs2, RegType::Float);
      break;
    case 0x60: // FCVT.W.D, FCVT.WU.D, FCVT.L.D, FCVT.LU.D
    case 0x61: // FCVT.W.S, FCVT.WU.S, FCVT.L.S, FCVT.LU.S
      instr->set_op_type(FpuType::F2I);
      instr->set_dest_reg(rd, RegType::Integer);
      instr->set_src_reg(0, rs1, RegType::Float);
      instr->set_src_reg(1, rs2, RegType::None);
      break;
    case 0x68: // FCVT.S.W, FCVT.S.WU, FCVT.S.L, FCVT.S.LU
    case 0x69: // FCVT.D.W, FCVT.D.WU, FCVT.D.L, FCVT.D.LU
      instr->set_op_type(FpuType::I2F);
      instr->set_dest_reg(rd, RegType::Float);
      instr->set_src_reg(0, rs1, RegType::Integer);
      instr->set_src_reg(1, rs2, RegType::None);
      break;
    case 0x70: // FCLASS.S, FMV.X.S
    case 0x71: // FCLASS.D, FMV.X.D
      instr->set_op_type((funct3 != 0) ? FpuType::FCLASS : FpuType::FMVXW);
      instr->set_dest_reg(rd, RegType::Integer);
      instr->set_src_reg(0, rs1, RegType::Float);
      break;
    case 0x78: // FMV.S.X
    case 0x79: // FMV.D.X
      instr->set_op_type(FpuType::FMVWX);
      instr->set_dest_reg(rd, RegType::Float);
      instr->set_src_reg(0, rs1, RegType::Integer);
      break;
    default:
      std::abort();
    }
  } break;
  case Opcode::FMADD:
  case Opcode::FMSUB:
  case Opcode::FNMADD:
  case Opcode::FNMSUB: {
    instr->set_fu_type(FUType::FPU);
    instr->set_op_type((op == Opcode::FMADD) ? FpuType::FMADD :
                     (op == Opcode::FMSUB) ? FpuType::FMSUB :
                     (op == Opcode::FNMADD) ? FpuType::FNMADD : FpuType::FNMSUB);
    instr->set_args(IntrFpuArgs{funct3, funct2, (funct7 & 0x1)});
    instr->set_dest_reg(rd, RegType::Float);
    instr->set_src_reg(0, rs1, RegType::Float);
    instr->set_src_reg(1, rs2, RegType::Float);
    instr->set_src_reg(2, rs3, RegType::Float);
  } break;
  case Opcode::EXT1: {
    switch (funct7) {
    case 0: {
      instr->set_fu_type(FUType::SFU);
      IntrWctlArgs wctlArgs{};
      switch (funct3) {
      case 0: // TMC
        instr->set_op_type(WctlType::TMC);
        instr->set_src_reg(0, rs1, RegType::Integer);
        instr->set_wstall(true);
        break;
      case 1: // WSPAWN
        instr->set_op_type(WctlType::WSPAWN);
        instr->set_src_reg(0, rs1, RegType::Integer);
        instr->set_src_reg(1, rs2, RegType::Integer);
        instr->set_wstall(true);
        break;
      case 2: // SPLIT
        instr->set_op_type(WctlType::SPLIT);
        instr->set_dest_reg(rd, RegType::Integer);
        instr->set_src_reg(0, rs1, RegType::Integer);
        wctlArgs.is_cond_neg = (rs2 != 0);
        instr->set_wstall(true);
        break;
      case 3: // JOIN
        instr->set_op_type(WctlType::JOIN);
        instr->set_src_reg(0, rs1, RegType::Integer);
        instr->set_wstall(true);
        break;
      case 4: // BAR (sync)
        instr->set_op_type(WctlType::BAR);
        instr->set_src_reg(0, rs1, RegType::Integer);
        instr->set_src_reg(1, rs2, RegType::Integer);
        wctlArgs.is_sync_bar = 1;
        wctlArgs.is_bar_arrive = 0;
        instr->set_wstall(true);
        break;
      case 5: // PRED
        instr->set_op_type(WctlType::PRED);
        instr->set_src_reg(0, rs1, RegType::Integer);
        instr->set_src_reg(1, rs2, RegType::Integer);
        wctlArgs.is_cond_neg = (rd != 0);
        instr->set_wstall(true);
        break;
      case 6: // BAR ARRIVE / WAIT
        instr->set_op_type(WctlType::BAR);
        instr->set_dest_reg(rd, RegType::Integer);
        instr->set_src_reg(0, rs1, RegType::Integer);
        instr->set_src_reg(1, rs2, RegType::Integer);
        wctlArgs.is_sync_bar = 0;
        wctlArgs.is_bar_arrive = (rd != 0);
        instr->set_wstall(rd == 0); // stall on wait, not on arrive
        break;
      case 7: // WSYNC
        instr->set_op_type(WctlType::WSYNC);
        instr->set_wstall(true);
        break;
      default:
        std::abort();
      }
      instr->set_args(wctlArgs);
    } break;
    case 1: { // VOTE
      instr->set_dest_reg(rd, RegType::Integer);
      instr->set_src_reg(0, rs1, RegType::Integer);
      switch (funct3) {
      case 0: instr->set_op_type(VoteType::ALL); break;
      case 1: instr->set_op_type(VoteType::ANY); break;
      case 2: instr->set_op_type(VoteType::UNI); break;
      case 3: instr->set_op_type(VoteType::BAL); break;
      case 4:
        instr->set_op_type(ShflType::UP);
        instr->set_src_reg(1, rs2, RegType::Integer);
        break;
      case 5:
        instr->set_op_type(ShflType::DOWN);
        instr->set_src_reg(1, rs2, RegType::Integer);
        break;
      case 6:
        instr->set_op_type(ShflType::BFLY);
        instr->set_src_reg(1, rs2, RegType::Integer);
        break;
      case 7:
        instr->set_op_type(ShflType::IDX);
        instr->set_src_reg(1, rs2, RegType::Integer);
        break;
      default:
        std::abort();
      }
    } break;
#ifdef VX_CFG_EXT_DXA_ENABLE
    case 3: { // DXA issue
      instr->set_fu_type(FUType::SFU);
      IntrDxaArgs dxaArgs{};
      instr->set_args(dxaArgs);
      instr->set_op_type(DxaType::ISSUE);
      instr->set_src_reg(0, rs1, RegType::Integer);
      instr->set_src_reg(1, rs2, RegType::Integer);
    } break;
#endif
    case 5: { // PQC
      switch (funct3) {
#ifdef VX_CFG_EXT_PQC_ENABLE
      case 0: { // KECCAKF. R-type, rd = x0, rs2 = x0; rs1 is the state pointer.
        // One source, because Keccak-f1600 has no parameters -- 1600 bits in,
        // 1600 bits out, 24 rounds. See
        // pqc/docs/proposals/keccak_ise_proposal.md S2.0. Blocking, so no handle
        // and no destination: next_steps_recipes.md Stage 1 spells an async
        // launch/wait triple which S3.2 of that proposal rejects, and the
        // proposal is the later document.
        instr->set_fu_type(FUType::SFU);
        instr->set_args(IntrPqcArgs{});
        instr->set_op_type(PqcType::KECCAKF);
        instr->set_src_reg(0, rs1, RegType::Integer);
        // The warp must stall until the PE is done. Without this the SFU holds
        // only its own trace: the warp keeps issuing, and its next LSU load of
        // the state runs ahead of the PE. A trace caught the CPU's read response
        // for lane 2 at cycle 130,783 against the PE's first read of that lane at
        // 130,785 -- the program read the state before the engine had touched it,
        // so it read the pre-permutation value. That is unrecoverable by any
        // amount of draining on the PE side, because the stale word is already in
        // a register. Every blocking op in this file does the same thing; the
        // WctlType cases are the model.
        instr->set_wstall(true);
      } break;
#endif
#ifdef VX_CFG_EXT_NTT_ENABLE
      case 2: { // NTTMUL.K
        instr->set_fu_type(FUType::ALU);
        instr->set_op_type(NttType::MUL_K);
        instr->set_dest_reg(rd, RegType::Integer);
        instr->set_src_reg(0, rs1, RegType::Integer);
        instr->set_src_reg(1, rs2, RegType::Integer);
      } break;
      case 3: { // NTTMUL.D
        instr->set_fu_type(FUType::ALU);
        instr->set_op_type(NttType::MUL_D);
        instr->set_dest_reg(rd, RegType::Integer);
        instr->set_src_reg(0, rs1, RegType::Integer);
        instr->set_src_reg(1, rs2, RegType::Integer);
      } break;
#endif
      default: std::abort();
      }
    } break;
#ifdef VX_CFG_EXT_NTT_ENABLE
    case 8:
    case 9: { // NTTBF.{CT,GS}.K
      if (funct3 > 4 || VX_CFG_NUM_ALU_LANES != 32)
        std::abort();
      instr->set_fu_type(FUType::ALU);
      instr->set_op_type(funct7 == 8 ? NttType::BF_CT_K : NttType::BF_GS_K);
      instr->set_args(IntrNttArgs{funct3});
      instr->set_dest_reg(rd, RegType::Integer);
      instr->set_src_reg(0, rs1, RegType::Integer);
      instr->set_src_reg(1, rs2, RegType::Integer);
    } break;
    case 10:
    case 11: { // NTTBF.{CT,GS}.D
      if (funct3 > 4 || VX_CFG_NUM_ALU_LANES != 32)
        std::abort();
      instr->set_fu_type(FUType::ALU);
      instr->set_op_type(funct7 == 10 ? NttType::BF_CT_D : NttType::BF_GS_D);
      instr->set_args(IntrNttArgs{funct3});
      instr->set_dest_reg(rd, RegType::Integer);
      instr->set_src_reg(0, rs1, RegType::Integer);
      instr->set_src_reg(1, rs2, RegType::Integer);
    } break;
#endif
#ifdef VX_CFG_EXT_KSG25_ENABLE
    case 6: {
      instr->set_fu_type(FUType::ALU);
      switch (funct3) {
      case 0: instr->set_op_type(Ksg25Type::THETA_L); break;
      case 1: instr->set_op_type(Ksg25Type::THETA_H); break;
      case 2: instr->set_op_type(Ksg25Type::RHOPI_L); break;
      case 3: instr->set_op_type(Ksg25Type::RHOPI_H); break;
      case 4: instr->set_op_type(Ksg25Type::CHII_L); break;
      case 5: instr->set_op_type(Ksg25Type::CHII_H); break;
      default:
        std::abort();
      }
#if (VX_CFG_XLEN == 64)
      if ((funct3 & 1) != 0) {
        std::abort();
      }
#endif
      instr->set_dest_reg(rd, RegType::Integer);
      instr->set_src_reg(0, rs1, RegType::Integer);
#if (VX_CFG_XLEN == 64)
      if (funct3 == 4) {
        instr->set_src_reg(1, rs2, RegType::Integer);
      }
#else
      instr->set_src_reg(1, rs2, RegType::Integer);
#endif
    } break;
#endif
  #ifdef VX_CFG_EXT_TCU_ENABLE
    case 2: {
      instr->set_fu_type(FUType::TCU);
      switch (funct3) {
      case 0: { // WMMA_SYNC / WMMA_SP_SYNC — single macro Instr, sequencer expands to micro-ops
        uint32_t fmt_d = rd, fmt_s = rs1;
        bool is_sparse = (rs2 & 1) != 0;
        instr->set_op_type(is_sparse ? TcuType::WMMA_SP : TcuType::WMMA);
        instr->set_args(IntrTcuArgs{0, 0, fmt_s, fmt_d, 0, 0, 0, 0, 0, 0});
        instr->set_macro_op();
        instr->set_wstall(true);
      } break;
    #ifdef VX_CFG_TCU_WGMMA_ENABLE
      case 1: { // WGMMA_SYNC — single macro Instr, sequencer expands to micro-ops
        uint32_t fmt_d = rd, fmt_s = rs1;
        bool is_sparse = (rs2 & 1) != 0;
        uint32_t cd_nregs = (rs2 >> 1) & 0x3;
        bool is_a_smem = (rs2 >> 3) & 1;
        instr->set_op_type(is_sparse ? TcuType::WGMMA_SP : TcuType::WGMMA);
        instr->set_args(IntrTcuArgs{is_a_smem ? 1u : 0u, cd_nregs, fmt_s, fmt_d, 0, 0, 0, 0, 0, 0});
        instr->set_macro_op();
        instr->set_wstall(true);
      } break;
    #endif // VX_CFG_TCU_WGMMA_ENABLE
    #ifdef TCU_META_ENABLE
      case 2: { // TCU_LD — rd[4] selects sparse/MX metadata namespace.
        uint32_t fmt_s = rs2;
        uint32_t slot  = rd;
        instr->set_op_type(TcuType::TCU_LD);
        instr->set_args(IntrTcuArgs{0, 0, fmt_s, slot, 0, 0, 0, 0, 0, 0});
        // rs1 holds the warp-broadcast base address (real I-reg read).
        instr->set_src_reg(0, rs1, RegType::Integer);
      } break;
    #endif // TCU_META_ENABLE
      default:
        std::abort();
      }
    } break;
  #endif
    case 4: { // Load/Store Packing extensions — macro-ops, sequencer expands to N single-elem uops
      instr->set_fu_type(FUType::LSU);
      instr->set_op_type(LsuType::LOAD);
      instr->set_dest_reg(rd, RegType::Float);
      instr->set_src_reg(0, rs1, RegType::Integer);
      instr->set_src_reg(1, rs2, RegType::Integer);
      switch (funct3) {
      case 1: { // vx_packlb_f: 4 strided bytes (LB-width) → packed FP
        instr->set_args(IntrLsuArgs{/*width=LB*/ 0, /*stride*/ 0, /*offset*/ 0});
      } break;
      case 2: { // vx_packlh_f: 2 strided halfwords (LH-width) → packed FP
        instr->set_args(IntrLsuArgs{/*width=LH*/ 1, /*stride*/ 0, /*offset*/ 0});
      } break;
      default:
        std::abort();
      }
      instr->set_macro_op();
      instr->set_wstall(true);   // pause fetch while sequencer expands the N uops
    } break;
    default:
      std::abort();
    }
  } break;
  case Opcode::EXT2: {
    switch (funct3) {
    case 0: { // WGATHER
      instr->set_op_type(WgatherType::WGATHER);
      instr->set_dest_reg(rd, RegType::Integer);
      instr->set_src_reg(0, rs1, RegType::Integer);
      instr->set_src_reg(1, rs2, RegType::Integer);
      instr->set_src_reg(2, rs3, RegType::Integer);
      IntrWgatherArgs wgArgs{};
      wgArgs.src_lane = funct2;
      instr->set_args(wgArgs);
    } break;
#ifdef VX_CFG_EXT_TEX_ENABLE
    case 5: { // vx_tex: R4-type. rs1=u, rs2=v, rs3=lod, rd=texel, funct2=stage.
      instr->set_fu_type(FUType::SFU);
      instr->set_op_type(TexType::SAMPLE);
      instr->set_dest_reg(rd, RegType::Integer);    // texel
      instr->set_src_reg(0, rs1, RegType::Integer); // u
      instr->set_src_reg(1, rs2, RegType::Integer); // v
      instr->set_src_reg(2, rs3, RegType::Integer); // lod
      IntrTexArgs texArgs{};
      texArgs.stage = funct2 & 0x1;
      instr->set_args(texArgs);
    } break;
#endif
#ifdef VX_CFG_EXT_OM_ENABLE
    case 3: { // vx_om_export: R4-type, rd=x0. rs1=aperture address, rs2=colour,
              // rs3=depth; funct7[1:0] = {has_depth, has_colour}.
              //
              // In hardware this expands into one or two ordinary stores that the
              // cluster's OM steer peels off the L1->L2 trunk. SimX is
              // transaction-level and does not model memory beats, so it submits
              // the fragment directly -- functionally identical, and it keeps the
              // model from carrying a beat protocol that exists only to fit a
              // 4-byte bus.
      instr->set_fu_type(FUType::SFU);
      instr->set_op_type(OmType::EXPORT);
      instr->set_src_reg(0, rs1, RegType::Integer);  // aperture address
      instr->set_src_reg(1, rs2, RegType::Integer);  // colour
      instr->set_src_reg(2, rs3, RegType::Integer);  // depth
      IntrOmArgs omArgs{};
      omArgs.export_mask = funct7 & 0x3;
      instr->set_args(omArgs);
      // A colour+depth record needs two 4-byte beats, and hardware retires one
      // store uop per beat. Expand so the retired count tracks it; the OM still
      // sees a single fragment, submitted on the last beat.
      if ((omArgs.export_mask & 0x3) == 0x3) {
        instr->set_macro_op();
        instr->set_wstall(true);
      }
    } break;
#endif
#ifdef VX_CFG_EXT_RTU_ENABLE
    case 6: { // RTU callback / hit-window ops. funct2 selects:
              //   sub_op=0  CB_RET  R4-type, rs1=action, rs2=t, rs3=attr, no rd
              //   sub_op=2  GETWF   FP windowed read; sub_op=3 GETW (GP twin)
              // The window is written by the RTU and read by the shader; a
              // candidate's verdict carries its own t/attr, so there is no
              // shader-side window write.
      instr->set_fu_type(FUType::SFU);
      uint32_t sub_op = funct2;
      switch (sub_op) {
#ifdef VX_CFG_EXT_RTU_ENABLE
      case 0: { // CB_RET — releases this lane's parked context in RtuCore,
                // handing back the shader's hit distance and attribute.
                // Dispatcher follows up with `mret` to resume the post-wait PC.
        instr->set_op_type(GfxwType::CB_RET);
        instr->set_src_reg(0, rs1, RegType::Integer); // action
        instr->set_src_reg(1, rs2, RegType::Float);   // hit distance t
        instr->set_src_reg(2, rs3, RegType::Integer); // hit attribute
        IntrGfxwArgs args{};
        instr->set_args(args);
      } break;
#endif
      // GETWF / GETW are window reads shared by RTU (vx_rt_get / vx_rt_wait hit
      // window) AND the gfx FF path (FWD-5 vx_frag_payload), so they are gated on
      // the window, not the RTU. A multi-slot read (count > 1, only RTU's windowed
      // vx_rt_wait) is a macro-op expanded by RtuUopGen; a single-slot read
      // (count <= 1, the gfx frag payload + vx_rt_get) is a plain op handled
      // directly by the SFU window dispatch — so it needs no RTU uop sequencer and
      // works in a pure-gfx (no-RTU) build.
      case 2: { // GETWF — FP windowed regfile read into rd..rd+count-1.
        instr->set_op_type(GfxwType::GETWF);
        instr->set_dest_reg(rd, RegType::Float);   // window base register
        instr->set_src_reg(0, rs1, RegType::Integer); // optional scoreboard chain (x0=none)
        IntrGfxwArgs args{};
        args.slot  = (funct7 >> 2) & 0x1F;         // 5-bit window start slot (funct7[6:2])
        args.count = rs2 & 0xF;                     // slot count (rs2 = imm)
        instr->set_args(args);
        if (args.count > 1) {                      // windowed (RTU) -> macro-op
          instr->set_macro_op();
          instr->set_wstall(true);
        }
      } break;
      case 3: { // GETW — GP twin of GETWF: read `count` contiguous integer slots.
        instr->set_op_type(GfxwType::GETW);
        instr->set_dest_reg(rd, RegType::Integer);  // window base register
        instr->set_src_reg(0, rs1, RegType::Integer); // optional scoreboard chain (x0=none)
        IntrGfxwArgs args{};
        args.slot  = (funct7 >> 2) & 0x1F;         // 5-bit window slot (funct7[6:2])
        args.count = rs2 & 0xF;
        instr->set_args(args);
        if (args.count > 1) {                      // windowed (RTU) -> macro-op
          instr->set_macro_op();
          instr->set_wstall(true);
    }
  } break;
  default:
        std::abort();
      }
    } break;
#endif // VX_CFG_EXT_RTU_ENABLE
#ifdef VX_CFG_EXT_RTU_ENABLE
    case 7: { // RTU — single-issue trace / register-window wait.
              // Both are macro-ops: the per-warp sequencer (RtuUopGen)
              // expands them into the micro-ops that stream the f0..f7 ray
              // window into the pool slot (TRACE) or retire the hit window
              // (WAIT). funct2 selects:
              //   sub_op=0  TRACE  rd=handle, rs1=lane-packed config
              //   sub_op=1  WAIT   rd=status, rs1=handle
              // The f0..f7 ray window / f0..f2 + t3..t5 hit window are read
              // and written by HW convention (see RtuUopGen), so the
              // architectural encoding names only rd/rs1.
      instr->set_fu_type(FUType::SFU);
      uint32_t sub_op = funct2;
      switch (sub_op) {
      case 0: { // TRACE — warp-uniform scene (lane-packed config in rs1)
        instr->set_op_type(GfxwType::TRACE);
        instr->set_dest_reg(rd, RegType::Integer);   // handle
        instr->set_src_reg(0, rs1, RegType::Integer); // lane-packed config
        instr->set_args(IntrGfxwArgs{});
        instr->set_macro_op();
        instr->set_wstall(true);
      } break;
      case 1: { // WAIT — single-op block: park until terminal, return status.
                // NOT a macro-op; reuses the v1 park/revive path so it survives
                // an async callback trap. The hit window is delivered by a
                // separate WAIT_WB the vx_rt_wait intrinsic emits next.
        instr->set_op_type(GfxwType::WAIT);
        instr->set_dest_reg(rd, RegType::Integer);   // status
        instr->set_src_reg(0, rs1, RegType::Integer); // handle
        instr->set_args(IntrGfxwArgs{});
        // WAIT owns the block: it suspends its warp until a record lands and it
        // retires with the status. That is what keeps the warp from fetching past
        // a WAIT whose response has not arrived, so TRACE does not have to hold
        // the warp until the traversal answers — it is released at burst end like
        // any other macro-op.
        instr->set_wstall(true);
      } break;
      default:
        std::abort();
      }
    } break;
#endif
    default:
      std::abort();
    }
    // FF<->SIMT interface-law structural assertion: every FF
    // op routed to the SFU must declare a scoreboarded / side-effect-free /
    // known-violation handoff class, checked against its decoded destination.
    gfx_doctrine::check(*instr);
  } break;
#ifdef VX_CFG_EXT_KROUND25_ENABLE
  case Opcode::EXT3: {
    if (funct7 >= 24 || funct3 >= 2
#if (VX_CFG_XLEN == 64)
        || funct3 != 0
#endif
    ) {
      std::abort();
    }
    instr->set_fu_type(FUType::ALU);
    instr->set_op_type(funct3 == 0 ? Kround25Type::ROUND_L
                                   : Kround25Type::ROUND_H);
    instr->set_args(IntrAluArgs{0, 0, funct7});
    instr->set_dest_reg(rd, RegType::Integer);
    instr->set_src_reg(0, rs1, RegType::Integer);
#if (VX_CFG_XLEN == 32)
    instr->set_src_reg(1, rs2, RegType::Integer);
#endif
  } break;
#endif
  default:
    std::abort();
  }

  return instr;
}
