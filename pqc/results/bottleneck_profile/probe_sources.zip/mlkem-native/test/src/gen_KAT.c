/*
 * Copyright (c) The mlkem-native project authors
 * SPDX-License-Identifier: Apache-2.0 OR ISC OR MIT
 */
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include "../../mlkem/src/fips202/fips202.h"

#include "../../mlkem/mlkem_native.h"
#include "test_common.h"
#include "test_namespace.h"

#if defined(MLK_CONFIG_NO_KEYPAIR_API) || defined(MLK_CONFIG_NO_ENCAPS_API) || \
    defined(MLK_CONFIG_NO_DECAPS_API)
int main(void)
{
  printf("SKIPPED (KAT requires full API)\n");
  return 0;
}
#else /* MLK_CONFIG_NO_KEYPAIR_API || MLK_CONFIG_NO_ENCAPS_API || \
         MLK_CONFIG_NO_DECAPS_API */

#if defined(_WIN64) || defined(_WIN32)
#include <fcntl.h>
#include <io.h>
#endif

/* Note that the entire output of this application feeds into
 * a hash compared with those in META.yml. If you want to reduce
 * the number of KAT tests, META.yml needs adjusting as well. */
#define NTESTS_KAT 100


static void print_hex(const char *label, const uint8_t *data, size_t size)
{
  size_t i;
  printf("%s = ", label);
  for (i = 0; i < size; i++)
  {
    printf("%02x", data[i]);
  }
  printf("\n");
}

/* Prototype for a re-#define'd main, to satisfy -Wmissing-prototypes. */
#if defined(main)
int main(void);
#endif
int main(void)
{
  unsigned i;
  MLK_ALIGN uint8_t coins[3 * MLKEM_SYMBYTES];
  MLK_ALIGN uint8_t pk[MLKEM_PK_BYTES];
  MLK_ALIGN uint8_t sk[MLKEM_SK_BYTES];
  MLK_ALIGN uint8_t ct[MLKEM_CT_BYTES];
  MLK_ALIGN uint8_t ss1[MLKEM_BYTES];
  MLK_ALIGN uint8_t ss2[MLKEM_BYTES];

  const uint8_t seed[64] = {
      32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47,
      48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63,
      64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79,
      80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95,
  };

#if defined(_WIN64) || defined(_WIN32)
  /* Disable automatic CRLF conversion on Windows to match testvector hashes */
  _setmode(_fileno(stdout), _O_BINARY);
#endif


  mlk_shake256(coins, sizeof(coins), seed, sizeof(seed));

  for (i = 0; i < NTESTS_KAT; i++)
  {
    mlk_shake256(coins, sizeof(coins), coins, sizeof(coins));

    CHECK_ERR(mlk_kem_keypair_derand(pk, sk, coins), 0);
    print_hex("pk", pk, sizeof(pk));
    print_hex("sk", sk, sizeof(sk));

    CHECK_ERR(mlk_kem_enc_derand(ct, ss1, pk, coins + 2 * MLKEM_SYMBYTES), 0);
    print_hex("ct", ct, sizeof(ct));

    CHECK_ERR(mlk_kem_dec(ss2, ct, sk), 0);
    CHECK(memcmp(ss1, ss2, sizeof(ss1)) == 0);

    print_hex("ss", ss1, sizeof(ss1));
  }

  return 0;
}
#endif /* !(MLK_CONFIG_NO_KEYPAIR_API || MLK_CONFIG_NO_ENCAPS_API || \
          MLK_CONFIG_NO_DECAPS_API) */
