/*
 * Copyright (c) The mlkem-native project authors
 * SPDX-License-Identifier: Apache-2.0 OR ISC OR MIT
 */
#include <stddef.h>
#include <stdio.h>
#include <string.h>

#include "../notrandombytes/notrandombytes.h"

#include "../../mlkem/src/compress.h"
#include "../../mlkem/src/fips202/keccakf1600.h"
#include "../../mlkem/src/poly.h"
#include "../../mlkem/src/poly_k.h"
#include "../../mlkem/src/sampling.h"
#include "test_common.h"

#ifndef NUM_RANDOM_TESTS
#ifdef MLKEM_DEBUG
#define NUM_RANDOM_TESTS 800
#else
#define NUM_RANDOM_TESTS 8000
#endif
#endif /* !NUM_RANDOM_TESTS */

#ifndef NUM_RANDOM_TESTS_REJ_UNIFORM
#ifdef MLKEM_DEBUG
#define NUM_RANDOM_TESTS_REJ_UNIFORM 100
#else
#define NUM_RANDOM_TESTS_REJ_UNIFORM 1000
#endif
#endif /* !NUM_RANDOM_TESTS_REJ_UNIFORM */

/* Largest absolute constant-coefficient value the invNTT overflow test sweeps.
 * Defaults to a full INT16 sweep; an emulated target (e.g. QEMU) can lower it
 * to keep the run within its time budget. */
#ifndef MAX_INTT_CONSTANT_COEFF
#define MAX_INTT_CONSTANT_COEFF INT16_MAX
#endif

/* Declarations for _c functions exposed by MLK_STATIC_TESTABLE= */

void mlk_poly_reduce_c(mlk_poly *r);
#if !defined(MLK_CONFIG_NO_KEYPAIR_API)
void mlk_poly_tomont_c(mlk_poly *r);
#endif
void mlk_poly_ntt_c(mlk_poly *r);
#if !defined(MLK_CONFIG_NO_ENCAPS_API) || !defined(MLK_CONFIG_NO_DECAPS_API)
void mlk_poly_invntt_tomont_c(mlk_poly *r);
#endif
#if !defined(MLK_CONFIG_NO_KEYPAIR_API) || !defined(MLK_CONFIG_NO_ENCAPS_API)
void mlk_poly_tobytes_c(uint8_t r[MLKEM_POLYBYTES], const mlk_poly *a);
#endif
#if !defined(MLK_CONFIG_NO_ENCAPS_API) || !defined(MLK_CONFIG_NO_DECAPS_API)
void mlk_poly_frombytes_c(mlk_poly *r, const uint8_t a[MLKEM_POLYBYTES]);
#endif
void mlk_polyvec_basemul_acc_montgomery_cached_c(
    mlk_poly *r, const mlk_polyvec *a, const mlk_polyvec *b,
    const mlk_polyvec_mulcache *b_cache);
void mlk_poly_mulcache_compute_c(mlk_poly_mulcache *x, const mlk_poly *a);
void mlk_keccakf1600_permute_c(uint64_t *state);
unsigned mlk_rej_uniform_c(int16_t *r, unsigned target, unsigned offset,
                           const uint8_t *buf, unsigned buflen);
#if !defined(MLK_CONFIG_NO_ENCAPS_API) || !defined(MLK_CONFIG_NO_DECAPS_API)
void mlk_poly_compress_d4_c(uint8_t r[MLKEM_POLYCOMPRESSEDBYTES_D4],
                            const mlk_poly *a);
void mlk_poly_compress_d5_c(uint8_t r[MLKEM_POLYCOMPRESSEDBYTES_D5],
                            const mlk_poly *a);
void mlk_poly_compress_d10_c(uint8_t r[MLKEM_POLYCOMPRESSEDBYTES_D10],
                             const mlk_poly *a);
void mlk_poly_compress_d11_c(uint8_t r[MLKEM_POLYCOMPRESSEDBYTES_D11],
                             const mlk_poly *a);
#endif /* !MLK_CONFIG_NO_ENCAPS_API || !MLK_CONFIG_NO_DECAPS_API */
#if !defined(MLK_CONFIG_NO_DECAPS_API)
void mlk_poly_decompress_d4_c(mlk_poly *r,
                              const uint8_t a[MLKEM_POLYCOMPRESSEDBYTES_D4]);
void mlk_poly_decompress_d5_c(mlk_poly *r,
                              const uint8_t a[MLKEM_POLYCOMPRESSEDBYTES_D5]);
void mlk_poly_decompress_d10_c(mlk_poly *r,
                               const uint8_t a[MLKEM_POLYCOMPRESSEDBYTES_D10]);
void mlk_poly_decompress_d11_c(mlk_poly *r,
                               const uint8_t a[MLKEM_POLYCOMPRESSEDBYTES_D11]);
#endif /* !MLK_CONFIG_NO_DECAPS_API */


#if defined(MLK_USE_NATIVE_FIPS202_X1)
static void print_u64_array(const char *label, const uint64_t *array,
                            size_t len)
{
  size_t i;
  fprintf(stderr, "%s:\n", label);
  for (i = 0; i < len; i++)
  {
    if (i % 4 == 0)
    {
      fprintf(stderr, "  ");
    }
    fprintf(stderr, "%016llx", (unsigned long long)array[i]);
    if (i % 4 == 3)
    {
      fprintf(stderr, "\n");
    }
    else
    {
      fprintf(stderr, " ");
    }
  }
  if (len % 4 != 0)
  {
    fprintf(stderr, "\n");
  }
}

static int compare_u64_arrays(const uint64_t *a, const uint64_t *b,
                              unsigned len, const char *test_name)
{
  unsigned i;
  for (i = 0; i < len; i++)
  {
    if (a[i] != b[i])
    {
      fprintf(stderr, "FAIL: %s\n", test_name);
      fprintf(
          stderr,
          "  First difference at index %u: got=0x%016llx, expected=0x%016llx\n",
          i, (unsigned long long)a[i], (unsigned long long)b[i]);
      print_u64_array("Got", a, len);
      print_u64_array("Expected", b, len);
      return 0;
    }
  }
  return 1;
}
#endif /* MLK_USE_NATIVE_FIPS202_X1 */

#if defined(MLK_USE_NATIVE_POLY_REDUCE) ||                                  \
    defined(MLK_USE_NATIVE_POLY_TOMONT) || defined(MLK_USE_NATIVE_NTT) ||   \
    defined(MLK_USE_NATIVE_INTT) || defined(MLK_USE_NATIVE_POLY_TOBYTES) || \
    defined(MLK_USE_NATIVE_POLY_FROMBYTES) ||                               \
    defined(MLK_USE_NATIVE_POLYVEC_BASEMUL_ACC_MONTGOMERY_CACHED) ||        \
    defined(MLK_USE_NATIVE_FIPS202_X1) || defined(MLK_USE_NATIVE_FIPS202_X4)

/* Backend unit test helper functions for arithmetic native backends */
#if defined(MLK_USE_NATIVE_POLY_REDUCE) ||                                  \
    defined(MLK_USE_NATIVE_POLY_TOMONT) || defined(MLK_USE_NATIVE_NTT) ||   \
    defined(MLK_USE_NATIVE_INTT) || defined(MLK_USE_NATIVE_POLY_TOBYTES) || \
    defined(MLK_USE_NATIVE_POLY_FROMBYTES) ||                               \
    defined(MLK_USE_NATIVE_POLYVEC_BASEMUL_ACC_MONTGOMERY_CACHED) ||        \
    defined(MLK_USE_NATIVE_POLY_COMPRESS_D4) ||                             \
    defined(MLK_USE_NATIVE_POLY_COMPRESS_D5) ||                             \
    defined(MLK_USE_NATIVE_POLY_COMPRESS_D10) ||                            \
    defined(MLK_USE_NATIVE_POLY_COMPRESS_D11) ||                            \
    defined(MLK_USE_NATIVE_POLY_DECOMPRESS_D4) ||                           \
    defined(MLK_USE_NATIVE_POLY_DECOMPRESS_D5) ||                           \
    defined(MLK_USE_NATIVE_POLY_DECOMPRESS_D10) ||                          \
    defined(MLK_USE_NATIVE_POLY_DECOMPRESS_D11)
static void print_i16_array(const char *label, const int16_t *array, size_t len)
{
  size_t i;
  fprintf(stderr, "%s:\n", label);
  for (i = 0; i < len; i++)
  {
    if (i % 16 == 0)
    {
      fprintf(stderr, "  ");
    }
    fprintf(stderr, "%6d", array[i]);
    if (i % 16 == 15)
    {
      fprintf(stderr, "\n");
    }
    else
    {
      fprintf(stderr, " ");
    }
  }
  if (len % 16 != 0)
  {
    fprintf(stderr, "\n");
  }
}

static void generate_i16_array_zeros(int16_t *data, size_t len)
{
  memset(data, 0, len * sizeof(int16_t));
}

static void generate_i16_array_single(int16_t *data, size_t len, size_t pos,
                                      int16_t value)
{
  memset(data, 0, len * sizeof(int16_t));
  data[pos] = value;
}

#if defined(MLK_USE_NATIVE_INTT) && \
    (!defined(MLK_CONFIG_NO_ENCAPS_API) || !defined(MLK_CONFIG_NO_DECAPS_API))
static void generate_i16_array_constant(int16_t *data, size_t len,
                                        int16_t value)
{
  size_t i;
  for (i = 0; i < len; i++)
  {
    data[i] = value;
  }
}
#endif /* MLK_USE_NATIVE_INTT && (!MLK_CONFIG_NO_ENCAPS_API || \
          !MLK_CONFIG_NO_DECAPS_API) */

/* This does not generate a uniformly random distribution, but it's
 * good enough for our test.
 *
 * The lower bound is inclusive, the upper bound exclusive, matching
 * the CBMC assertions in the code base. */
static void generate_i16_array_ranged(int16_t *data, size_t len, int min_incl,
                                      int max_excl)
{
  size_t i;

  randombytes((uint8_t *)data, len * sizeof(int16_t));
  for (i = 0; i < len; i++)
  {
    data[i] = (int16_t)((unsigned)min_incl +
                        ((unsigned)data[i] % (unsigned)(max_excl - min_incl)));
  }
}
#endif /* MLK_USE_NATIVE_POLY_REDUCE || MLK_USE_NATIVE_POLY_TOMONT ||        \
          MLK_USE_NATIVE_NTT || MLK_USE_NATIVE_INTT ||                       \
          MLK_USE_NATIVE_POLY_TOBYTES || MLK_USE_NATIVE_POLY_FROMBYTES ||    \
          MLK_USE_NATIVE_POLYVEC_BASEMUL_ACC_MONTGOMERY_CACHED ||            \
          MLK_USE_NATIVE_POLY_COMPRESS_D4 || MLK_USE_NATIVE_POLY_COMPRESS_D5 \
          || MLK_USE_NATIVE_POLY_COMPRESS_D10 ||                             \
          MLK_USE_NATIVE_POLY_COMPRESS_D11 ||                                \
          MLK_USE_NATIVE_POLY_DECOMPRESS_D4 ||                               \
          MLK_USE_NATIVE_POLY_DECOMPRESS_D5 ||                               \
          MLK_USE_NATIVE_POLY_DECOMPRESS_D10 ||                              \
          MLK_USE_NATIVE_POLY_DECOMPRESS_D11 */

#if (defined(MLK_USE_NATIVE_POLY_TOBYTES) &&     \
     (!defined(MLK_CONFIG_NO_KEYPAIR_API) ||     \
      !defined(MLK_CONFIG_NO_ENCAPS_API))) ||    \
    defined(MLK_USE_NATIVE_POLY_COMPRESS_D4) ||  \
    defined(MLK_USE_NATIVE_POLY_COMPRESS_D5) ||  \
    defined(MLK_USE_NATIVE_POLY_COMPRESS_D10) || \
    defined(MLK_USE_NATIVE_POLY_COMPRESS_D11)
static void print_u8_array(const char *label, const uint8_t *array, size_t len)
{
  size_t i;
  fprintf(stderr, "%s:\n", label);
  for (i = 0; i < len; i++)
  {
    if (i % 16 == 0)
    {
      fprintf(stderr, "  ");
    }
    fprintf(stderr, "%4d", array[i]);
    if (i % 16 == 15)
    {
      fprintf(stderr, "\n");
    }
    else
    {
      fprintf(stderr, " ");
    }
  }
  if (len % 16 != 0)
  {
    fprintf(stderr, "\n");
  }
}

static int compare_u8_arrays(const uint8_t *a, const uint8_t *b, unsigned len,
                             const char *test_name)
{
  unsigned i;
  for (i = 0; i < len; i++)
  {
    if (a[i] != b[i])
    {
      fprintf(stderr, "FAIL: %s\n", test_name);
      fprintf(stderr,
              "  First difference at index %u: native=%d, reference=%d\n", i,
              a[i], b[i]);
      print_u8_array("Native result", a, len);
      print_u8_array("Reference result", b, len);
      return 0;
    }
  }
  return 1;
}
#endif /* (MLK_USE_NATIVE_POLY_TOBYTES && (!MLK_CONFIG_NO_KEYPAIR_API ||      \
          !MLK_CONFIG_NO_ENCAPS_API)) || MLK_USE_NATIVE_POLY_COMPRESS_D4 ||   \
          MLK_USE_NATIVE_POLY_COMPRESS_D5 || MLK_USE_NATIVE_POLY_COMPRESS_D10 \
          || MLK_USE_NATIVE_POLY_COMPRESS_D11 */

#if defined(MLK_USE_NATIVE_POLY_REDUCE) ||                                  \
    defined(MLK_USE_NATIVE_POLY_TOMONT) || defined(MLK_USE_NATIVE_NTT) ||   \
    defined(MLK_USE_NATIVE_INTT) || defined(MLK_USE_NATIVE_POLY_TOBYTES) || \
    defined(MLK_USE_NATIVE_POLY_FROMBYTES) ||                               \
    defined(MLK_USE_NATIVE_POLYVEC_BASEMUL_ACC_MONTGOMERY_CACHED)
static int compare_i16_arrays(const int16_t *a, const int16_t *b, unsigned len,
                              const char *test_name, const int16_t *input)
{
  unsigned i;
  for (i = 0; i < len; i++)
  {
    if (a[i] != b[i])
    {
      fprintf(stderr, "FAIL: %s\n", test_name);
      fprintf(stderr,
              "  First difference at index %u: native=%d, reference=%d\n", i,
              a[i], b[i]);
      if (input)
      {
        print_i16_array("Input", input, len);
      }
      print_i16_array("Native result", a, len);
      print_i16_array("Reference result", b, len);
      return 0;
    }
  }
  return 1;
}
#endif /* MLK_USE_NATIVE_POLY_REDUCE || MLK_USE_NATIVE_POLY_TOMONT ||     \
          MLK_USE_NATIVE_NTT || MLK_USE_NATIVE_INTT ||                    \
          MLK_USE_NATIVE_POLY_TOBYTES || MLK_USE_NATIVE_POLY_FROMBYTES || \
          MLK_USE_NATIVE_POLYVEC_BASEMUL_ACC_MONTGOMERY_CACHED */

#ifdef MLK_USE_NATIVE_POLY_REDUCE
static int test_poly_reduce_core(const int16_t *input, const char *test_name)
{
  int ret = 1;
  MLK_ALLOC(test_poly, mlk_poly, 1, NULL);
  MLK_ALLOC(ref_poly, mlk_poly, 1, NULL);

  if (test_poly == NULL || ref_poly == NULL)
  {
    goto cleanup;
  }

  memcpy(test_poly->coeffs, input, MLKEM_N * sizeof(int16_t));
  memcpy(ref_poly->coeffs, input, MLKEM_N * sizeof(int16_t));

  mlk_poly_reduce(test_poly);
  mlk_poly_reduce_c(ref_poly);

  CHECK(compare_i16_arrays(test_poly->coeffs, ref_poly->coeffs, MLKEM_N,
                           test_name, NULL));
  ret = 0;

cleanup:
  MLK_FREE(ref_poly, mlk_poly, 1, NULL);
  MLK_FREE(test_poly, mlk_poly, 1, NULL);
  return ret;
}

static int test_native_poly_reduce(void)
{
  int16_t test_data[MLKEM_N];
  int pos, i;

  generate_i16_array_zeros(test_data, MLKEM_N);
  CHECK(test_poly_reduce_core(test_data, "poly_reduce_zeros") == 0);

  for (pos = 0; pos < MLKEM_N; pos += MLKEM_N / 8)
  {
    generate_i16_array_single(test_data, MLKEM_N, (size_t)pos, 1);
    CHECK(test_poly_reduce_core(test_data, "poly_reduce_single") == 0);
  }

  for (i = 0; i < NUM_RANDOM_TESTS; i++)
  {
    generate_i16_array_ranged(test_data, MLKEM_N, INT16_MIN, INT16_MAX + 1);
    CHECK(test_poly_reduce_core(test_data, "poly_reduce_random") == 0);
  }

  return 0;
}
#endif /* MLK_USE_NATIVE_POLY_REDUCE */

#if defined(MLK_USE_NATIVE_POLY_TOMONT) && !defined(MLK_CONFIG_NO_KEYPAIR_API)
static int test_poly_tomont_core(const int16_t *input, const char *test_name)
{
  int ret = 1;
  MLK_ALLOC(test_poly, mlk_poly, 1, NULL);
  MLK_ALLOC(ref_poly, mlk_poly, 1, NULL);

  if (test_poly == NULL || ref_poly == NULL)
  {
    goto cleanup;
  }

  memcpy(test_poly->coeffs, input, MLKEM_N * sizeof(int16_t));
  memcpy(ref_poly->coeffs, input, MLKEM_N * sizeof(int16_t));

  mlk_poly_tomont(test_poly);
  mlk_poly_tomont_c(ref_poly);

  /* Normalize */
  mlk_poly_reduce_c(ref_poly);
  mlk_poly_reduce_c(test_poly);

  CHECK(compare_i16_arrays(test_poly->coeffs, ref_poly->coeffs, MLKEM_N,
                           test_name, NULL));
  ret = 0;

cleanup:
  MLK_FREE(ref_poly, mlk_poly, 1, NULL);
  MLK_FREE(test_poly, mlk_poly, 1, NULL);
  return ret;
}

static int test_native_poly_tomont(void)
{
  int16_t test_data[MLKEM_N];
  int pos, i;

  generate_i16_array_zeros(test_data, MLKEM_N);
  CHECK(test_poly_tomont_core(test_data, "poly_tomont_zeros") == 0);

  for (pos = 0; pos < MLKEM_N; pos += MLKEM_N / 8)
  {
    generate_i16_array_single(test_data, MLKEM_N, (size_t)pos, 1);
    CHECK(test_poly_tomont_core(test_data, "poly_tomont_single") == 0);
  }

  for (i = 0; i < NUM_RANDOM_TESTS; i++)
  {
    generate_i16_array_ranged(test_data, MLKEM_N, -MLKEM_Q + 1, MLKEM_Q);
    CHECK(test_poly_tomont_core(test_data, "poly_tomont_random") == 0);
  }

  return 0;
}
#endif /* MLK_USE_NATIVE_POLY_TOMONT && !MLK_CONFIG_NO_KEYPAIR_API */

#ifdef MLK_USE_NATIVE_NTT
static int test_ntt_core(const int16_t *input, const char *test_name)
{
  int ret = 1;
  MLK_ALLOC(test_poly, mlk_poly, 1, NULL);
  MLK_ALLOC(ref_poly, mlk_poly, 1, NULL);

  if (test_poly == NULL || ref_poly == NULL)
  {
    goto cleanup;
  }

  memcpy(test_poly->coeffs, input, MLKEM_N * sizeof(int16_t));
  memcpy(ref_poly->coeffs, input, MLKEM_N * sizeof(int16_t));

  mlk_poly_ntt(test_poly);
  mlk_poly_ntt_c(ref_poly);

#ifdef MLK_USE_NATIVE_NTT_CUSTOM_ORDER
  mlk_poly_permute_bitrev_to_custom(ref_poly->coeffs);
#endif

  /* Normalize */
  mlk_poly_reduce_c(ref_poly);
  mlk_poly_reduce_c(test_poly);

  CHECK(compare_i16_arrays(test_poly->coeffs, ref_poly->coeffs, MLKEM_N,
                           test_name, input));
  ret = 0;

cleanup:
  MLK_FREE(ref_poly, mlk_poly, 1, NULL);
  MLK_FREE(test_poly, mlk_poly, 1, NULL);
  return ret;
}

static int test_native_ntt(void)
{
  int16_t test_data[MLKEM_N];
  int pos, i;

  generate_i16_array_zeros(test_data, MLKEM_N);
  CHECK(test_ntt_core(test_data, "ntt_zeros") == 0);

  for (pos = 0; pos < MLKEM_N; pos += MLKEM_N / 8)
  {
    generate_i16_array_single(test_data, MLKEM_N, (size_t)pos, 1);
    CHECK(test_ntt_core(test_data, "ntt_single") == 0);
  }

  for (i = 0; i < NUM_RANDOM_TESTS; i++)
  {
    generate_i16_array_ranged(test_data, MLKEM_N, -MLKEM_Q + 1, MLKEM_Q);
    CHECK(test_ntt_core(test_data, "ntt_random") == 0);
  }

  return 0;
}
#endif /* MLK_USE_NATIVE_NTT */

#if defined(MLK_USE_NATIVE_INTT) && \
    (!defined(MLK_CONFIG_NO_ENCAPS_API) || !defined(MLK_CONFIG_NO_DECAPS_API))
static int test_intt_core(const int16_t *input, const char *test_name)
{
  int ret = 1;
  MLK_ALLOC(test_poly, mlk_poly, 1, NULL);
  MLK_ALLOC(ref_poly, mlk_poly, 1, NULL);

  if (test_poly == NULL || ref_poly == NULL)
  {
    goto cleanup;
  }

  memcpy(test_poly->coeffs, input, MLKEM_N * sizeof(int16_t));
  memcpy(ref_poly->coeffs, input, MLKEM_N * sizeof(int16_t));

#ifdef MLK_USE_NATIVE_NTT_CUSTOM_ORDER
  mlk_poly_permute_bitrev_to_custom(test_poly->coeffs);
#endif

  mlk_poly_invntt_tomont(test_poly);
  mlk_poly_invntt_tomont_c(ref_poly);

  /* Normalize */
  mlk_poly_reduce_c(ref_poly);
  mlk_poly_reduce_c(test_poly);

  CHECK(compare_i16_arrays(test_poly->coeffs, ref_poly->coeffs, MLKEM_N,
                           test_name, input));
  ret = 0;

cleanup:
  MLK_FREE(ref_poly, mlk_poly, 1, NULL);
  MLK_FREE(test_poly, mlk_poly, 1, NULL);
  return ret;
}

static int test_native_intt(void)
{
  int16_t test_data[MLKEM_N];
  int coeff, pos, i;

  generate_i16_array_zeros(test_data, MLKEM_N);
  CHECK(test_intt_core(test_data, "intt_zeros") == 0);

  for (pos = 0; pos < MLKEM_N; pos += MLKEM_N / 8)
  {
    generate_i16_array_single(test_data, MLKEM_N, (size_t)pos, 1);
    CHECK(test_intt_core(test_data, "intt_single") == 0);
  }

  /* invNTT implementation are at risk of overflow when not
   * correctly reducing those coefficients which grow exponentially
   * fast in the number of layers. Most notably, the first and second
   * coefficients in the output of the invNTT are sums of 128 input
   * coefficients each, which can easily overflow.
   *
   * Test this by running the invNTT on constant input coefficients.
   * Note that since the invNTT often performs a reduction or normalization
   * at the beginning, it's unclear which exact choice of constant data
   * would trigger the largest coefficient growth, so we just try them all.
   *
   * Gradually increase absolute value to find smallest failure first.
   */
  for (coeff = 0; coeff <= MAX_INTT_CONSTANT_COEFF; coeff++)
  {
    generate_i16_array_constant(test_data, MLKEM_N, (int16_t)coeff);
    CHECK(test_intt_core(test_data, "intt_constant") == 0);

    generate_i16_array_constant(test_data, MLKEM_N, (int16_t)-coeff);
    CHECK(test_intt_core(test_data, "intt_constant") == 0);
  }

  /* This one is omitted by the previous loop */
  generate_i16_array_constant(test_data, MLKEM_N, INT16_MIN);
  CHECK(test_intt_core(test_data, "intt_constant") == 0);


  for (i = 0; i < NUM_RANDOM_TESTS; i++)
  {
    generate_i16_array_ranged(test_data, MLKEM_N, INT16_MIN, INT16_MAX + 1);
    CHECK(test_intt_core(test_data, "intt_random") == 0);
  }

  return 0;
}
#endif /* MLK_USE_NATIVE_INTT && (!MLK_CONFIG_NO_ENCAPS_API || \
          !MLK_CONFIG_NO_DECAPS_API) */

#if defined(MLK_USE_NATIVE_POLY_TOBYTES) && \
    (!defined(MLK_CONFIG_NO_KEYPAIR_API) || \
     !defined(MLK_CONFIG_NO_ENCAPS_API))
static int test_poly_tobytes_core(const int16_t *input, const char *test_name)
{
  int ret = 1;
  MLK_ALLOC(test_result, uint8_t, MLKEM_POLYBYTES, NULL);
  MLK_ALLOC(ref_result, uint8_t, MLKEM_POLYBYTES, NULL);
  MLK_ALLOC(test_poly, mlk_poly, 1, NULL);
  MLK_ALLOC(ref_poly, mlk_poly, 1, NULL);

  if (test_result == NULL || ref_result == NULL || test_poly == NULL ||
      ref_poly == NULL)
  {
    goto cleanup;
  }

  memcpy(test_poly->coeffs, input, MLKEM_N * sizeof(int16_t));
  memcpy(ref_poly->coeffs, input, MLKEM_N * sizeof(int16_t));

#ifdef MLK_USE_NATIVE_NTT_CUSTOM_ORDER
  mlk_poly_permute_bitrev_to_custom(test_poly->coeffs);
#endif

  mlk_poly_tobytes(test_result, test_poly);
  mlk_poly_tobytes_c(ref_result, ref_poly);

  CHECK(compare_u8_arrays(test_result, ref_result, MLKEM_POLYBYTES, test_name));
  ret = 0;

cleanup:
  MLK_FREE(ref_poly, mlk_poly, 1, NULL);
  MLK_FREE(test_poly, mlk_poly, 1, NULL);
  MLK_FREE(ref_result, uint8_t, MLKEM_POLYBYTES, NULL);
  MLK_FREE(test_result, uint8_t, MLKEM_POLYBYTES, NULL);
  return ret;
}

static int test_native_poly_tobytes(void)
{
  int16_t test_data[MLKEM_N];
  int pos, i;

  generate_i16_array_zeros(test_data, MLKEM_N);
  CHECK(test_poly_tobytes_core(test_data, "poly_tobytes_zeros") == 0);

  for (pos = 0; pos < MLKEM_N; pos += MLKEM_N / 8)
  {
    generate_i16_array_single(test_data, MLKEM_N, (size_t)pos, 1);
    CHECK(test_poly_tobytes_core(test_data, "poly_tobytes_single") == 0);
  }

  for (i = 0; i < NUM_RANDOM_TESTS; i++)
  {
    generate_i16_array_ranged(test_data, MLKEM_N, 0, MLKEM_Q);
    CHECK(test_poly_tobytes_core(test_data, "poly_tobytes_random") == 0);
  }

  return 0;
}
#endif /* MLK_USE_NATIVE_POLY_TOBYTES && (!MLK_CONFIG_NO_KEYPAIR_API || \
          !MLK_CONFIG_NO_ENCAPS_API) */

#if defined(MLK_USE_NATIVE_POLY_FROMBYTES) && \
    (!defined(MLK_CONFIG_NO_ENCAPS_API) || !defined(MLK_CONFIG_NO_DECAPS_API))
static int test_poly_frombytes_core(const uint8_t *input_bytes,
                                    const char *test_name)
{
  int ret = 1;
  MLK_ALLOC(test_poly, mlk_poly, 1, NULL);
  MLK_ALLOC(ref_poly, mlk_poly, 1, NULL);

  if (test_poly == NULL || ref_poly == NULL)
  {
    goto cleanup;
  }

  mlk_poly_frombytes(test_poly, input_bytes);
  mlk_poly_frombytes_c(ref_poly, input_bytes);

#ifdef MLK_USE_NATIVE_NTT_CUSTOM_ORDER
  mlk_poly_permute_bitrev_to_custom(ref_poly->coeffs);
#endif

  CHECK(compare_i16_arrays(test_poly->coeffs, ref_poly->coeffs, MLKEM_N,
                           test_name, NULL));
  ret = 0;

cleanup:
  MLK_FREE(ref_poly, mlk_poly, 1, NULL);
  MLK_FREE(test_poly, mlk_poly, 1, NULL);
  return ret;
}

static int test_native_poly_frombytes(void)
{
  uint8_t test_bytes[MLKEM_POLYBYTES];
  int16_t temp_data[MLKEM_POLYBYTES / 2];
  int i;

  /* Test with zero bytes */
  memset(test_bytes, 0, MLKEM_POLYBYTES);
  CHECK(test_poly_frombytes_core(test_bytes, "poly_frombytes_zeros") == 0);

  /* Test with incremental bytes */
  generate_i16_array_zeros(temp_data, MLKEM_POLYBYTES / 2);
  generate_i16_array_ranged(temp_data, MLKEM_POLYBYTES / 2, INT16_MIN,
                            INT16_MAX + 1);
  memcpy(test_bytes, temp_data, MLKEM_POLYBYTES);
  CHECK(test_poly_frombytes_core(test_bytes, "poly_frombytes_incremental") ==
        0);

  /* Test with random bytes */
  for (i = 0; i < NUM_RANDOM_TESTS; i++)
  {
    generate_i16_array_ranged(temp_data, MLKEM_POLYBYTES / 2, INT16_MIN,
                              INT16_MAX + 1);
    memcpy(test_bytes, temp_data, MLKEM_POLYBYTES);
    CHECK(test_poly_frombytes_core(test_bytes, "poly_frombytes_random") == 0);
  }

  return 0;
}
#endif /* MLK_USE_NATIVE_POLY_FROMBYTES && (!MLK_CONFIG_NO_ENCAPS_API || \
          !MLK_CONFIG_NO_DECAPS_API) */

#ifdef MLK_USE_NATIVE_POLYVEC_BASEMUL_ACC_MONTGOMERY_CACHED
static int test_polyvec_basemul_core(const int16_t *a, const int16_t *b,
                                     const char *test_name)
{
  int ret = 1;
  int i;
  MLK_ALLOC(test_result, mlk_poly, 1, NULL);
  MLK_ALLOC(ref_result, mlk_poly, 1, NULL);
  MLK_ALLOC(test_a, mlk_polyvec, 1, NULL);
  MLK_ALLOC(test_b, mlk_polyvec, 1, NULL);
  MLK_ALLOC(ref_a, mlk_polyvec, 1, NULL);
  MLK_ALLOC(ref_b, mlk_polyvec, 1, NULL);
  MLK_ALLOC(test_cache, mlk_polyvec_mulcache, 1, NULL);
  MLK_ALLOC(ref_cache, mlk_polyvec_mulcache, 1, NULL);

  if (test_result == NULL || ref_result == NULL || test_a == NULL ||
      test_b == NULL || ref_a == NULL || ref_b == NULL || test_cache == NULL ||
      ref_cache == NULL)
  {
    goto cleanup;
  }

  /* Copy test data to structures */
  for (i = 0; i < MLKEM_K; i++)
  {
    memcpy(test_a->vec[i].coeffs, &a[i * MLKEM_N], MLKEM_N * sizeof(int16_t));
    memcpy(test_b->vec[i].coeffs, &b[i * MLKEM_N], MLKEM_N * sizeof(int16_t));
    memcpy(ref_a->vec[i].coeffs, &a[i * MLKEM_N], MLKEM_N * sizeof(int16_t));
    memcpy(ref_b->vec[i].coeffs, &b[i * MLKEM_N], MLKEM_N * sizeof(int16_t));

#ifdef MLK_USE_NATIVE_NTT_CUSTOM_ORDER
    mlk_poly_permute_bitrev_to_custom(test_a->vec[i].coeffs);
    mlk_poly_permute_bitrev_to_custom(test_b->vec[i].coeffs);
#endif

    mlk_poly_mulcache_compute_c(&ref_cache->vec[i], &ref_b->vec[i]);
    mlk_poly_mulcache_compute(&test_cache->vec[i], &test_b->vec[i]);
  }

  mlk_polyvec_basemul_acc_montgomery_cached(test_result, test_a, test_b,
                                            test_cache);
  mlk_polyvec_basemul_acc_montgomery_cached_c(ref_result, ref_a, ref_b,
                                              ref_cache);

#ifdef MLK_USE_NATIVE_NTT_CUSTOM_ORDER
  mlk_poly_permute_bitrev_to_custom(ref_result->coeffs);
#endif

  /* Normalize */
  mlk_poly_reduce_c(ref_result);
  mlk_poly_reduce_c(test_result);

  CHECK(compare_i16_arrays(test_result->coeffs, ref_result->coeffs, MLKEM_N,
                           test_name, NULL));
  ret = 0;

cleanup:
  MLK_FREE(ref_cache, mlk_polyvec_mulcache, 1, NULL);
  MLK_FREE(test_cache, mlk_polyvec_mulcache, 1, NULL);
  MLK_FREE(ref_b, mlk_polyvec, 1, NULL);
  MLK_FREE(ref_a, mlk_polyvec, 1, NULL);
  MLK_FREE(test_b, mlk_polyvec, 1, NULL);
  MLK_FREE(test_a, mlk_polyvec, 1, NULL);
  MLK_FREE(ref_result, mlk_poly, 1, NULL);
  MLK_FREE(test_result, mlk_poly, 1, NULL);
  return ret;
}

static int test_native_polyvec_basemul(void)
{
  int16_t a[MLKEM_K * MLKEM_N];
  int16_t b[MLKEM_K * MLKEM_N];
  int i;

  /* Test with zeros */
  generate_i16_array_zeros(a, MLKEM_K * MLKEM_N);
  generate_i16_array_zeros(b, MLKEM_K * MLKEM_N);
  CHECK(test_polyvec_basemul_core(a, b, "polyvec_basemul_zeros") == 0);

  /* Test with random data */
  for (i = 0; i < NUM_RANDOM_TESTS; i++)
  {
    generate_i16_array_ranged(a, MLKEM_K * MLKEM_N, 0, MLKEM_UINT12_LIMIT);
    generate_i16_array_ranged(b, MLKEM_K * MLKEM_N, 0, MLKEM_UINT12_LIMIT);
    CHECK(test_polyvec_basemul_core(a, b, "polyvec_basemul_random") == 0);
  }

  return 0;
}
#endif /* MLK_USE_NATIVE_POLYVEC_BASEMUL_ACC_MONTGOMERY_CACHED */

#ifdef MLK_USE_NATIVE_FIPS202_X1
static int test_keccakf1600_permute(void)
{
  int ret = 1;
  int i;
  MLK_ALLOC(state, uint64_t, MLK_KECCAK_LANES, NULL);
  MLK_ALLOC(state_ref, uint64_t, MLK_KECCAK_LANES, NULL);

  if (state == NULL || state_ref == NULL)
  {
    goto cleanup;
  }

  for (i = 0; i < NUM_RANDOM_TESTS; i++)
  {
    randombytes((uint8_t *)state, MLK_KECCAK_LANES * sizeof(uint64_t));
    memcpy(state_ref, state, MLK_KECCAK_LANES * sizeof(uint64_t));

    mlk_keccakf1600_permute(state);
    mlk_keccakf1600_permute_c(state_ref);

    CHECK(compare_u64_arrays(state, state_ref, MLK_KECCAK_LANES,
                             "keccakf1600_permute"));
  }

  ret = 0;

cleanup:
  MLK_FREE(state_ref, uint64_t, MLK_KECCAK_LANES, NULL);
  MLK_FREE(state, uint64_t, MLK_KECCAK_LANES, NULL);
  return ret;
}
#endif /* MLK_USE_NATIVE_FIPS202_X1 */

/*
 * Test that x4 Keccak (xor_bytes, permute, extract_bytes) produces
 * the same results as the x1 C reference.
 */
#ifdef MLK_USE_NATIVE_FIPS202_X4
#define MAX_RATE 136

static int test_keccakf1600x4_xor_permute_extract(void)
{
  int ret = 1;
  int i, j;
  uint8_t xor_offset, xor_length, ext_offset, ext_length;
  MLK_ALLOC(state_x4, uint64_t, MLK_KECCAK_LANES *MLK_KECCAK_WAY, NULL);
  MLK_ALLOC(state_x1, uint64_t, MLK_KECCAK_LANES, NULL);
  MLK_ALLOC(output_x1, unsigned char, MAX_RATE, NULL);
  MLK_ALLOC(output_x4_0, unsigned char, MAX_RATE, NULL);
  MLK_ALLOC(output_x4_1, unsigned char, MAX_RATE, NULL);
  MLK_ALLOC(output_x4_2, unsigned char, MAX_RATE, NULL);
  MLK_ALLOC(output_x4_3, unsigned char, MAX_RATE, NULL);
  MLK_ALLOC(input_0, unsigned char, MAX_RATE, NULL);
  MLK_ALLOC(input_1, unsigned char, MAX_RATE, NULL);
  MLK_ALLOC(input_2, unsigned char, MAX_RATE, NULL);
  MLK_ALLOC(input_3, unsigned char, MAX_RATE, NULL);

  unsigned char *output_x4[MLK_KECCAK_WAY];
  unsigned char *input[MLK_KECCAK_WAY];
  output_x4[0] = output_x4_0;
  output_x4[1] = output_x4_1;
  output_x4[2] = output_x4_2;
  output_x4[3] = output_x4_3;
  input[0] = input_0;
  input[1] = input_1;
  input[2] = input_2;
  input[3] = input_3;

  if (state_x4 == NULL || state_x1 == NULL || output_x1 == NULL ||
      output_x4_0 == NULL || output_x4_1 == NULL || output_x4_2 == NULL ||
      output_x4_3 == NULL || input_0 == NULL || input_1 == NULL ||
      input_2 == NULL || input_3 == NULL)
  {
    goto cleanup;
  }

  for (i = 0; i < NUM_RANDOM_TESTS; i++)
  {
    /* Generate random offset and length for xor_bytes */
    randombytes(&xor_offset, 1);
    randombytes(&xor_length, 1);
    xor_offset = xor_offset % MAX_RATE;
    xor_length = (uint8_t)(1 + (xor_length % (MAX_RATE - xor_offset)));

    /* Generate random offset and length for extract_bytes */
    randombytes(&ext_offset, 1);
    randombytes(&ext_length, 1);
    ext_offset = ext_offset % MAX_RATE;
    ext_length = (uint8_t)(1 + (ext_length % (MAX_RATE - ext_offset)));

    /* Generate different random input for each lane */
    for (j = 0; j < MLK_KECCAK_WAY; j++)
    {
      randombytes(input[j], xor_length);
    }

    /* Run x4 implementation */
    memset(state_x4, 0, MLK_KECCAK_LANES * MLK_KECCAK_WAY * sizeof(uint64_t));
    mlk_keccakf1600x4_xor_bytes(state_x4, input[0], input[1], input[2],
                                input[3], xor_offset, xor_length);
    mlk_keccakf1600x4_permute(state_x4);
    mlk_keccakf1600x4_extract_bytes(state_x4, output_x4[0], output_x4[1],
                                    output_x4[2], output_x4[3], ext_offset,
                                    ext_length);

    /* Compare each lane against x1 C reference */
    for (j = 0; j < MLK_KECCAK_WAY; j++)
    {
      memset(state_x1, 0, MLK_KECCAK_LANES * sizeof(uint64_t));
      mlk_keccakf1600_xor_bytes(state_x1, input[j], xor_offset, xor_length);
      mlk_keccakf1600_permute_c(state_x1);
      mlk_keccakf1600_extract_bytes(state_x1, output_x1, ext_offset,
                                    ext_length);

      CHECK(memcmp(output_x4[j], output_x1, ext_length) == 0);
    }
  }

  ret = 0;

cleanup:
  MLK_FREE(input_3, unsigned char, MAX_RATE, NULL);
  MLK_FREE(input_2, unsigned char, MAX_RATE, NULL);
  MLK_FREE(input_1, unsigned char, MAX_RATE, NULL);
  MLK_FREE(input_0, unsigned char, MAX_RATE, NULL);
  MLK_FREE(output_x4_3, unsigned char, MAX_RATE, NULL);
  MLK_FREE(output_x4_2, unsigned char, MAX_RATE, NULL);
  MLK_FREE(output_x4_1, unsigned char, MAX_RATE, NULL);
  MLK_FREE(output_x4_0, unsigned char, MAX_RATE, NULL);
  MLK_FREE(output_x1, unsigned char, MAX_RATE, NULL);
  MLK_FREE(state_x1, uint64_t, MLK_KECCAK_LANES, NULL);
  MLK_FREE(state_x4, uint64_t, MLK_KECCAK_LANES *MLK_KECCAK_WAY, NULL);
  return ret;
}

#undef MAX_RATE
#endif /* MLK_USE_NATIVE_FIPS202_X4 */

#ifdef MLK_USE_NATIVE_REJ_UNIFORM
#define REJ_UNIFORM_BUFLEN 504 /* 3 * 168, divisible by 3 */
static int test_native_rej_uniform(void)
{
  int ret = 1;
  int i;
  MLK_ALLOC(r_test, int16_t, MLKEM_N, NULL);
  MLK_ALLOC(r_ref, int16_t, MLKEM_N, NULL);
  MLK_ALLOC(buf, uint8_t, REJ_UNIFORM_BUFLEN, NULL);

  if (r_test == NULL || r_ref == NULL || buf == NULL)
  {
    goto cleanup;
  }

  for (i = 0; i < NUM_RANDOM_TESTS; i++)
  {
    int native_ret;
    unsigned c_ret;
    randombytes(buf, REJ_UNIFORM_BUFLEN);

    native_ret =
        mlk_rej_uniform_native(r_test, MLKEM_N, buf, REJ_UNIFORM_BUFLEN);
    if (native_ret == MLK_NATIVE_FUNC_FALLBACK)
    {
      ret = 0;
      goto cleanup;
    }

    c_ret = mlk_rej_uniform_c(r_ref, MLKEM_N, 0, buf, REJ_UNIFORM_BUFLEN);

    CHECK((unsigned)native_ret == c_ret);
    CHECK(compare_i16_arrays(r_test, r_ref, (unsigned)native_ret, "rej_uniform",
                             NULL));
  }

  ret = 0;

cleanup:
  MLK_FREE(buf, uint8_t, REJ_UNIFORM_BUFLEN, NULL);
  MLK_FREE(r_ref, int16_t, MLKEM_N, NULL);
  MLK_FREE(r_test, int16_t, MLKEM_N, NULL);
  return ret;
}
#undef REJ_UNIFORM_BUFLEN
#endif /* MLK_USE_NATIVE_REJ_UNIFORM */

/* Backend unit tests for poly compress/decompress native implementations.
 * For each variant, we compare the native output against the C reference. */

#define DEFINE_COMPRESS_TEST(D, BYTES)                                      \
  static int test_native_poly_compress_d##D(void)                           \
  {                                                                         \
    int ret = 1;                                                            \
    int i;                                                                  \
    MLK_ALLOC(r_test, uint8_t, BYTES, NULL);                                \
    MLK_ALLOC(r_ref, uint8_t, BYTES, NULL);                                 \
    MLK_ALLOC(a, mlk_poly, 1, NULL);                                        \
                                                                            \
    if (r_test == NULL || r_ref == NULL || a == NULL)                       \
    {                                                                       \
      goto cleanup;                                                         \
    }                                                                       \
                                                                            \
    for (i = 0; i < NUM_RANDOM_TESTS; i++)                                  \
    {                                                                       \
      int native_ret;                                                       \
      generate_i16_array_ranged(a->coeffs, MLKEM_N, 0, MLKEM_Q);            \
                                                                            \
      native_ret = mlk_poly_compress_d##D##_native(r_test, a->coeffs);      \
      if (native_ret == MLK_NATIVE_FUNC_FALLBACK)                           \
      {                                                                     \
        ret = 0;                                                            \
        goto cleanup;                                                       \
      }                                                                     \
                                                                            \
      mlk_poly_compress_d##D##_c(r_ref, a);                                 \
      CHECK(compare_u8_arrays(r_test, r_ref, BYTES, "poly_compress_d" #D)); \
    }                                                                       \
                                                                            \
    ret = 0;                                                                \
                                                                            \
  cleanup:                                                                  \
    MLK_FREE(a, mlk_poly, 1, NULL);                                         \
    MLK_FREE(r_ref, uint8_t, BYTES, NULL);                                  \
    MLK_FREE(r_test, uint8_t, BYTES, NULL);                                 \
    return ret;                                                             \
  }

#define DEFINE_DECOMPRESS_TEST(D, BYTES)                                 \
  static int test_native_poly_decompress_d##D(void)                      \
  {                                                                      \
    int ret = 1;                                                         \
    int i;                                                               \
    MLK_ALLOC(r_test, mlk_poly, 1, NULL);                                \
    MLK_ALLOC(r_ref, mlk_poly, 1, NULL);                                 \
    MLK_ALLOC(a, uint8_t, BYTES, NULL);                                  \
                                                                         \
    if (r_test == NULL || r_ref == NULL || a == NULL)                    \
    {                                                                    \
      goto cleanup;                                                      \
    }                                                                    \
                                                                         \
    for (i = 0; i < NUM_RANDOM_TESTS; i++)                               \
    {                                                                    \
      int native_ret;                                                    \
      randombytes(a, BYTES);                                             \
                                                                         \
      native_ret = mlk_poly_decompress_d##D##_native(r_test->coeffs, a); \
      if (native_ret == MLK_NATIVE_FUNC_FALLBACK)                        \
      {                                                                  \
        ret = 0;                                                         \
        goto cleanup;                                                    \
      }                                                                  \
                                                                         \
      mlk_poly_decompress_d##D##_c(r_ref, a);                            \
      CHECK(compare_i16_arrays(r_test->coeffs, r_ref->coeffs, MLKEM_N,   \
                               "poly_decompress_d" #D, NULL));           \
    }                                                                    \
                                                                         \
    ret = 0;                                                             \
                                                                         \
  cleanup:                                                               \
    MLK_FREE(a, uint8_t, BYTES, NULL);                                   \
    MLK_FREE(r_ref, mlk_poly, 1, NULL);                                  \
    MLK_FREE(r_test, mlk_poly, 1, NULL);                                 \
    return ret;                                                          \
  }

#if defined(MLK_CONFIG_MULTILEVEL_WITH_SHARED) || (MLKEM_K == 2 || MLKEM_K == 3)
#if defined(MLK_USE_NATIVE_POLY_COMPRESS_D4) && \
    (!defined(MLK_CONFIG_NO_ENCAPS_API) || !defined(MLK_CONFIG_NO_DECAPS_API))
DEFINE_COMPRESS_TEST(4, MLKEM_POLYCOMPRESSEDBYTES_D4)
#endif
#if defined(MLK_USE_NATIVE_POLY_DECOMPRESS_D4) && \
    !defined(MLK_CONFIG_NO_DECAPS_API)
DEFINE_DECOMPRESS_TEST(4, MLKEM_POLYCOMPRESSEDBYTES_D4)
#endif
#if defined(MLK_USE_NATIVE_POLY_COMPRESS_D10) && \
    (!defined(MLK_CONFIG_NO_ENCAPS_API) || !defined(MLK_CONFIG_NO_DECAPS_API))
DEFINE_COMPRESS_TEST(10, MLKEM_POLYCOMPRESSEDBYTES_D10)
#endif
#if defined(MLK_USE_NATIVE_POLY_DECOMPRESS_D10) && \
    !defined(MLK_CONFIG_NO_DECAPS_API)
DEFINE_DECOMPRESS_TEST(10, MLKEM_POLYCOMPRESSEDBYTES_D10)
#endif
#endif /* MLK_CONFIG_MULTILEVEL_WITH_SHARED || MLKEM_K == 2 || MLKEM_K == 3 */

#if defined(MLK_CONFIG_MULTILEVEL_WITH_SHARED) || MLKEM_K == 4
#if defined(MLK_USE_NATIVE_POLY_COMPRESS_D5) && \
    (!defined(MLK_CONFIG_NO_ENCAPS_API) || !defined(MLK_CONFIG_NO_DECAPS_API))
DEFINE_COMPRESS_TEST(5, MLKEM_POLYCOMPRESSEDBYTES_D5)
#endif
#if defined(MLK_USE_NATIVE_POLY_DECOMPRESS_D5) && \
    !defined(MLK_CONFIG_NO_DECAPS_API)
DEFINE_DECOMPRESS_TEST(5, MLKEM_POLYCOMPRESSEDBYTES_D5)
#endif
#if defined(MLK_USE_NATIVE_POLY_COMPRESS_D11) && \
    (!defined(MLK_CONFIG_NO_ENCAPS_API) || !defined(MLK_CONFIG_NO_DECAPS_API))
DEFINE_COMPRESS_TEST(11, MLKEM_POLYCOMPRESSEDBYTES_D11)
#endif
#if defined(MLK_USE_NATIVE_POLY_DECOMPRESS_D11) && \
    !defined(MLK_CONFIG_NO_DECAPS_API)
DEFINE_DECOMPRESS_TEST(11, MLKEM_POLYCOMPRESSEDBYTES_D11)
#endif
#endif /* MLK_CONFIG_MULTILEVEL_WITH_SHARED || MLKEM_K == 4 */

static int test_backend_units(void)
{
  /* Set fixed seed for reproducible tests */
  randombytes_reset();

#ifdef MLK_USE_NATIVE_POLY_REDUCE
  CHECK(test_native_poly_reduce() == 0);
#endif

#if defined(MLK_USE_NATIVE_POLY_TOMONT) && !defined(MLK_CONFIG_NO_KEYPAIR_API)
  CHECK(test_native_poly_tomont() == 0);
#endif

#ifdef MLK_USE_NATIVE_NTT
  CHECK(test_native_ntt() == 0);
#endif

#if defined(MLK_USE_NATIVE_INTT) && \
    (!defined(MLK_CONFIG_NO_ENCAPS_API) || !defined(MLK_CONFIG_NO_DECAPS_API))
  CHECK(test_native_intt() == 0);
#endif

#if defined(MLK_USE_NATIVE_POLY_TOBYTES) && \
    (!defined(MLK_CONFIG_NO_KEYPAIR_API) || \
     !defined(MLK_CONFIG_NO_ENCAPS_API))
  CHECK(test_native_poly_tobytes() == 0);
#endif

#if defined(MLK_USE_NATIVE_POLY_FROMBYTES) && \
    (!defined(MLK_CONFIG_NO_ENCAPS_API) || !defined(MLK_CONFIG_NO_DECAPS_API))
  CHECK(test_native_poly_frombytes() == 0);
#endif

#ifdef MLK_USE_NATIVE_POLYVEC_BASEMUL_ACC_MONTGOMERY_CACHED
  CHECK(test_native_polyvec_basemul() == 0);
#endif

#ifdef MLK_USE_NATIVE_FIPS202_X1
  CHECK(test_keccakf1600_permute() == 0);
#endif

#ifdef MLK_USE_NATIVE_FIPS202_X4
  CHECK(test_keccakf1600x4_xor_permute_extract() == 0);
#endif

#ifdef MLK_USE_NATIVE_REJ_UNIFORM
  CHECK(test_native_rej_uniform() == 0);
#endif

#if defined(MLK_CONFIG_MULTILEVEL_WITH_SHARED) || (MLKEM_K == 2 || MLKEM_K == 3)
#if defined(MLK_USE_NATIVE_POLY_COMPRESS_D4) && \
    (!defined(MLK_CONFIG_NO_ENCAPS_API) || !defined(MLK_CONFIG_NO_DECAPS_API))
  CHECK(test_native_poly_compress_d4() == 0);
#endif
#if defined(MLK_USE_NATIVE_POLY_DECOMPRESS_D4) && \
    !defined(MLK_CONFIG_NO_DECAPS_API)
  CHECK(test_native_poly_decompress_d4() == 0);
#endif
#if defined(MLK_USE_NATIVE_POLY_COMPRESS_D10) && \
    (!defined(MLK_CONFIG_NO_ENCAPS_API) || !defined(MLK_CONFIG_NO_DECAPS_API))
  CHECK(test_native_poly_compress_d10() == 0);
#endif
#if defined(MLK_USE_NATIVE_POLY_DECOMPRESS_D10) && \
    !defined(MLK_CONFIG_NO_DECAPS_API)
  CHECK(test_native_poly_decompress_d10() == 0);
#endif
#endif /* MLK_CONFIG_MULTILEVEL_WITH_SHARED || MLKEM_K == 2 || MLKEM_K == 3 */

#if defined(MLK_CONFIG_MULTILEVEL_WITH_SHARED) || MLKEM_K == 4
#if defined(MLK_USE_NATIVE_POLY_COMPRESS_D5) && \
    (!defined(MLK_CONFIG_NO_ENCAPS_API) || !defined(MLK_CONFIG_NO_DECAPS_API))
  CHECK(test_native_poly_compress_d5() == 0);
#endif
#if defined(MLK_USE_NATIVE_POLY_DECOMPRESS_D5) && \
    !defined(MLK_CONFIG_NO_DECAPS_API)
  CHECK(test_native_poly_decompress_d5() == 0);
#endif
#if defined(MLK_USE_NATIVE_POLY_COMPRESS_D11) && \
    (!defined(MLK_CONFIG_NO_ENCAPS_API) || !defined(MLK_CONFIG_NO_DECAPS_API))
  CHECK(test_native_poly_compress_d11() == 0);
#endif
#if defined(MLK_USE_NATIVE_POLY_DECOMPRESS_D11) && \
    !defined(MLK_CONFIG_NO_DECAPS_API)
  CHECK(test_native_poly_decompress_d11() == 0);
#endif
#endif /* MLK_CONFIG_MULTILEVEL_WITH_SHARED || MLKEM_K == 4 */

  return 0;
}

#endif /* MLK_USE_NATIVE_POLY_REDUCE || MLK_USE_NATIVE_POLY_TOMONT ||     \
          MLK_USE_NATIVE_NTT || MLK_USE_NATIVE_INTT ||                    \
          MLK_USE_NATIVE_POLY_TOBYTES || MLK_USE_NATIVE_POLY_FROMBYTES || \
          MLK_USE_NATIVE_POLYVEC_BASEMUL_ACC_MONTGOMERY_CACHED ||         \
          MLK_USE_NATIVE_FIPS202_X1 || MLK_USE_NATIVE_FIPS202_X4 */

/* poly_rej_uniform and poly_rej_uniform_4x implement the same
 * functionality with different degrees of batching. This unit
 * test makes sure these functions indeed produce the same
 * outputs. */
#if !defined(MLK_CONFIG_SERIAL_FIPS202_ONLY)
static int test_poly_rej_uniform_consistency(void)
{
  int ret = 1;
  int i, j;
  MLK_ALLOC(vec_x4, mlk_poly, 4, NULL);
  MLK_ALLOC(vec_x1, mlk_poly, 4, NULL);
  MLK_ALLOC(seed, uint8_t, 4 * MLK_ALIGN_UP(MLKEM_SYMBYTES + 2), NULL);

  if (vec_x4 == NULL || vec_x1 == NULL || seed == NULL)
  {
    goto cleanup;
  }

  for (i = 0; i < NUM_RANDOM_TESTS_REJ_UNIFORM; i++)
  {
    for (j = 0; j < 4; j++)
    {
      randombytes(seed + j * MLK_ALIGN_UP(MLKEM_SYMBYTES + 2),
                  MLKEM_SYMBYTES + 2);
    }

    /* Test x4 version */
    mlk_poly_rej_uniform_x4(&vec_x4[0], &vec_x4[1], &vec_x4[2], &vec_x4[3],
                            (uint8_t (*)[MLK_ALIGN_UP(MLKEM_SYMBYTES + 2)])
                                seed);

    /* Test x1 version with same seeds */
    for (j = 0; j < 4; j++)
    {
      mlk_poly_rej_uniform(&vec_x1[j],
                           seed + j * MLK_ALIGN_UP(MLKEM_SYMBYTES + 2));
    }

    /* Compare results */
    for (j = 0; j < 4; j++)
    {
      CHECK(memcmp(vec_x4[j].coeffs, vec_x1[j].coeffs,
                   MLKEM_N * sizeof(int16_t)) == 0);
    }
  }

  ret = 0;

cleanup:
  MLK_FREE(seed, uint8_t, 4 * MLK_ALIGN_UP(MLKEM_SYMBYTES + 2), NULL);
  MLK_FREE(vec_x1, mlk_poly, 4, NULL);
  MLK_FREE(vec_x4, mlk_poly, 4, NULL);
  return ret;
}
#endif /* !MLK_CONFIG_SERIAL_FIPS202_ONLY */



/* Prototype for a re-#define'd main, to satisfy -Wmissing-prototypes. */
#if defined(main)
int main(void);
#endif
int main(void)
{
  /* WARNING: Test-only
   * Normally, you would want to seed a PRNG with trustworthy entropy here. */
  randombytes_reset();

  /* Run backend unit tests */
#if defined(MLK_USE_NATIVE_POLY_REDUCE) ||                                  \
    defined(MLK_USE_NATIVE_POLY_TOMONT) || defined(MLK_USE_NATIVE_NTT) ||   \
    defined(MLK_USE_NATIVE_INTT) || defined(MLK_USE_NATIVE_POLY_TOBYTES) || \
    defined(MLK_USE_NATIVE_POLY_FROMBYTES) ||                               \
    defined(MLK_USE_NATIVE_POLYVEC_BASEMUL_ACC_MONTGOMERY_CACHED) ||        \
    defined(MLK_USE_NATIVE_FIPS202_X1) || defined(MLK_USE_NATIVE_FIPS202_X4)
  CHECK(test_backend_units() == 0);
#endif /* MLK_USE_NATIVE_POLY_REDUCE || MLK_USE_NATIVE_POLY_TOMONT ||     \
          MLK_USE_NATIVE_NTT || MLK_USE_NATIVE_INTT ||                    \
          MLK_USE_NATIVE_POLY_TOBYTES || MLK_USE_NATIVE_POLY_FROMBYTES || \
          MLK_USE_NATIVE_POLYVEC_BASEMUL_ACC_MONTGOMERY_CACHED ||         \
          MLK_USE_NATIVE_FIPS202_X1 || MLK_USE_NATIVE_FIPS202_X4 */

#if !defined(MLK_CONFIG_SERIAL_FIPS202_ONLY)
  CHECK(test_poly_rej_uniform_consistency() == 0);
#endif

  return 0;
}
