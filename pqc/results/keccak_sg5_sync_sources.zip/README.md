# SG5 diagnostic source snapshots

Each patch applies independently to vortexPQC commit 68845dd72.
Use an isolated checkout at that commit and `git apply <variant>.patch`.
Configure a separate RV32 build and use the CONFIGS and soft-ABI library paths
in docs/proposals/keccak_sg25_proposal.md. Build the generated
tests/pqc/keccak_sg25 with MAPPING=sg5 SG5_SYNC=barrier and all Stage/KROUND/
UNROLL selectors zero. Launch arguments and exact ELF/host hashes are in
keccak_sg5_sync.csv. These are diagnostic controls, not the default software.

cta_barrier: two CTA-wide barriers per round, global transpose buffer.
lmem_barrier: two private warp barriers, LMEM transpose buffer; the host
reserves 1200 bytes per warp. The reservation is part of this patch.
one_barrier: one private warp barrier after stores; theta consumes all loads
before the next round can overwrite the global buffer.

The retained fence and two-barriers-per-round controls are reproducible from
1bd44cf34 using SG5_SYNC=fence or barrier; final ELFs match the measurements.
No RTL, timing constants, tolerances, or synthesis configurations were changed.
